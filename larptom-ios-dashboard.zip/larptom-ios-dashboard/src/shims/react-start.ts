// Offline stand-in for server calls. The UI never needs a server in this package.
type Fn = (opts?: unknown) => Promise<any>;
export function useServerFn<T>(fn: T): T { return fn; }
export function createServerFn(_opts?: unknown) {
  const chain: any = { inputValidator: () => chain, validator: () => chain, middleware: () => chain, handler: (_h: unknown): Fn => async () => null };
  return chain;
}
