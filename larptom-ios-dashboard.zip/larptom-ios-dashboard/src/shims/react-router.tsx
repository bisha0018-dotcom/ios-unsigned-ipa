import type { AnchorHTMLAttributes, ReactNode } from "react";
export function createFileRoute(_path: string) { return (opts: any) => opts; }
export function Link({ to, children, search: _s, ...rest }: AnchorHTMLAttributes<HTMLAnchorElement> & { to?: string; search?: unknown; children?: ReactNode }) {
  return <a href={to} {...rest}>{children}</a>;
}
export function useNavigate() { return (_o: unknown) => {}; }
