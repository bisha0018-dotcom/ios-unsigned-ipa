import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import "./styles.css";
import { AppTranslation } from "@/components/AppTranslation";
import { Dashboard } from "./AppScreens";

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <AppTranslation>
      <Dashboard />
    </AppTranslation>
  </StrictMode>,
);
