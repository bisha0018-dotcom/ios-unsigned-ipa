import { ChevronDown, Eye, Globe, Map, Maximize2, Minimize2, Minus, Plus, Search } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { AppText, useAppTranslation } from "@/components/AppTranslation";
import { Button } from "@/components/ui/button";
import { LiveViewGlobe } from "@/components/LiveViewGlobe";
import visitorAsset from "@/assets/live-visitor.svg.asset.json";
import { LiveViewMetrics } from "@/components/LiveViewMetrics";
import { LiveViewBehavior } from "@/components/LiveViewBehavior";
import { LiveViewLocations } from "@/components/LiveViewLocations";
import { LiveViewProducts } from "@/components/LiveViewProducts";
import { LiveViewSetup } from "@/components/LiveViewSetup";
import { LIVE_DEFAULTS, LIVE_MARKER_KEY, LIVE_SETUP_KEY, liveMarkerSchema, liveSetupSchema, liveViewData } from "@/lib/live-view-data";
import { Dialog, DialogContent, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { LiveViewEmpty } from "@/components/LiveViewEmpty";

export function LiveViewOverlay({ desktop = false }: { desktop?: boolean }) {
  const container = useRef<HTMLElement>(null);
  const [flat, setFlat] = useState(false);
  const [zoom, setZoom] = useState(0);
  const [fullscreen, setFullscreen] = useState(false);
  useEffect(() => { const changed = () => setFullscreen(document.fullscreenElement === container.current); document.addEventListener("fullscreenchange", changed); return () => document.removeEventListener("fullscreenchange", changed); }, []);
  const translate = useAppTranslation();
  const [cityOpen, setCityOpen] = useState(false);
  const [city, setCity] = useState("");
  const [focus, setFocus] = useState<{lat: number; lon: number; name: string} | null>(null);
  const [cities, setCities] = useState<{id: number; name: string; country?: string; admin1?: string; latitude: number; longitude: number}[]>([]);
  const [cityStatus, setCityStatus] = useState("");
  useEffect(() => {
    if (!cityOpen || city.trim().length < 2) { setCities([]); setCityStatus(""); return; }
    const controller = new AbortController();
    const timer = setTimeout(() => {
      setCityStatus("Searching…");
      void fetch(`https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(city.trim())}&count=8&language=en&format=json`, {signal: controller.signal})
        .then(response => { if (!response.ok) throw new Error("Search unavailable"); return response.json(); })
        .then((result: {results?: typeof cities}) => { setCities(result.results ?? []); setCityStatus(result.results?.length ? "" : "No cities found"); })
        .catch(() => { if (!controller.signal.aborted) setCityStatus("City search unavailable. Try again."); });
    }, 300);
    return () => { clearTimeout(timer); controller.abort(); };
  }, [city, cityOpen]);
  const [setupOpen, setSetupOpen] = useState(false);
  const [setup, setSetup] = useState(LIVE_DEFAULTS);
  useEffect(() => {
    try { const parsed = liveSetupSchema.safeParse(JSON.parse(localStorage.getItem(LIVE_SETUP_KEY) ?? "null")); if (parsed.success) setSetup(parsed.data); } catch { /* defaults */ }
    try { const marker = liveMarkerSchema.safeParse(JSON.parse(localStorage.getItem(LIVE_MARKER_KEY) ?? "null")); if (marker.success) { setFocus(marker.data); setCity(marker.data.name); } } catch { /* no saved marker */ }
  }, []);
  const saveFocus = (next: typeof focus) => {
    if (next && !liveMarkerSchema.safeParse(next).success) return;
    setFocus(next);
    try { if (next) localStorage.setItem(LIVE_MARKER_KEY, JSON.stringify(next)); else localStorage.removeItem(LIVE_MARKER_KEY); } catch { /* storage unavailable */ }
  };
  const update = (next: typeof LIVE_DEFAULTS) => {
    if (!liveSetupSchema.safeParse(next).success) return;
    setSetup(next);
    try { localStorage.setItem(LIVE_SETUP_KEY, JSON.stringify(next)); } catch { /* storage unavailable */ }
  };
  const data = liveViewData(setup.revenue, setup.seed);
  const shuffle = () => update({ ...setup, seed: setup.seed % 1000000 + 1 });
  return (
    <section ref={container} aria-label="Live View" className={`live-view flex min-h-0 flex-1 flex-col overflow-hidden bg-editor-background${desktop ? " adm-live" : ""}`}>
      {desktop ? <header className="adm-live-header">
        <div className="adm-live-title"><Globe size={16} /><h1>Live View</h1><span className="adm-live-updated"><i />Just now</span></div>
        <div className="adm-live-controls">
          <Button variant="outline" className="adm-live-search" onClick={() => setCityOpen(true)}><Search size={14} /><span>Search location</span></Button>
          <Button variant="outline" size="icon" className="live-tool" title="Customize Live View" aria-label="Customize Live View" onClick={() => setSetupOpen(true)}><Eye /></Button>
          <Button variant="outline" size="icon" className="live-tool" title={flat ? "Globe view" : "Map view"} aria-label={flat ? "Globe view" : "Map view"} aria-pressed={flat} onClick={() => setFlat(!flat)}><Map /></Button>
          <Button variant="outline" size="icon" className="live-tool" title={fullscreen ? "Exit fullscreen" : "Fullscreen"} aria-label={fullscreen ? "Exit fullscreen" : "Fullscreen"} onClick={() => { if (document.fullscreenElement) void document.exitFullscreen(); else void container.current?.requestFullscreen(); }}>{fullscreen ? <Minimize2 /> : <Maximize2 />}</Button>
        </div>
      </header> :
      <header className="animate-header-fade shrink-0 bg-editor-background text-insights-ink pt-[env(safe-area-inset-top,0px)]">
        <div className="flex items-center gap-1 px-4 py-3">
          <h1 className="text-lg font-semibold"><AppText>Live View</AppText></h1>
          <ChevronDown className="h-4 w-4" aria-hidden="true" />
        </div>
      </header>}
      {desktop ? <div className="adm-live-body">
        <div className="adm-live-cards"><LiveViewMetrics data={data} /><LiveViewBehavior data={data} /><LiveViewLocations data={data} /><section className="live-metric-card adm-live-returning"><div className="live-metric-heading"><h2>New vs returning customers</h2></div><LiveViewEmpty /></section><LiveViewProducts data={data} seed={setup.seed} /></div>
        <div className="adm-live-map"><LiveViewGlobe flat={flat} focus={focus} visitors={data.visitors} seed={setup.seed} region={setup.region} zoom={zoom} />
          <div className="adm-live-map-footer"><div className="live-legends"><span className="live-badge"><svg width="16" height="16" viewBox="0 0 16 16" aria-hidden="true"><circle cx="8" cy="8" r="7" className="live-order-halo" /><circle cx="8" cy="8" r="4" className="live-order-dot" /></svg>Orders</span><span className="live-badge"><span className="live-visitor-halo"><img src={visitorAsset.url} alt="" width="16" height="16" /></span>Visitors right now</span></div><div className="adm-live-zoom"><Button variant="outline" size="icon" className="live-tool" aria-label="Zoom in" title="Zoom in" disabled={zoom >= 6 || flat} onClick={() => setZoom(Math.min(6, zoom + 1))}><Plus /></Button><Button variant="outline" size="icon" className="live-tool" aria-label="Zoom out" title="Zoom out" disabled={zoom <= 0 || flat} onClick={() => setZoom(Math.max(0, zoom - 1))}><Minus /></Button></div></div>
        </div>
      </div> :
      <div data-live-view-content className="live-content min-h-0 flex-1 overflow-y-auto rounded-t-3xl">
        <div className="live-toolbar">
          <div className="live-legends">
            <span className="live-badge"><svg width="16" height="16" viewBox="0 0 16 16" fill="none" aria-hidden="true"><circle cx="8" cy="8" r="7" className="live-order-halo" /><circle cx="8" cy="8" r="4" className="live-order-dot" /></svg><AppText>Orders</AppText></span>
            <span className="live-badge"><span className="live-visitor-halo"><img src={visitorAsset.url} alt="" width="16" height="16" /></span><AppText>Visitors right now</AppText></span>
          </div>
          <div className="live-tools">
            <Button variant="outline" size="icon" className="live-tool" aria-label={translate("Customize Live View")} title={translate("Customize Live View")} onClick={() => setSetupOpen(true)}><Search /></Button>
            <Button variant="outline" size="icon" className="live-tool" aria-label="Select city" title="Select city" onClick={() => setCityOpen(true)}><Map /></Button>
          </div>
        </div>
        <LiveViewGlobe flat={false} focus={focus} visitors={data.visitors} seed={setup.seed} region={setup.region} />
        <LiveViewMetrics data={data} />
        <LiveViewBehavior data={data} />
        <LiveViewLocations data={data} />
        <LiveViewProducts data={data} seed={setup.seed} />
      </div>}
      <LiveViewSetup open={setupOpen} onOpenChange={setSetupOpen} revenue={setup.revenue} onRevenueChange={revenue => update({ ...setup, revenue, seed: setup.seed % 1000000 + 1 })} region={setup.region} onRegionChange={region => update({ ...setup, region, seed: setup.seed % 1000000 + 1 })} onShuffle={shuffle} onReset={() => update(LIVE_DEFAULTS)} />
      <Dialog open={cityOpen} onOpenChange={setCityOpen}><DialogContent className="live-setup-panel live-city-panel"><DialogTitle>Select city</DialogTitle>
        <Input aria-label="City" placeholder="Enter a city" value={city} onChange={event => setCity(event.target.value)} />
        <div className="live-city-results" aria-live="polite">{cityStatus && <p>{cityStatus}</p>}{cities.map(result => <Button key={result.id} variant="ghost" onClick={() => { saveFocus({lat: result.latitude, lon: result.longitude, name: result.name}); setCityOpen(false); }}><Map size={16} /><span>{[result.name, result.admin1, result.country].filter(Boolean).join(" · ")}</span></Button>)}</div>
        {focus && <Button variant="outline" onClick={() => { saveFocus(null); setCityOpen(false); }}>Remove marker</Button>}
      </DialogContent></Dialog>
    </section>
  );
}