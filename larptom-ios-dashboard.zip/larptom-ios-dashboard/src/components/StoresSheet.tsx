import { useAppTranslation } from "@/components/AppTranslation";
import { AppText } from "@/components/AppTranslation";
import { useEffect } from "react";
import { createPortal } from "react-dom";

import type { AvatarSettings } from "@/components/app-colors";

function CheckIcon() {
  return (
    <svg aria-hidden="true" className="h-5 w-5 shrink-0" viewBox="0 0 20 20" fill="none">
      <path d="M4 10.5 8.5 15 16.5 6.5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

function AddStoreIcon() {
  return (
    <svg aria-hidden="true" className="h-5 w-5 shrink-0" viewBox="0 0 20 20" fill="currentColor">
      <path fillRule="evenodd" d="M10 17a7 7 0 1 0 0-14 7 7 0 0 0 0 14Zm0-1.5a5.5 5.5 0 1 1 0-11 5.5 5.5 0 0 1 0 11Z" />
      <path d="M6.25 10a.75.75 0 0 1 .75-.75h2.25V7a.75.75 0 0 1 1.5 0v2.25H13a.75.75 0 0 1 0 1.5h-2.25V13a.75.75 0 0 1-1.5 0v-2.25H7a.75.75 0 0 1-.75-.75Z" />
    </svg>
  );
}

export function StoresSheet({ open, onClose, store, name }: {
  open: boolean;
  onClose: () => void;
  store: AvatarSettings;
  name: string;
}) {
  const translateAttribute = useAppTranslation();
  useEffect(() => {
    if (!open) return;
    const onKeyDown = (event: KeyboardEvent) => { if (event.key === "Escape") onClose(); };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [open, onClose]);

  if (!open || typeof document === "undefined") return null;

  const rowClass = "flex h-[52px] w-full items-center gap-3 border-t-[0.5px] border-account-border bg-transparent px-4 text-[16px] text-account-ink hover:bg-account-hover active:bg-account-hover";

  return createPortal(
    <div className="fixed inset-0 z-[210] flex items-end justify-center" role="presentation">
      <div className="absolute inset-0 bg-black/40" onClick={onClose} aria-hidden="true" />
      <section
        role="dialog"
        aria-modal="true"
        aria-label={translateAttribute("Stores")}
        className="relative w-full max-w-[430px] rounded-t-2xl bg-account-sheet pb-[max(6px,env(safe-area-inset-bottom))] text-account-ink shadow-2xl animate-in slide-in-from-bottom-4 duration-300"
        style={{ animationTimingFunction: "cubic-bezier(0.32, 0.72, 0, 1)" }}
      >
        <div className="mx-auto my-[6px] h-1 w-9 rounded-[3px] bg-account-handle" />
        <p className="px-4 pb-[10px] pt-1 text-[17px] font-semibold text-account-ink"><AppText>Stores</AppText></p>

        <div className="flex h-[52px] w-full items-center gap-3 px-4 text-left hover:bg-account-hover">
          <span
            className="flex h-7 w-7 shrink-0 items-center justify-center overflow-hidden rounded-[9px]"
            style={{ backgroundColor: store.background }}
          >
            {store.mode === "image" && store.image ? (
              <img src={store.image} alt="" className="h-full w-full object-cover" />
            ) : (
              <span className="text-[14px] font-bold leading-none tracking-[-0.2px] uppercase" style={{ color: store.textColor }}>
                {store.initials}
              </span>
            )}
          </span>
          <span className="flex-1 truncate tracking-[-0.2px]">{name || "My store"}</span>
          <span className="text-account-ink"><CheckIcon /></span>
        </div>

        <button type="button" className={rowClass} onClick={onClose}>
          <span className="text-account-ink"><AddStoreIcon /></span>
          <span className="flex-1 text-left tracking-[-0.2px]"><AppText>Add store</AppText></span>
        </button>
      </section>
    </div>,
    document.body,
  );
}
