import { useAppTranslation } from "@/components/AppTranslation";
import { AppText } from "@/components/AppTranslation";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { ChevronDown, MoreHorizontal, PlusCircle, Search, ListFilter, ArrowDownUp, ImageIcon, X } from "lucide-react";
import PullToRefresh from "@/components/PullToRefresh";
import { Button } from "@/components/ui/button";
import productsArt from "@/assets/products-art.png.asset.json";
import glassesArt from "@/assets/glasses-art.png.asset.json";
import sweaterArt from "@/assets/sweater-art.png.asset.json";
import cactusArt from "@/assets/cactus-art.png.asset.json";
import {
  clearStoredProducts,
  getStoredProducts,
  saveProduct,
  productPriceSchema,
  type ProductStatus,
  type StoredProduct,
} from "@/lib/products-store";

const TABS = ["All", "Active", "Draft", "Archived"] as const;
const STATUSES: ProductStatus[] = ["Active", "Draft", "Archived"];

const STATUS_STYLES: Record<ProductStatus, string> = {
  Active: "bg-[#CDFEE1] text-[#0C5132]",
  Draft: "bg-gray-200 text-gray-700",
  Archived: "bg-gray-200 text-gray-600",
};

/** Shopify-style Products page. */
const ProductsOverlay = () => {
  const translateAttribute = useAppTranslation();
  const [products, setProducts] = useState<StoredProduct[]>([]);
  const [activeTab, setActiveTab] = useState<string>("All");
  const [searchQuery, setSearchQuery] = useState("");
  const [creating, setCreating] = useState(false);

  useEffect(() => {
    const handleUpdate = () => setProducts(getStoredProducts());
    handleUpdate();
    window.addEventListener("products-updated", handleUpdate);
    window.addEventListener("storage", handleUpdate);
    return () => {
      window.removeEventListener("products-updated", handleUpdate);
      window.removeEventListener("storage", handleUpdate);
    };
  }, []);

  const handleRefresh = useCallback(() => {
    /* cosmetic only */
  }, []);

  const addSampleProduct = useCallback(() => {
    saveProduct({
      id: `${Date.now()}-sample`,
      title: "Potted cactus",
      price: 19.99,
      stock: 12,
      status: "Active",
      image: cactusArt.url,
      timestamp: Date.now(),
    });
  }, []);

  const filtered = useMemo(() => {
    let list = products;
    if (activeTab !== "All") list = list.filter((p) => p.status === activeTab);
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      list = list.filter((p) => p.title.toLowerCase().includes(q));
    }
    return list;
  }, [products, activeTab, searchQuery]);

  return (
    <div className="flex min-h-0 flex-1 flex-col overflow-hidden bg-black">
      {/* Header - fixed */}
      <div className="animate-header-fade flex-shrink-0 bg-black text-white" style={{ paddingTop: "env(safe-area-inset-top, 0px)" }}>
        <div className="flex items-center justify-between px-4 py-3">
          <div className="flex items-center gap-1">
            <span className="text-lg font-semibold"><AppText>Products</AppText></span>
            <ChevronDown className="h-4 w-4" />
          </div>
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" aria-label={translateAttribute("New product")} onClick={() => setCreating(true)}><PlusCircle className="h-5 w-5" /></Button>
            <MoreHorizontal
              className="h-5 w-5 cursor-pointer"
              onClick={() => {
                if (products.length === 0) return;
                if (window.confirm("Delete all products?")) clearStoredProducts();
              }}
            />
          </div>
        </div>
      </div>

      {/* White content area with curve */}
      <div className="min-h-0 flex-1 overflow-hidden rounded-t-3xl bg-white">
        {products.length === 0 ? (
          <div
            className="relative h-full overflow-y-auto text-center"
            style={{ background: "rgb(255, 255, 255)", animation: "lp-fade-in 0.2s ease both" }}
          >
            <img
              src={productsArt.url}
              alt=""
              style={{ position: "absolute", top: 41, left: "50%", transform: "translateX(-50%)", width: 131, height: 140 }}
            />
            <h2
              style={{
                margin: 0,
                paddingTop: 200,
                fontSize: 22,
                lineHeight: "27px",
                fontWeight: 700,
                letterSpacing: "-0.3px",
                color: "rgb(26, 26, 26)",
              }}
            >
              <AppText>Add your first product</AppText>
            </h2>
            <p
              style={{
                margin: "8px auto 0",
                width: 240,
                fontSize: 15,
                lineHeight: "22.5px",
                color: "rgb(97, 97, 97)",
              }}
            >
              <AppText>Start by stocking your store with products your customers will love</AppText>
            </p>
            <button
              type="button"
              onClick={() => setCreating(true)}
              style={{
                position: "absolute",
                top: 340,
                left: 40,
                right: 40,
                height: 47,
                borderRadius: 12,
                background: "rgb(48, 49, 43)",
                color: "rgb(255, 255, 255)",
                fontSize: 17,
                fontWeight: 650,
              }}
            >
              <AppText>Add your products</AppText>
            </button>
            <div style={{ position: "absolute", top: 406, left: 40, right: 40, textAlign: "left" }}>
              <div style={{ fontSize: 17, fontWeight: 600, color: "rgb(97, 97, 97)" }}>
                <AppText>More ways to add products</AppText>
              </div>
              <div style={{ display: "flex", gap: 16, marginTop: 10 }}>
                <button
                  type="button"
                  onClick={() => setCreating(true)}
                  style={{
                    flex: "1 1 0%",
                    minWidth: 0,
                    height: 91,
                    borderRadius: 12,
                    background: "rgb(247, 247, 247)",
                    display: "flex",
                    alignItems: "flex-start",
                    gap: 4,
                    padding: "10px 4px 0px 13px",
                    textAlign: "left",
                    position: "relative",
                    overflow: "hidden",
                  }}
                >
                  <span style={{ fontSize: 15, lineHeight: 1.35, color: "rgb(26, 26, 26)", maxWidth: "62%" }}>
                    <AppText>Discover products to sell</AppText>
                  </span>
                  <img
                    src={glassesArt.url}
                    alt=""
                    style={{ position: "absolute", left: 108, top: 17, width: 34, height: 41 }}
                  />
                  <img
                    src={sweaterArt.url}
                    alt=""
                    style={{ position: "absolute", left: 76, top: 49, width: 58, height: 41 }}
                  />
                </button>
                <button
                  type="button"
                  onClick={addSampleProduct}
                  style={{
                    flex: "1 1 0%",
                    minWidth: 0,
                    height: 91,
                    borderRadius: 12,
                    background: "rgb(247, 247, 247)",
                    display: "flex",
                    alignItems: "flex-start",
                    gap: 4,
                    padding: "10px 4px 0px 13px",
                    textAlign: "left",
                    position: "relative",
                    overflow: "hidden",
                  }}
                >
                  <span style={{ fontSize: 15, lineHeight: 1.35, color: "rgb(26, 26, 26)", maxWidth: "62%" }}>
                    <AppText>Add a sample product</AppText>
                  </span>
                  <img
                    src={cactusArt.url}
                    alt=""
                    style={{ position: "absolute", left: 93, top: 34, width: 56, height: 56 }}
                  />
                </button>
              </div>
            </div>
          </div>
        ) : (
        <div className="flex h-full flex-col">
          {/* Search bar - stays pinned */}
          <div className="flex flex-shrink-0 items-center gap-2 bg-white px-4 pt-2 pb-2">
            <div className="flex flex-1 items-center gap-2 rounded-full bg-gray-100 px-3 py-2">
              <Search className="h-4 w-4 text-gray-400" />
              <input
                type="text"
                placeholder={translateAttribute("Search")}
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="flex-1 bg-transparent text-sm text-gray-900 outline-none placeholder:text-gray-400"
              />
            </div>
            <div className="relative flex h-9 w-9 items-center justify-center rounded-full bg-gray-100">
              <ArrowDownUp className="h-4 w-4 text-gray-600" />
            </div>
            <div className="flex h-9 w-9 items-center justify-center rounded-full bg-gray-100">
              <ListFilter className="h-4 w-4 text-gray-600" />
            </div>
          </div>

          {/* Tabs - stays pinned */}
          <div className="flex flex-shrink-0 gap-0 bg-white px-4 py-1">
            {TABS.map((tab) => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`rounded-full px-3 py-1.5 text-[13px] font-medium transition-colors ${
                  activeTab === tab ? "bg-gray-200 text-black" : "text-gray-500"
                }`}
              >
                <AppText>{tab}</AppText>
              </button>
            ))}
          </div>

          {/* Scrollable product list */}
          <div className="min-h-0 flex-1 overflow-hidden">
            <PullToRefresh onRefresh={handleRefresh}>
              <div className="pb-24">
                {filtered.length === 0 ? (
                  <div className="px-4 py-10 text-center text-sm text-gray-400"><AppText>No products yet</AppText></div>
                ) : (
                  filtered.map((product) => (
                    <div key={product.id} className="flex items-center gap-3 px-4 py-3">
                      <div className="flex h-11 w-11 flex-shrink-0 items-center justify-center overflow-hidden rounded-lg border border-gray-200 bg-white">
                        {product.image ? (
                          <img src={product.image} alt={product.title} className="h-full w-full object-cover" />
                        ) : (
                          <ImageIcon className="h-5 w-5 text-gray-400" />
                        )}
                      </div>
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-[15px] font-semibold text-black">{product.title}</p>
                        <p
                          className={`text-[13px] ${
                            product.stock > 0 ? "text-gray-500" : "text-[#8E1F0B]"
                          }`}
                        >
                          {product.stock} available
                        </p>
                      </div>
                      <span
                        className={`flex-shrink-0 rounded-full px-2.5 py-1 text-[12px] font-medium ${
                          STATUS_STYLES[product.status]
                        }`}
                      >
                        {product.status}
                      </span>
                    </div>
                  ))
                )}
              </div>
            </PullToRefresh>
          </div>
        </div>
        )}
      </div>

      {creating && <CreateProductSheet onClose={() => setCreating(false)} />}
    </div>
  );
};

function CreateProductSheet({ onClose }: { onClose: () => void }) {
  const translateAttribute = useAppTranslation();
  const [title, setTitle] = useState("");
  const [stock, setStock] = useState("0");
  const [price, setPrice] = useState("0.00");
  const parsedPrice = productPriceSchema.safeParse(price.trim() === "" ? NaN : Number(price));
  const [status, setStatus] = useState<ProductStatus>("Active");
  const [image, setImage] = useState<string | undefined>(undefined);
  const fileRef = useRef<HTMLInputElement>(null);

  const pickImage = (file: File | undefined) => {
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => setImage(typeof reader.result === "string" ? reader.result : undefined);
    reader.readAsDataURL(file);
  };

  const save = () => {
    const name = title.trim();
    if (!name || !parsedPrice.success) return;
    saveProduct({
      id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
      title: name,
      price: Math.round(parsedPrice.data * 100) / 100,
      stock: Math.max(0, Math.floor(Number(stock) || 0)),
      status,
      ...(image ? { image } : {}),
      timestamp: Date.now(),
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-[70] mx-auto flex w-full max-w-[430px] flex-col justify-end bg-black/50">
      <div className="max-h-[88%] overflow-y-auto rounded-t-3xl bg-white pb-32">
        <div className="flex items-center justify-between border-b border-gray-100 px-4 py-3">
          <button type="button" onClick={onClose} aria-label={translateAttribute("Close")} className="text-gray-500">
            <X className="h-5 w-5" />
          </button>
          <span className="text-[15px] font-semibold text-black"><AppText>New product</AppText></span>
          <Button variant="ghost"
            type="button"
            onClick={save}
            disabled={!title.trim() || !parsedPrice.success}
            className="text-[15px] font-semibold text-desk-link disabled:text-account-handle"
          ><AppText>
            Save
          </AppText></Button>
        </div>

        <div className="space-y-5 px-4 py-4">
          <div>
            <label className="mb-1.5 block text-[13px] font-medium text-gray-500"><AppText>Title</AppText></label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder={translateAttribute("Short sleeve t-shirt")}
              className="w-full rounded-lg border border-gray-300 px-3 py-2.5 text-[15px] text-black outline-none focus:border-black"
            />
          </div>

          <div>
            <label className="mb-1.5 block text-[13px] font-medium text-gray-500"><AppText>Image</AppText></label>
            <button
              type="button"
              onClick={() => fileRef.current?.click()}
              className="flex h-24 w-24 items-center justify-center overflow-hidden rounded-lg border border-dashed border-gray-300 bg-gray-50"
            >
              {image ? (
                <img src={image} alt={translateAttribute("Product")} className="h-full w-full object-cover" />
              ) : (
                <ImageIcon className="h-6 w-6 text-gray-400" />
              )}
            </button>
            <input
              ref={fileRef}
              type="file"
              accept="image/*"
              className="hidden"
              onChange={(e) => pickImage(e.target.files?.[0])}
            />
          </div>

          <div>
            <label htmlFor="product-price" className="mb-1.5 block text-[13px] font-medium text-account-muted"><AppText>Price</AppText> (USD)</label>
            <input id="product-price" type="number" inputMode="decimal" min="0" max="999999999.99" step="0.01" value={price} onChange={e => setPrice(e.target.value)} aria-invalid={!parsedPrice.success} className="w-full rounded-lg border border-account-border px-3 py-2.5 text-[15px] text-account-ink outline-none focus:border-account-ink" />
          </div>

          <div>
            <label className="mb-1.5 block text-[13px] font-medium text-gray-500"><AppText>Available stock</AppText></label>
            <input
              type="number"
              inputMode="numeric"
              value={stock}
              onChange={(e) => setStock(e.target.value)}
              className="w-full rounded-lg border border-gray-300 px-3 py-2.5 text-[15px] text-black outline-none focus:border-black"
            />
          </div>

          <div>
            <label className="mb-1.5 block text-[13px] font-medium text-gray-500"><AppText>Status</AppText></label>
            <div className="flex gap-2">
              {STATUSES.map((s) => (
                <button
                  key={s}
                  type="button"
                  onClick={() => setStatus(s)}
                  className={`rounded-full px-3 py-1.5 text-[13px] font-medium ${
                    status === s ? "bg-[#303030] text-white" : "bg-gray-100 text-gray-600"
                  }`}
                >
                  {s}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default ProductsOverlay;
