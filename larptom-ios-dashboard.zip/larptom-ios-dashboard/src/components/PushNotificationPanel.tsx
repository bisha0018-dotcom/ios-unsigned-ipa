import { useAppTranslation } from "@/components/AppTranslation";
import { AppText } from "@/components/AppTranslation";
import { useEffect, useRef, useState } from "react";

import { BottomSheet } from "@/components/BottomSheet";
import { Switch } from "@/components/ui/switch";
import { INITIAL_METRICS } from "@/components/MetricsCarousel";
import { onStoreChange, readStore, writeStore } from "@/lib/app-store";
import { applyOrderToToday, formatEuro, parseEuro } from "@/lib/apply-order";
import { readCurrency, useCurrency } from "@/lib/currency";
import { clearBadge, incrementBadge, readBadgeCount } from "@/lib/app-badge";
import { randomCustomerName, saveOrder } from "@/lib/orders-store";
import { KACHING_KEY, isKaChingOn, playKaChing } from "@/lib/ka-ching";
import { readLanguage } from "@/lib/app-locale";
import { orderNotification } from "@/lib/ui-translation";

const AUTO_KEY = "push.auto";
const AMOUNT_KEY = "push.amount";
const ORDER_KEY = "push.orderNumber";
const SILENT_KEY = "push.autoSilent";
const ITEMS_KEY = "push.items";
const RANDOM_ITEMS_KEY = "push.randomItems";
const PRESETS_KEY = "push.presets";
const HIGH_SPEED_KEY = "push.highSpeed";

type Preset = { enabled: boolean; amount: string; items: number; randomItems: boolean };

const PRESET_COUNT = 4;

const makeDefaultPresets = (): Preset[] => {
  const amount = readStore(AMOUNT_KEY, "29,99");
  const items = Math.max(1, Number(readStore(ITEMS_KEY, "1")) || 1);
  const randomItems = readStore(RANDOM_ITEMS_KEY, "0") === "1";
  return Array.from({ length: PRESET_COUNT }, (_, i) => ({
    enabled: i === 0,
    amount,
    items,
    randomItems,
  }));
};

const readPresets = (): Preset[] => {
  try {
    const raw = readStore(PRESETS_KEY, "");
    if (!raw) return makeDefaultPresets();
    const parsed = JSON.parse(raw) as Partial<Preset>[];
    const base = makeDefaultPresets();
    return base.map((fallback, i) => {
      const p = parsed[i];
      if (!p) return fallback;
      return {
        enabled: Boolean(p.enabled),
        amount: typeof p.amount === "string" ? p.amount : fallback.amount,
        items: Math.min(99, Math.max(1, Number(p.items) || 1)),
        randomItems: Boolean(p.randomItems),
      };
    });
  } catch {
    return makeDefaultPresets();
  }
};



const METRIC_DEFAULTS = Object.fromEntries(
  INITIAL_METRICS.map((m) => [m.label, { value: m.value, delta: m.delta }]),
);

type Status = "idle" | "sent" | "quiet" | "denied" | "unsupported" | "open-in-new-tab";

const STATUS_TEXT: Record<Status, string> = {
  idle: "",
  sent: "Notification sent.",
  quiet: "App is open — notification hidden.",
  denied: "Notifications are blocked. Enable them in your device settings.",
  unsupported: "This device or browser does not support notifications.",
  "open-in-new-tab": "Open the app from your home screen (or a new tab) to allow notifications.",
};

export function PushNotificationPanel({
  open,
  onClose,
}: {
  open: boolean;
  onClose: () => void;
}) {
  const translateAttribute = useAppTranslation();
  const currency = useCurrency();
  const [auto, setAuto] = useState(false);
  const [silent, setSilent] = useState(false);
  const [highSpeed, setHighSpeed] = useState(false);
  const [kaChing, setKaChing] = useState(true);
  useEffect(() => { setKaChing(isKaChingOn()); }, []);
  const [order, setOrder] = useState(1000);
  const [status, setStatus] = useState<Status>("idle");
  const [badgeCount, setBadgeCount] = useState(readBadgeCount);
  const [storeName, setStoreName] = useState("Larptom.com");
  const [presets, setPresets] = useState<Preset[]>(makeDefaultPresets);
  const [activeIndex, setActiveIndex] = useState(0);
  const orderRef = useRef(order);
  const presetsRef = useRef(presets);

  orderRef.current = order;
  presetsRef.current = presets;

  const active = presets[activeIndex]!;

  const updatePreset = (index: number, patch: Partial<Preset>) => {
    setPresets((prev) => {
      const next = prev.map((p, i) => (i === index ? { ...p, ...patch } : p));
      writeStore(PRESETS_KEY, JSON.stringify(next));
      return next;
    });
  };

  useEffect(() => {
    const sync = () => setStoreName(readStore("bisha.headerName", "Larptom.com"));
    sync();
    return onStoreChange(sync);
  }, []);

  useEffect(() => {
    if (!open) return;
    setStatus("idle");
    setBadgeCount(readBadgeCount());
    setAuto(readStore(AUTO_KEY, "0") === "1");
    setSilent(readStore(SILENT_KEY, "0") === "1");
    setHighSpeed(readStore(HIGH_SPEED_KEY, "0") === "1");
    setOrder(Number(readStore(ORDER_KEY, "1000")) || 1000);
    setPresets(readPresets());
    // Clear the red app-badge dot when the user opens this panel.
    clearBadge();
  }, [open]);

  /** Pick one of the enabled presets at random for this alert. */
  const pickPreset = (): Preset => {
    const enabled = presetsRef.current.filter((p) => p.enabled);
    const pool = enabled.length ? enabled : [presetsRef.current[0]!];
    return pool[Math.floor(Math.random() * pool.length)]!;
  };

  /** How many items this order has: fixed, or random 1..items when randomizing. */
  const pickItemCount = (preset: Preset) => {
    const max = Math.max(1, preset.items);
    return preset.randomItems ? 1 + Math.floor(Math.random() * max) : max;
  };

  /** Total order value = single item amount × item count. */
  const totalText = (preset: Preset, count: number) =>
    formatEuro(parseEuro(preset.amount) * count, 2);

  /** Count the order into today's numbers and move to the next order number. */
  const countOrder = (preset = pickPreset(), count?: number) => {
    const n = count ?? pickItemCount(preset);
    const total = totalText(preset, n);
    applyOrderToToday(total, METRIC_DEFAULTS);
    saveOrder({
      id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
      orderNumber: orderRef.current,
      customerName: randomCustomerName(),
      amount: total,
      items: n,
      timestamp: Date.now(),
      status: "Archived",
    });
    const bumped = orderRef.current + 1;
    setOrder(bumped);
    writeStore(ORDER_KEY, String(bumped));
  };



  /** Persistent notifications (the kind that stay in iOS Notification Center)
      must come from a service worker registration. */
  const getNotifyRegistration = async () => {
    if (!("serviceWorker" in navigator)) return null;
    try {
      const existing = await navigator.serviceWorker.getRegistration("/notification-sw.js");
      if (existing) return existing;
      return await navigator.serviceWorker.register("/notification-sw.js", { scope: "/" });
    } catch {
      return null;
    }
  };

  const show = async (item: { title: string; body: string; order: number }) => {
    const options: NotificationOptions & { renotify?: boolean } = {
      body: item.body,
      icon: "/icon-192.png",
      badge: "/icon-192.png",
      // Unique tag per order so alerts stack in Notification Center
      // instead of replacing each other.
      tag: `order-${item.order}-${Date.now()}`,
      renotify: true,
      data: { order: item.order },
    };
    try {
      const registration = await getNotifyRegistration();
      if (registration) await registration.showNotification(item.title, options);
      else new Notification(item.title, options);
      void playKaChing();
      return true;
    } catch {
      return false;
    }
  };

  const deliver = async (): Promise<Status> => {
    if (typeof window === "undefined" || !("Notification" in window)) return "unsupported";
    if (window.top !== window.self) return "open-in-new-tab";

    const permission =
      Notification.permission === "granted"
        ? "granted"
        : await Notification.requestPermission();
    if (permission !== "granted") return "denied";

    const preset = pickPreset();
    const count = pickItemCount(preset);
    const item = {
      order: orderRef.current,
      ...orderNotification(readLanguage(), orderRef.current, `${readCurrency()}${totalText(preset, count)}`, count, readStore("bisha.headerName", "My Store")),
    };

    const ok = await show(item);
    if (!ok) return "denied";
    countOrder(preset, count);


    incrementBadge();
    if (!open) setBadgeCount(readBadgeCount());
    return "sent";
  };

  const sendOnce = async () => {
    setStatus(await deliver());
  };

  // Auto notifications: fire continuously while enabled.
  // Normal: every 0.5–2.5s. High speed: every 0.1–0.5s.
  useEffect(() => {
    if (!auto) return;
    let timer: number;
    const schedule = () => {
      const delay = highSpeed ? 100 + Math.random() * 400 : 500 + Math.random() * 2000;
      timer = window.setTimeout(
        async () => {
          await deliver();
          schedule();
        },
        delay,
      );
    };
    schedule();
    return () => window.clearTimeout(timer);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [auto, highSpeed]);

  // Silent auto orders: bump today's sales/orders every 6-12s, no notification.
  useEffect(() => {
    if (!silent) return;
    let timer: number;
    const schedule = () => {
      timer = window.setTimeout(
        () => {
          countOrder();
          schedule();
        },
        6000 + Math.random() * 6000,
      );
    };
    schedule();
    return () => window.clearTimeout(timer);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [silent]);

  const updateSilent = (next: boolean) => {
    setSilent(next);
    writeStore(SILENT_KEY, next ? "1" : "0");
  };

  // Keep the displayed badge count in sync when auto notifications add badges
  // while this panel is already open.
  useEffect(() => {
    const sync = () => setBadgeCount(readBadgeCount());
    window.addEventListener("storage", sync);
    const id = window.setInterval(sync, 500);
    return () => {
      window.removeEventListener("storage", sync);
      window.clearInterval(id);
    };
  }, []);

  const updateAuto = (next: boolean) => {
    setAuto(next);
    writeStore(AUTO_KEY, next ? "1" : "0");
    if (next) void deliver();
    else clearBadge();
  };

  return (
    <BottomSheet
      open={open}
      onClose={onClose}
      title={translateAttribute("Push notifications")}
      subtitle="Send iOS order alerts from this app"
    >
      <div className="mt-3 pb-1">
        <div className="flex items-center justify-between gap-3 px-5 py-3">
          <div className="text-[14px] font-medium text-gray-900"><AppText>Auto notifications</AppText></div>
          <Switch checked={auto} onCheckedChange={updateAuto} />
        </div>

        <div className="flex items-center justify-between gap-3 px-5 py-3">
          <div className="text-[14px] font-medium text-gray-900"><AppText>High speed</AppText></div>
          <Switch
            checked={highSpeed}
            onCheckedChange={(next) => {
              setHighSpeed(next);
              writeStore(HIGH_SPEED_KEY, next ? "1" : "0");
            }}
          />
        </div>

        <div className="flex items-center justify-between gap-3 px-5 py-3">
          <div>
            <div className="text-[14px] font-medium text-gray-900"><AppText>Ka-Ching sound</AppText></div>
            <div className="text-[12px] text-gray-500"><AppText>Play sound with each notification</AppText></div>
          </div>
          <Switch
            checked={kaChing}
            onCheckedChange={(next) => {
              setKaChing(next);
              writeStore(KACHING_KEY, next ? "1" : "0");
              if (next) void playKaChing();
            }}
          />
        </div>

        <div className="flex items-center justify-between gap-3 px-5 py-3">
          <div className="text-[14px] font-medium text-gray-900"><AppText>Silent orders</AppText></div>
          <Switch checked={silent} onCheckedChange={updateSilent} />
        </div>

        {badgeCount > 0 && (
          <div className="flex items-center justify-between gap-3 px-5 py-2.5">
            <div className="flex items-center gap-2">
              <span className="text-[13px] text-gray-600"><AppText>App badge</AppText></span>
              <span className="flex h-4 min-w-[16px] items-center justify-center rounded-full bg-red-500 px-1 text-[10px] font-semibold text-white"><AppText>
                {badgeCount > 99 ? "99+" : badgeCount}
              </AppText></span>
            </div>
            <button
              type="button"
              onClick={() => {
                clearBadge();
                setBadgeCount(0);
              }}
              className="text-[12px] font-medium text-gray-500 active:text-gray-900"
            ><AppText>
              Clear
            </AppText></button>
          </div>
        )}

        <div className="mx-5 my-1 h-px bg-gray-100" />

        <div className="px-5 pt-1 pb-2">
          <div className="text-[13px] text-gray-600"><AppText>Notification presets</AppText></div>
          <div className="mt-2 flex gap-1.5">
            {presets.map((p, i) => (
              <button
                key={i}
                type="button"
                onClick={() => setActiveIndex(i)}
                className={`flex-1 rounded-lg border px-2 py-1.5 text-[12px] font-semibold ${
                  i === activeIndex
                    ? "border-gray-900 bg-gray-900 text-white"
                    : "border-gray-200 bg-gray-50 text-gray-600"
                }`}
              >
                #{i + 1}
                {p.enabled && (
                  <span
                    className={`ml-1 inline-block h-1.5 w-1.5 rounded-full align-middle ${
                      i === activeIndex ? "bg-green-400" : "bg-green-500"
                    }`}
                  />
                )}
              </button>
            ))}
          </div>
        </div>

        <div className="flex items-center justify-between gap-3 px-5 py-2.5">
          <span className="text-[13px] text-gray-600"><AppText>Preset {activeIndex + 1} enabled</AppText></span>
          <Switch
            checked={active.enabled}
            onCheckedChange={(next) => updatePreset(activeIndex, { enabled: next })}
          />
        </div>

        <label className="flex items-center justify-between gap-3 px-5 py-2.5">
          <span className="text-[13px] text-gray-600"><AppText>Order amount</AppText></span>
          <span className="flex items-center gap-1">
            <span className="text-[13px] font-semibold text-gray-900">{currency}</span>
            <input
              value={active.amount}
              inputMode="decimal"
              onChange={(e) => updatePreset(activeIndex, { amount: e.target.value })}
              className="w-28 rounded-lg border border-gray-200 bg-gray-50 px-2 py-1.5 text-right text-[13px] font-semibold text-gray-900 outline-none focus:border-gray-400"
            />
          </span>
        </label>

        <label className="flex items-center justify-between gap-3 px-5 py-2.5">
          <span className="text-[13px] text-gray-600"><AppText>Items per order</AppText></span>
          <input
            value={active.items}
            inputMode="numeric"
            onChange={(e) => {
              const clean = e.target.value.replace(/\D/g, "");
              updatePreset(activeIndex, {
                items: Math.min(99, Math.max(1, Number(clean) || 1)),
              });
            }}
            className="w-28 rounded-lg border border-gray-200 bg-gray-50 px-2 py-1.5 text-right text-[13px] font-semibold text-gray-900 outline-none focus:border-gray-400"
          />
        </label>

        <div className="flex items-center justify-between gap-3 px-5 py-2.5">
          <span className="text-[13px] text-gray-600"><AppText>Random item count</AppText></span>
          <Switch
            checked={active.randomItems}
            onCheckedChange={(next) => updatePreset(activeIndex, { randomItems: next })}
          />
        </div>

        <label className="flex items-center justify-between gap-3 px-5 py-2.5">

          <span className="text-[13px] text-gray-600"><AppText>Order number</AppText></span>
          <span className="flex items-center gap-1">
            <span className="text-[13px] font-semibold text-gray-900">#</span>
            <input
              value={order}
              inputMode="numeric"
              onChange={(e) => {
                const clean = e.target.value.replace(/\D/g, "");
                const next = Number(clean) || 0;
                setOrder(next);
                writeStore(ORDER_KEY, String(next));
              }}
              className="w-28 rounded-lg border border-gray-200 bg-gray-50 px-2 py-1.5 text-right text-[13px] font-semibold text-gray-900 outline-none focus:border-gray-400"
            />
          </span>
        </label>

        <div className="px-5 pt-1 pb-2 text-[12px] text-gray-500"><AppText>
          Preview (preset {activeIndex + 1}): Order #{order} — {currency}
          {active.randomItems
            ? `${formatEuro(parseEuro(active.amount), 2)}–${formatEuro(parseEuro(active.amount) * Math.max(1, active.items), 2)}, 1–${Math.max(1, active.items)} items`
            : `${formatEuro(parseEuro(active.amount) * Math.max(1, active.items), 2)}, ${active.items} ${active.items === 1 ? "item" : "items"}`}{" "}
          from Online Store • {storeName}
        </AppText></div>



        <div className="px-5 pt-2">
          <button
            type="button"
            onClick={sendOnce}
            className="w-full rounded-full bg-gray-900 px-4 py-3 text-[14px] font-semibold text-white active:opacity-80"
          ><AppText>
            Send notification (once)
          </AppText></button>
          {status !== "idle" && (
            <p className="mt-2 text-center text-[12px] text-gray-500"><AppText>{STATUS_TEXT[status]}</AppText></p>
          )}
        </div>
      </div>
    </BottomSheet>
  );
}
