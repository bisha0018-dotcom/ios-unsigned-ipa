import { useAppTranslation } from "@/components/AppTranslation";
import { AppText } from "@/components/AppTranslation";
import { useEffect, useMemo, useState } from "react";
import { ArrowLeft, ArrowRight, Check, ChevronLeft, Ellipsis } from "lucide-react";
import PullToRefresh from "./PullToRefresh";
import {
  ComposedChart,
  Line,
  ReferenceLine,
  ResponsiveContainer,
  XAxis,
  YAxis,
} from "recharts";
import { useCurrency } from "@/lib/currency";
import { onStoreChange, readChartShape } from "@/lib/app-store";
import { metricsKey, rangeTicks, useDateRange, type RangeId } from "@/lib/date-range";
import calendarIcon from "@/assets/report-calendar.png.asset.json";
import calendarCompareIcon from "@/assets/report-calendar-compare.png.asset.json";
import slidersIcon from "@/assets/report-sliders.png.asset.json";
import infoIcon from "@/assets/info-icon.png.asset.json";

const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

function dayOffset(days: number) {
  const d = new Date();
  d.setDate(d.getDate() - days);
  return d;
}

function fmtDay(d: Date, withYear = false) {
  return withYear
    ? `${MONTHS[d.getMonth()]} ${d.getDate()}, ${d.getFullYear()}`
    : `${MONTHS[d.getMonth()]} ${d.getDate()}`;
}

/** "Aug 19–Sep 17, 2026" style labels for the current and previous period. */
function periodLabels(range: RangeId): [string, string] {
  if (range === "7d" || range === "30d") {
    const span = range === "7d" ? 6 : 29;
    const cur = `${fmtDay(dayOffset(span))}–${fmtDay(dayOffset(0), true)}`;
    const prev = `${fmtDay(dayOffset(span * 2 + 1))}–${fmtDay(dayOffset(span + 1), true)}`;
    return [cur, prev];
  }
  const base = range === "yesterday" ? 1 : 0;
  return [fmtDay(dayOffset(base), true), fmtDay(dayOffset(base + 1), true)];
}

/** Parse a European formatted number string ("591.760,03") into a number. */
function parseValue(raw: string | undefined | null) {
  if (!raw) return 0;
  const cleaned = String(raw).replace(/\./g, "").replace(",", ".").replace(/[^\d.]/g, "");
  const n = Number.parseFloat(cleaned);
  return Number.isFinite(n) ? n : 0;
}

/** Format a number in European notation with two decimals. */
function money(n: number) {
  const [int, dec] = Math.abs(n).toFixed(2).split(".");
  return `${(int ?? "0").replace(/\B(?=(\d{3})+(?!\d))/g, ".")},${dec}`;
}

function niceMax(peak: number) {
  if (peak <= 0) return 100;
  const magnitude = Math.pow(10, Math.floor(Math.log10(peak)));
  const steps = [1, 1.5, 2, 2.5, 3, 4, 5, 7.5, 10];
  for (const s of steps) {
    const candidate = s * magnitude;
    if (candidate >= peak) return candidate;
  }
  return 10 * magnitude;
}

function hash(str: string) {
  let h = 0;
  for (let i = 0; i < str.length; i++) h = (h * 31 + str.charCodeAt(i)) % 1000;
  return h / 100;
}

/** The same seeded, multi-frequency wave used by the dashboard chart. */
function seededRand(seed: number) {
  let state = seed | 0 || 1;
  return () => {
    state = (state * 16807) % 2147483647;
    return (state % 100000) / 100000;
  };
}

function seededSeries(seed: number, max: number, points: number) {
  const rand = seededRand(seed);
  const frequencyA = 2 + rand() * 5;
  const frequencyB = 4 + rand() * 8;
  const frequencyC = 8 + rand() * 16;
  const phaseA = rand() * Math.PI * 2;
  const phaseB = rand() * Math.PI * 2;
  const phaseC = rand() * Math.PI * 2;
  const raw = Array.from({ length: points }, (_, index) => {
    const t = points <= 1 ? 0 : index / (points - 1);
    return Math.max(
      0.02,
      0.45 +
        0.25 * Math.sin(t * Math.PI * frequencyA + phaseA) +
        0.18 * Math.sin(t * Math.PI * frequencyB + phaseB) +
        0.12 * Math.sin(t * Math.PI * frequencyC + phaseC) +
        (rand() - 0.5) * 0.35,
    );
  });
  const rawPeak = Math.max(...raw, 1);
  return raw.map((value) => (value / rawPeak) * max * 0.92);
}

function pointCount(range: RangeId) {
  if (range === "today" || range === "yesterday") return 49;
  if (range === "7d") return 43;
  return 61;
}

const trimZero = (s: string) => s.replace(/\.0$/, "");

function formatAxis(value: number, symbol: string) {
  if (value === 0) return `${symbol}0`;
  if (value >= 1000) return `${symbol}${trimZero((value / 1000).toFixed(1))}K`;
  return `${symbol}${Math.round(value)}`;
}

/** Live "Total sales" value for the selected range, as shown on the dashboard. */
function useTotalSales(range: RangeId) {
  const [value, setValue] = useState("591.760,03");
  useEffect(() => {
    const sync = () => {
      try {
        const raw = localStorage.getItem(metricsKey(range));
        const saved = raw ? (JSON.parse(raw) as Record<string, { value: string }>) : {};
        setValue(saved["Total sales"]?.value ?? "591.760,03");
      } catch {
        setValue("591.760,03");
      }
    };
    sync();
    return onStoreChange(sync);
  }, [range]);
  return value;
}

function useChartShape() {
  const [token, setToken] = useState("0");
  useEffect(() => {
    setToken(readChartShape());
    return onStoreChange(() => setToken(readChartShape()));
  }, []);
  return token;
}

/** Full-page "Total sales over time" report, opened from the View report pill. */
export function ReportOverlay({ open, onClose }: { open: boolean; onClose: () => void }) {
  const translateAttribute = useAppTranslation();
  const currency = useCurrency();
  const range = useDateRange();
  const ticks = rangeTicks(range);
  const shapeToken = useChartShape();
  const totalRaw = useTotalSales(range);
  const total = parseValue(totalRaw);
  const [curLabel, prevLabel] = periodLabels(range);

  const divisor = range === "today" || range === "yesterday" ? 17 : 22;
  const max = total <= 0 ? 100 : niceMax(total / divisor);
  const yTicks = [0, max / 3, (max * 2) / 3, max];

  const data = useMemo(() => {
    const points = pointCount(range);
    if (total <= 0) {
      return Array.from({ length: points }, (_, i) => ({
        hour: (i * 23) / (points - 1),
        cur: 0,
        prev: 0,
      }));
    }
    const seed = Math.floor(hash(`Total sales:${range}:${shapeToken}`) * 100000) + 1;
    const cur = seededSeries(seed, max, points);
    const prev = seededSeries(seed + 1234, max * 0.75, points);
    return cur.map((value, i) => ({
      hour: (i * 23) / (points - 1),
      cur: value,
      prev: prev[i],
    }));
  }, [total, max, range, shapeToken]);

  /** Five realistic breakdown buckets whose totals add up to the period total. */
  const rows = useMemo(() => {
    const weights = [0.34, 0.24, 0.18, 0.14, 0.1];
    const prevFactor = 0.87;
    return weights.map((w, i) => {
      const rowTotal = total * w;
      const taxes = rowTotal * 0.0925; // ~9,25% sales tax
      const additional = rowTotal * 0.0245; // shipping & duties
      return {
        highlight: i === 0,
        total: money(rowTotal),
        totalSub: money(rowTotal * prevFactor),
        taxes: money(taxes),
        taxesSub: money(taxes * prevFactor),
        additional: money(additional),
        additionalSub: money(additional * prevFactor),
      };
    });
  }, [total]);

  if (!open) return null;

  return (
    <div
      className="fixed inset-0 z-[55] flex w-full flex-col bg-white text-black"
      style={{ fontFamily: '-apple-system, BlinkMacSystemFont, "SF Pro Text", "Segoe UI", Roboto, sans-serif' }}
    >
      {/* Header */}
      <div
        className="flex-shrink-0 bg-white z-10"
        style={{ paddingTop: "env(safe-area-inset-top, 0px)" }}
      >
        <div className="flex items-center justify-between px-4 py-2">
          <button
            type="button"
            aria-label={translateAttribute("Back")}
            onClick={onClose}
            className="flex h-8 w-8 items-center justify-center rounded-full bg-[#f1f1f1] active:opacity-70"
          >
            <ChevronLeft className="h-4 w-4 text-black/70" />
          </button>

          <h1 className="absolute left-1/2 -translate-x-1/2 text-[15px] font-semibold text-black"><AppText>
            Total sales over time
          </AppText></h1>

          <button
            type="button"
            aria-label={translateAttribute("More options")}
            className="flex h-8 w-8 items-center justify-center rounded-full bg-[#f1f1f1] active:opacity-70"
          >
            <Ellipsis className="h-4 w-4 text-black/70" />
          </button>
        </div>
      </div>

      {/* Pull-to-refresh scroll area */}
      <div className="flex-1 min-h-0 relative">
        <PullToRefresh onRefresh={() => {}} spinnerBg="bg-[#f4f4f4]">
          {/* Filter bar */}
          <div className="flex items-center gap-2 pl-4 pr-2 pt-1 pb-0">
            <div
              className="flex-1 min-w-0 overflow-x-auto scrollbar-none"
              style={{ scrollbarWidth: "none", overscrollBehaviorX: "contain", touchAction: "pan-x" }}
            >
              <div className="flex items-center gap-1.5" style={{ width: "max-content" }}>
                <button
                  type="button"
                  className="flex items-center gap-1.5 px-2 h-7 rounded-lg border border-gray-300 bg-white whitespace-nowrap shrink-0 active:bg-gray-50"
                >
                  <img alt="" className="w-3.5 h-3.5 object-contain" src={calendarIcon.url} />
                  <span className="text-[11px] font-medium text-black">{curLabel}</span>
                </button>
                <button
                  type="button"
                  className="flex items-center gap-1.5 px-2 h-7 rounded-lg border border-gray-300 bg-white whitespace-nowrap shrink-0 active:bg-gray-50"
                >
                  <img alt="" className="w-3.5 h-3.5 object-contain" src={calendarCompareIcon.url} />
                  <span className="text-[11px] font-medium text-black">{prevLabel}</span>
                </button>
                <div className="flex items-center gap-0.5 px-2 h-7 rounded-lg border border-gray-300 bg-white whitespace-nowrap shrink-0">
                  <span className="text-[11px] font-medium text-black">$</span>
                  <div className="flex flex-col items-center justify-center -space-y-1">
                    <ArrowRight className="w-2.5 h-2.5 text-black" strokeWidth={2.25} aria-hidden="true" />
                    <ArrowLeft className="w-2.5 h-2.5 text-black" strokeWidth={2.25} aria-hidden="true" />
                  </div>
                  <span className="text-[11px] font-medium text-black">EUR {currency}</span>
                </div>
                <div className="w-2 shrink-0" />
              </div>
            </div>
            <button
              type="button"
              className="flex items-center justify-center w-7 h-7 rounded-lg border border-gray-300 bg-white shrink-0 ml-1.5 active:bg-gray-50"
              aria-label={translateAttribute("Randomize total sales")}
            >
              <img alt="" className="w-4 h-4 object-contain" src={slidersIcon.url} />
            </button>
          </div>
          <div className="border-t border-gray-200 my-[4px] mx-0 px-0 py-px" />

          {/* Total sales card */}
          <div className="px-4 pt-0.5">
            <div className="flex items-start justify-between">
              <div>
                <div className="text-[14px] font-semibold text-black underline decoration-dotted underline-offset-4 decoration-gray-400"><AppText>
                  Total sales
                </AppText></div>
                <div className="flex items-center gap-2 -mt-0.5">
                  <button type="button" className="text-[18px] font-semibold tracking-tight text-black">
                    {currency}{money(total)}
                  </button>
                  <span className="text-gray-500 text-sm inline-block scale-x-75 origin-left">—</span>
                </div>
              </div>
              <img alt="" className="w-4 h-4 object-contain mt-1" src={infoIcon.url} />
            </div>
          </div>

          {/* Chart content */}
          <div>
            <div className="relative h-44 mx-2 mt-2">
          <ResponsiveContainer width="100%" height="100%">
            <ComposedChart data={data} margin={{ top: 5, right: 8, bottom: 0, left: 0 }}>
...
              {/* Previous period: dashed cyan line, same as the dashboard chart */}
              <Line
                type="monotone"
                dataKey="prev"
                stroke="#5bc0de"
                strokeWidth={1.5}
                strokeDasharray="5 3"
                strokeOpacity={0.5}
                dot={false}
                isAnimationActive={false}
              />
              {/* Current period: solid cyan line, same as the dashboard chart */}
              <Line
                type="monotone"
                dataKey="cur"
                stroke="#5bc0de"
                strokeWidth={2}
                strokeLinecap="round"
                strokeLinejoin="round"
                dot={false}
                isAnimationActive={false}
              />
            </ComposedChart>
          </ResponsiveContainer>
        </div>
        <div className="flex items-center justify-center gap-6 mt-4 pb-3">
          <div className="flex items-center gap-2 text-[11px] text-gray-500">
            <span className="w-2 h-2 rounded-full bg-[#5bc0de]" />
            {curLabel}
          </div>
          <div className="flex items-center gap-2 text-[11px] text-gray-500">
            <span className="w-2 h-2 rounded-full bg-[#5bc0de] opacity-50" />
            {prevLabel}
          </div>
        </div>

        <div className="border-t border-b border-gray-200 py-1">
          <div className="flex justify-end px-4">
            <button
              type="button"
              className="w-6 h-6 rounded-md border border-gray-300 flex items-center justify-center"
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="24"
                height="24"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="lucide lucide-maximize2 lucide-maximize-2 w-3.5 h-3.5"
                aria-hidden="true"
              >
                <path d="M15 3h6v6" />
                <path d="M21 3l-7 7" />
                <path d="M3 21l7-7" />
                <path d="M9 21H3v-6" />
              </svg>
            </button>
          </div>
        </div>

        {/* Breakdown table */}
        <div className="border-t border-gray-200 pt-1.5 pb-3">
          <div className="grid grid-cols-3 text-[12px] text-gray-900 pb-1.5 border-b border-gray-200 px-4">
            <div><AppText>Additional ...</AppText></div>
            <div className="text-center"><AppText>Taxes</AppText></div>
            <div className="flex items-center justify-end gap-0.5">
              <Check className="w-3.5 h-3.5" aria-hidden="true" />
              <span><AppText>Total sales</AppText></span>
            </div>
          </div>

          {rows.map((row, i) => (
            <div
              key={i}
              className={`grid grid-cols-3 py-1.5 border-b border-gray-200 px-4 ${
                row.highlight ? "bg-[#f4f4f4]" : ""
              }`}
            >
              <div className="flex flex-col items-start pl-5">
                <div className="flex flex-col items-end">
                  <button type="button" className="text-[12px] font-medium text-black">
                    {currency}{row.additional}
                  </button>
                  <div className="text-[12px] text-gray-500 font-normal">
                    {currency}{row.additionalSub}
                  </div>
                  <div className="text-gray-400 text-[12px] font-normal leading-none inline-block scale-x-75 origin-right">
                    —
                  </div>
                </div>
              </div>
              <div className="flex flex-col items-center pl-2">
                <div className="flex flex-col items-end">
                  <button type="button" className="text-[12px] font-medium text-black">
                    {currency}{row.taxes}
                  </button>
                  <div className="text-[12px] text-gray-500 font-normal">
                    {currency}{row.taxesSub}
                  </div>
                  <div className="text-gray-400 text-[12px] font-normal leading-none inline-block scale-x-75 origin-right">
                    —
                  </div>
                </div>
              </div>
              <div className="flex flex-col items-end">
                <div className="flex flex-col items-end">
                  <div className="text-[12px] font-medium text-black">
                    {currency}{row.total}
                  </div>
                  <div className="text-[12px] text-gray-500 font-normal">
                    {currency}{row.totalSub}
                  </div>
                  <div className="text-gray-400 text-[12px] font-normal leading-none inline-block scale-x-75 origin-right">
                    —
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </PullToRefresh>
  </div>
</div>
  );
}
