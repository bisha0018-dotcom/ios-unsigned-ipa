import { useAppLanguage } from "@/components/AppTranslation";
import { useState } from "react";

import todayIcon from "@/assets/today-icon.png.asset.json";
import reportIcon from "@/assets/report-icon.png.asset.json";
import { DateRangeSheet } from "@/components/DateRangeSheet";
import { useDateRange } from "@/lib/date-range";
import { appText, useLanguage } from "@/lib/app-locale";

/** Date-range + "View report" pill buttons below the chart. */
export function ChartActions({ onReportClick }: { onReportClick?: () => void }) {
  const [sheetOpen, setSheetOpen] = useState(false);
  const range = useDateRange();
  const language = useAppLanguage();
  const rangeKey = range === "today" ? "today" : range === "yesterday" ? "yesterday" : range === "7d" ? "last_7_days" : "last_30_days";


  return (
    <>
      <div className="relative z-10 mt-2 mb-1 flex items-center justify-center gap-2 px-4">
        <button
          type="button"
          data-no-pull
          onClick={() => setSheetOpen((open) => !open)}
          className="flex h-8 items-center gap-2 rounded-xl border border-[#3c3c3c] bg-[#141414] px-2 py-1 text-[11px] font-normal whitespace-nowrap text-neutral-200 transition-colors hover:bg-[#1a1a1a] hover:text-white"
        >
          <img src={todayIcon.url} alt="" className="pointer-events-none h-4 w-4 shrink-0 select-none" />
          <span className="pointer-events-none select-none">{appText(language, rangeKey)}</span>
        </button>

        <button
          type="button"
          data-no-pull
          onClick={() => onReportClick?.()}
          className="flex h-8 items-center gap-2 rounded-xl border border-[#3c3c3c] bg-[#141414] px-3 py-1 text-[11px] font-normal whitespace-nowrap text-neutral-200 transition-colors hover:bg-[#1a1a1a] hover:text-white"
        >
          <img src={reportIcon.url} alt="" className="pointer-events-none h-4 w-4 shrink-0 select-none" />
          <span className="pointer-events-none select-none">{appText(language, "view_report")}</span>
        </button>
      </div>
      <DateRangeSheet open={sheetOpen} onClose={() => setSheetOpen(false)} />
    </>
  );
}
