import { AppText } from "@/components/AppTranslation";
import { useAppTranslation } from "@/components/AppTranslation";
import { BottomSheet } from "@/components/BottomSheet";

export type PromoOrderItem = { id: string; label: string };

export function PromoOrderDialog({
  open,
  onOpenChange,
  items,
  hidden,
  onToggleHidden,
  onMove,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  items: PromoOrderItem[];
  hidden: Record<string, boolean>;
  onToggleHidden: (id: string) => void;
  onMove: (id: string, direction: -1 | 1) => void;
}) {
  const translateAttribute = useAppTranslation();
  return (
    <BottomSheet
      open={open}
      onClose={() => onOpenChange(false)}
      title={translateAttribute("Change order")}
      subtitle="Reorder or hide sections"
    >
      <div className="mt-4 max-h-[60vh] overflow-y-auto px-5">
        {items.map((item, i) => {
          const isHidden = hidden[item.id] ?? false;
          return (
            <div key={item.id} className="flex items-center gap-3 py-3">
              <span
                className={`flex-1 truncate text-[15px] ${isHidden ? "text-gray-400 line-through" : "text-gray-900"}`}
              >
                <AppText>{item.label}</AppText>
              </span>
              <button
                type="button"
                onClick={() => onToggleHidden(item.id)}
                aria-label={isHidden ? "Show section" : "Hide section"}
                className="px-1 text-gray-400 transition-colors hover:text-gray-700"
              >
                {isHidden ? (
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round">
                    <path d="M3 3l18 18" />
                    <path d="M10.6 5.1A9.7 9.7 0 0 1 12 5c7 0 10 7 10 7a17 17 0 0 1-2.2 3.2M6.2 6.2A17 17 0 0 0 2 12s3 7 10 7a9.7 9.7 0 0 0 4.2-.9" />
                    <path d="M9.9 9.9a3 3 0 0 0 4.2 4.2" />
                  </svg>
                ) : (
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round">
                    <path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z" />
                    <circle cx="12" cy="12" r="3" />
                  </svg>
                )}
              </button>
              {i > 0 && (
                <button
                  type="button"
                  onClick={() => onMove(item.id, -1)}
                  aria-label={translateAttribute("Move up")}
                  className="px-1 text-gray-400 transition-colors hover:text-gray-700"
                >
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M12 19V5M5 12l7-7 7 7" />
                  </svg>
                </button>
              )}
              {i < items.length - 1 && (
                <button
                  type="button"
                  onClick={() => onMove(item.id, 1)}
                  aria-label={translateAttribute("Move down")}
                  className="px-1 text-gray-400 transition-colors hover:text-gray-700"
                >
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M12 5v14M5 12l7 7 7-7" />
                  </svg>
                </button>
              )}
            </div>
          );
        })}
      </div>
    </BottomSheet>
  );
}
