import { useAppTranslation, useAppLanguage } from "@/components/AppTranslation";
import { AppText } from "@/components/AppTranslation";
import { useState, useEffect, useMemo, useCallback } from "react";
import { ChevronDown, MoreHorizontal, PlusCircle, Search, ListFilter, ArrowDownUp } from "lucide-react";
import firstOrderArt from "@/assets/orders-first-order.png.asset.json";
import { getStoredOrders, clearStoredOrders, seedDemoOrders, type StoredOrder } from "@/lib/orders-store";
import PullToRefresh from "@/components/PullToRefresh";
import { useCurrency } from "@/lib/currency";

const TABS = ["All", "Unfulfilled", "Unpaid", "Open", "Archived"] as const;

function formatTime(ts: number, language: string): string {
  return new Date(ts).toLocaleTimeString(language, { hour: "numeric", minute: "2-digit" });
}

function groupOrdersByDay(orders: StoredOrder[], language: string): { label: string; orders: StoredOrder[] }[] {
  const now = new Date();
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
  const dayNames = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];

  const groups: Record<string, StoredOrder[]> = {};
  const groupOrder: string[] = [];

  for (const order of orders) {
    const d = new Date(order.timestamp);
    const dayStart = new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime();
    const diffDays = Math.floor((today - dayStart) / 86400000);

    let label: string;
    if (diffDays === 0) label = "Today";
    else if (diffDays === 1) label = "Yesterday";
    else if (diffDays < 7) label = d.toLocaleDateString(language, { weekday: "long" });
    else label = d.toLocaleDateString(language, { month: "short", day: "numeric" });

    if (!groups[label]) {
      groups[label] = [];
      groupOrder.push(label);
    }
    groups[label]!.push(order);
  }

  return groupOrder.map((label) => ({ label, orders: groups[label]! }));
}

function parseAmount(amount: string): number {
  const normalized = amount.replace(/\./g, "").replace(",", ".").replace(/[^0-9.]/g, "");
  return Number(normalized) || 0;
}

/** Shopify-style Orders page. */
const OrdersOverlay = () => {
  const translateAttribute = useAppTranslation();
  const language = useAppLanguage();
  const currency = useCurrency();
  const [orders, setOrders] = useState<StoredOrder[]>([]);
  const [activeTab, setActiveTab] = useState<string>("All");
  const [searchQuery, setSearchQuery] = useState("");

  const handleClearOrders = useCallback(() => {
    clearStoredOrders();
  }, []);

  const handleRefresh = useCallback(() => {
    // Cosmetic only
  }, []);

  useEffect(() => {
    const handleUpdate = () => setOrders(getStoredOrders());
    handleUpdate();
    window.addEventListener("orders-updated", handleUpdate);
    window.addEventListener("storage", handleUpdate);
    return () => {
      window.removeEventListener("orders-updated", handleUpdate);
      window.removeEventListener("storage", handleUpdate);
    };
  }, []);

  const filteredOrders = useMemo(() => {
    let filtered = orders;
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      filtered = filtered.filter(
        (o) => `#${o.orderNumber}`.includes(q) || o.customerName.toLowerCase().includes(q),
      );
    }
    return filtered;
  }, [orders, searchQuery]);

  const grouped = useMemo(() => groupOrdersByDay(filteredOrders, language), [filteredOrders, language]);
  const hasOrders = orders.length > 0;

  return (
    <div className="flex min-h-0 flex-1 flex-col overflow-hidden bg-black">
      {/* Header - fixed */}
      <div className="animate-header-fade flex-shrink-0 bg-black text-white" style={{ paddingTop: "env(safe-area-inset-top, 0px)" }}>
        <div className="flex items-center justify-between px-4 py-3">
          <div className="flex items-center gap-1">
            <span className="text-lg font-semibold"><AppText>Orders</AppText></span>
            <ChevronDown className="h-4 w-4" />
          </div>
          <div className="flex items-center gap-4">
            <PlusCircle className="h-5 w-5 cursor-pointer" onClick={handleClearOrders} />
            <MoreHorizontal className="h-5 w-5" />
          </div>
        </div>
      </div>

      {/* White content area with curve */}
      <div className="min-h-0 flex-1 overflow-hidden rounded-t-3xl bg-white">
        {hasOrders ? (
          <div className="flex h-full flex-col">
            {/* Search bar - stays pinned */}
            <div className="flex-shrink-0 flex items-center gap-2 bg-white px-4 pt-2 pb-2">
              <div className="flex flex-1 items-center gap-2 rounded-full bg-gray-100 px-3 py-2">
                <Search className="h-4 w-4 text-gray-400" />
                <input
                  type="text"
                  placeholder={translateAttribute("Filter orders")}
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="flex-1 bg-transparent text-sm text-gray-900 outline-none placeholder:text-gray-400"
                />
              </div>
              <div className="relative flex h-9 w-9 items-center justify-center rounded-full bg-gray-100">
                <ArrowDownUp className="h-4 w-4 text-gray-600" />
                <div className="absolute top-1 right-1 h-2 w-2 rounded-full bg-gray-500" />
              </div>
              <div className="flex h-9 w-9 items-center justify-center rounded-full bg-gray-100">
                <ListFilter className="h-4 w-4 text-gray-600" />
              </div>
            </div>
            {/* Tabs - stays pinned */}
            <div className="flex-shrink-0 flex gap-0 bg-white px-4 py-1">
              {TABS.map((tab) => (
                <button
                  key={tab}
                  onClick={() => setActiveTab(tab)}
                  className={`rounded-full px-3 py-1.5 text-[13px] font-medium transition-colors ${
                    activeTab === tab ? "bg-gray-200 text-black" : "text-gray-500"
                  }`}
                >
                  <AppText>{tab}</AppText>
                </button>
              ))}
            </div>

            {/* Scrollable order list */}
            <div className="min-h-0 flex-1 overflow-hidden">
              <PullToRefresh onRefresh={handleRefresh}>
                <div className="pb-24">
                  {grouped.map((group) => (
                    <div key={group.label}>
                      <div className="bg-gray-100 px-4 py-1">
                        <span className="text-xs font-medium text-gray-500"><AppText>{group.label}</AppText></span>
                      </div>
                      {group.orders.map((order) => (
                        <div key={order.id} className="border-b border-gray-100 px-4 py-3">
                          <div className="flex items-start justify-between">
                            <span className="text-sm font-semibold text-gray-500">#{order.orderNumber}</span>
                            <span className="text-sm text-gray-400">
                              {currency}
                              {parseAmount(order.amount)
                                .toFixed(2)
                                .replace(/\B(?=(\d{3})+(?!\d))/g, ",")}
                            </span>
                          </div>
                          <p className="mt-0.5 text-xs text-gray-500"><AppText>
                            {order.customerName} • {order.items} {order.items === 1 ? "item" : "items"} •{" "}
                            {formatTime(order.timestamp, language)}
                          </AppText></p>
                          <div className="mt-1.5 flex items-center gap-2">
                            <span className="rounded-full bg-gray-100 px-2.5 py-0.5 text-[11px] font-medium text-gray-600"><AppText>
                              Archived
                            </AppText></span>
                          </div>
                          <p className="mt-1 text-xs text-gray-400">In larptom.com</p>
                        </div>
                      ))}
                    </div>
                  ))}
                </div>
              </PullToRefresh>
            </div>
          </div>
        ) : (
          <div className="flex h-full flex-col items-center px-8 pb-24">
            <img
              src={firstOrderArt.url}
              alt={translateAttribute("Get your first order")}
              className="h-[220px] w-[220px] flex-shrink-0"
              style={{ marginTop: 80 }}
            />
            <h2
              className="text-center"
              style={{
                marginTop: 24,
                fontSize: 22,
                lineHeight: "27px",
                fontWeight: 700,
                letterSpacing: "-0.3px",
                color: "rgb(26,26,26)",
              }}
            >
              <AppText>Get your first order</AppText>
            </h2>
            <p
              className="mx-auto text-center"
              style={{ marginTop: 8, fontSize: 17, lineHeight: "22.5px", color: "rgb(97,97,97)" }}
            >
              <AppText>Use Quick Sale to sell from anywhere to anyone with just your phone</AppText>
            </p>
            <button
              type="button"
              onClick={() => seedDemoOrders(10)}
              className="w-full active:opacity-80"
              style={{
                marginTop: 24,
                height: 47,
                borderRadius: 12,
                background: "rgb(48,48,48)",
                color: "#ffffff",
                fontSize: 17,
                fontWeight: 650,
              }}
            >
              <AppText>Set up Quick Sale</AppText>
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default OrdersOverlay;
