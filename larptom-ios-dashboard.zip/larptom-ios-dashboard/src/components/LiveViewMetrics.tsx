import { Info, ArrowUpRight } from "lucide-react";
import { AppText, useAppTranslation } from "@/components/AppTranslation";
import { formatLiveNumber, liveMetricSeries, type LiveViewData } from "@/lib/live-view-data";

/** Reference-only Live View values, independent of payment reporting. */
export function LiveViewMetrics({ data }: { data: LiveViewData }) {
  const translate = useAppTranslation();
  const metrics = [
    { label: "Visitors right now", value: formatLiveNumber(data.visitors), amount: data.visitors },
    { label: "Total sales", value: formatLiveNumber(data.totalSales, true), amount: data.totalSales, chart: true },
    { label: "Sessions", value: formatLiveNumber(data.sessions), amount: data.sessions, info: true, chart: true },
    { label: "Orders", value: formatLiveNumber(data.orders), amount: data.orders, chart: true },
  ];
  return (
    <div className="live-metrics" aria-label={translate("Live View")}>
      {metrics.map((metric, index) => {
        const points = liveMetricSeries(metric.amount, data.sessions + index * 47);
        const coordinates = points.map((value, i): [number, number] => [i * 100 / 23, 28 - value * 32]);
        const path = coordinates.reduce((result, point, i) => {
          const previous = coordinates[i - 1];
          return previous ? `${result} Q${previous[0]} ${previous[1]} ${(previous[0] + point[0]) / 2} ${(previous[1] + point[1]) / 2}` : `M${point[0]} ${point[1]}`;
        }, "");
        return (
        <section key={metric.label} aria-label={translate(metric.label)} className="live-metric-card">
          <div className="live-metric-heading">
            <h2><AppText>{metric.label}</AppText></h2>
            {metric.info && <Info className="live-metric-info" size={16} aria-label={translate("Sessions")}><title>{translate("Sessions")}</title></Info>}
          </div>
          <div className="live-metric-summary"><p>{metric.value}</p>
            {metric.chart && <><span className="live-metric-trend"><ArrowUpRight size={12} />{metric.amount === 0 ? 0 : Math.round(Math.abs(data.trends[index] ?? 0))}%</span>
              <svg className="live-metric-sparkline" viewBox="0 0 100 32" aria-label={`${translate(metric.label)} ${translate("Live View")}`} role="img"><path d={`${path} L100 32 L0 32Z`} className="live-metric-spark-fill" /><path d={path} className="live-metric-spark-solid" /><path d={metric.amount === 0 ? "M76 28H100" : "M76 22 Q82 13 88 22T100 20"} className="live-metric-spark-dashed" /></svg></>}
          </div>
        </section>
      ); })}
    </div>
  );
}