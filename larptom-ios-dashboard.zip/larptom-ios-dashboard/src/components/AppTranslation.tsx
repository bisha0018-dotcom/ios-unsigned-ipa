import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import { onStoreChange } from "@/lib/app-store";
import { readLanguage } from "@/lib/app-locale";
import { translateUi } from "@/lib/ui-translation";

const LanguageContext = createContext("en");

export function readOldLanguage() {
  try { return JSON.parse(localStorage.getItem("larptom:old:shopify-language") ?? '"en"') as string; }
  catch { return "en"; }
}

export function AppTranslation({ children, legacy = false }: { children: ReactNode; legacy?: boolean }) {
  const [language, setLanguage] = useState("en");
  useEffect(() => {
    const sync = () => setLanguage(legacy ? readOldLanguage() : readLanguage());
    sync();
    const unsubscribe = onStoreChange(sync);
    window.addEventListener("storage", sync);
    window.addEventListener("local-storage-changed", sync);
    return () => { unsubscribe(); window.removeEventListener("storage", sync); window.removeEventListener("local-storage-changed", sync); };
  }, [legacy]);
  useEffect(() => {
    document.documentElement.lang = language;
    document.documentElement.dir = language === "ar" || language === "he" ? "rtl" : "ltr";
  }, [language]);
  return <LanguageContext.Provider value={language}>{children}</LanguageContext.Provider>;
}

export function useAppLanguage() { return useContext(LanguageContext); }

export function useAppTranslation() {
  const language = useContext(LanguageContext);
  return (value: string) => translateUi(language, value);
}

export function AppText({ children }: { children: ReactNode }) {
  const translate = useAppTranslation();
  const transform = (value: ReactNode): ReactNode => {
    if (typeof value === "string") return translate(value);
    if (Array.isArray(value)) {
      if (value.every((item) => typeof item === "string" || typeof item === "number")) return translate(value.join(""));
      return value.map(transform);
    }
    return value;
  };
  return <>{transform(children)}</>;
}