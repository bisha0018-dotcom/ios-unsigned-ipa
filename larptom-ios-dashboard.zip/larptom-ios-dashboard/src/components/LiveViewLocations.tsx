import { Info, ArrowUpLeft, ArrowDownRight } from "lucide-react";
import { AppText, useAppLanguage, useAppTranslation } from "@/components/AppTranslation";
import { Button } from "@/components/ui/button";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { formatLiveNumber, type LiveViewData } from "@/lib/live-view-data";
import { LiveViewEmpty } from "@/components/LiveViewEmpty";

/** Reference locations matching desktop; independent of reporting and activity. */
const locations = [
  { country: "US", place: "New York · New York", sessions: 34, change: 14 },
  { country: "US", place: "California · Los Angeles", sessions: 22, change: 13 },
  { country: "GB", place: "England · London", sessions: 14, change: 18 },
  { country: "CA", place: "Ontario · Toronto", sessions: 11, change: 7, down: true },
  { country: "AU", place: "New South Wales · Sydney", sessions: 9, change: 18 },
] as const;

export function LiveViewLocations({ data }: { data: LiveViewData }) {
  const translate = useAppTranslation();
  const language = useAppLanguage();
  const countries = new Intl.DisplayNames([language], { type: "region" });
  return (
    <section className="live-metric-card live-locations" aria-label={translate("Sessions by location")}>
      <div className="live-metric-heading">
        <h2><AppText>Sessions by location</AppText></h2>
        <TooltipProvider delayDuration={150}><Tooltip><TooltipTrigger asChild>
          <Button variant="ghost" size="icon" className="live-location-info" aria-label={translate("Sessions by location")}><Info size={16} /></Button>
        </TooltipTrigger><TooltipContent className="live-location-tooltip"><AppText>Sessions by location</AppText></TooltipContent></Tooltip></TooltipProvider>
      </div>
      {data.sessions === 0 ? <LiveViewEmpty /> : <ol className="live-location-list">
        {locations.map((location, index) => {
          const sessions = data.locationSessions[index] ?? 0;
          const change = data.trends[index] ?? 0;
          const label = `${countries.of(location.country)} · ${location.place}`;
          const down = change < 0;
          const Arrow = down ? ArrowDownRight : ArrowUpLeft;
          return <li key={location.place}>
            <div className="live-location-label">{label}</div>
            <div className="live-location-row">
              <svg viewBox="0 0 340 28" preserveAspectRatio="none" role="img" aria-label={`${label}: ${sessions} ${translate("Sessions")}`}><rect width={sessions / Math.max(1, ...data.locationSessions) * 340} height="28" rx="2" /></svg>
              <span>{formatLiveNumber(sessions, false, language)}</span>
              <span className="live-location-trend"><Arrow size={10} aria-hidden="true" />{Math.abs(change)}%</span>
            </div>
          </li>;
        })}
      </ol>}
    </section>
  );
}