import { useAppTranslation } from "@/components/AppTranslation";
import { AppText } from "@/components/AppTranslation";
import { useEffect, useState } from "react";
import { ArrowLeft, ChevronRight, Copy, Check } from "lucide-react";
import { useServerFn } from "@tanstack/react-start";
import { LocalePicker } from "@/components/LocalePicker";
import { InsightsPanel } from "@/components/InsightsPanel";
import { AffiliateAdminPanel, AffiliatePanel } from "@/components/AffiliatePanel";
import { isAdminKey } from "@/lib/checkout.functions";
import { readCurrencyCode, setCurrency } from "@/lib/currency";
import { readLanguage, setLanguage } from "@/lib/app-locale";

import { AvatarEditorDialog } from "@/components/AvatarEditorDialog";
import { DEFAULT_AVATAR, type AvatarSettings } from "@/components/app-colors";
import { VisibilityDialog } from "@/components/VisibilityDialog";
import { PushNotificationPanel } from "@/components/PushNotificationPanel";
import { PromoOrderDialog } from "@/components/PromoOrderDialog";
import { randomizeMetrics } from "@/lib/randomize-metrics";
import payoutsIcon from "@/assets/payouts-icon.png.asset.json";
import fulfillIcon from "@/assets/icon-orders-fulfill.png.asset.json";
import captureIcon from "@/assets/icon-payments-capture.png.asset.json";
import returnsIcon from "@/assets/icon-return-requests.png.asset.json";
import highRiskIcon from "@/assets/icon-high-risk.png.asset.json";
import chargebacksIcon from "@/assets/icon-chargebacks.png.asset.json";
import blockIcon from "@/assets/icon-orders-block.png.asset.json";
import { bumpChartShape, readJSON, readStore, writeJSON, writeStore } from "@/lib/app-store";
import { liveDefault, liveKey, metricsKey, rangePill, useDateRange } from "@/lib/date-range";
import { getAppVersion, setAppVersion, type AppVersion } from "@/lib/app-version";

const METRIC_LABELS = ["Total sales", "Orders", "Conversion rate", "Sessions"] as const;
const ACTIVITY_FIELDS = [
  ["payouts", "Payouts today"], ["fulfill", "Fulfill orders"], ["capture", "Capture payments"],
  ["returns", "Return requests"], ["highrisk", "High risk orders"], ["chargebacks", "Chargebacks"],
  ["block", "Orders with block"],
] as const;
const ACTIVITY_DEFAULTS: Record<string, string> = {
  payouts: "1250", fulfill: "50", capture: "8", returns: "2", highrisk: "3", chargebacks: "5", block: "1",
};
const AVATAR_KEYS = ["app.avatar", "app.avatarSmall"] as const;
const ACTIVITY_VISIBILITY_KEY = "bisha.activity.visibility";
const PROMO_ORDER_KEY = "bisha.promos.order";
const PROMO_HIDDEN_KEY = "bisha.promos.hidden";
const PROMO_ITEMS = ["Shopify Editions", "Community", "Shop Store", "Shopify Partners", "SimGym", "EU Withdrawal Rules"].map((label, i) => ({ id: ["editions", "community", "shopstore", "partners", "simgym", "euwithdrawal"][i] ?? "", label }));
const ACTIVITY_ICONS = [payoutsIcon.url, fulfillIcon.url, captureIcon.url, returnsIcon.url, highRiskIcon.url, chargebacksIcon.url, blockIcon.url];
const ACTIVITY_ITEMS = ACTIVITY_FIELDS.map(([id, label], index) => ({ id, label, alt: label, icon: ACTIVITY_ICONS[index] ?? "" }));
const METRIC_DEFAULTS: Record<string, { value: string; delta: string }> = {
  "Total sales": { value: "591.760,03", delta: "+395" }, Orders: { value: "46.344", delta: "+426" },
  "Conversion rate": { value: "5,90", delta: "+696" }, Sessions: { value: "493.999", delta: "+290" },
};

function Input({ value, onChange, onBlur, label, text = false }: {
  value: string; onChange: (value: string) => void; onBlur?: ((value: string) => void) | undefined; label: string; text?: boolean;
}) {
  return <input aria-label={label} value={value} onBlur={(event) => onBlur?.(event.target.value)} inputMode={text ? "text" : "decimal"} onChange={(event) => onChange(event.target.value)}
    className="h-10 w-full min-w-0 bg-transparent text-right text-[15px] font-semibold text-[#303030] outline-none" />;
}

const Row = ({ label, children }: { label: string; children: React.ReactNode }) => <label className="flex min-h-[52px] items-center gap-3 px-4"><span className="shrink-0 text-[15px] text-[#303030]"><AppText>{label}</AppText></span><div className="ml-auto min-w-0 flex-1">{children}</div></label>;
const field = "h-10 w-full bg-transparent text-right text-[15px] font-semibold text-[#303030] outline-none placeholder:text-[#8a8a8a]";
const Group = ({ title, children }: { title: string; children: React.ReactNode }) => <section><h3 className="mb-2 px-1 text-[13px] font-semibold text-[#616161]"><AppText>{title}</AppText></h3><div className="divide-y divide-[#ebebeb] overflow-hidden rounded-xl bg-white shadow-[0_1px_0_rgba(26,26,26,0.07)] ring-1 ring-[#e3e3e3]">{children}</div></section>;
const Action = ({ label, onClick, danger = false }: { label: string; onClick: () => void; danger?: boolean }) => <button type="button" onClick={onClick} className={`flex min-h-[52px] w-full items-center justify-between px-4 text-left text-[15px] active:bg-[#f7f7f7] ${danger ? "font-semibold text-[#e22c38]" : "text-[#303030]"}`}><AppText>{label}</AppText>{!danger && <ChevronRight className="size-4 text-[#8a8a8a]" />}</button>;


function remainingText(expiresAt: string | undefined, now: number) {
  if (!expiresAt) return "—";
  const ms = new Date(expiresAt).getTime() - now;
  if (ms > 50 * 365 * 86400000) return "Lifetime";
  if (ms <= 0) return "Expired";
  const d = Math.floor(ms / 86400000), h = Math.floor((ms % 86400000) / 3600000), m = Math.floor((ms % 3600000) / 60000);
  return d > 0 ? `${d}d ${h}h ${m}m left` : `${h}h ${m}m left`;
}

export function EditPanel({ open, onClose, licenseKey, expiresAt, onOpenAdmin, onLogout }: {
  open: boolean; onClose: () => void; licenseKey?: string | undefined; expiresAt?: string | undefined;
  onOpenAdmin?: (() => void) | undefined; onLogout?: (() => void) | undefined;
}) {
  const translateAttribute = useAppTranslation();
  const checkAdmin = useServerFn(isAdminKey);
  const [admin, setAdmin] = useState(false);
  const [insightsOpen, setInsightsOpen] = useState(false);
  const [affiliatesOpen, setAffiliatesOpen] = useState(false);
  const [language, setCurrentLanguage] = useState("en");
  const [currencyCode, setCurrencyCode] = useState("EUR");
  const [copied, setCopied] = useState(false);
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => {
    if (!open) return;
    setCurrentLanguage(readLanguage()); setCurrencyCode(readCurrencyCode()); setNow(Date.now());
    const id = window.setInterval(() => setNow(Date.now()), 30000);
    let active = true;
    if (licenseKey) void checkAdmin({ data: { key: licenseKey } }).then((r) => { if (active) setAdmin(r.admin); }).catch(() => setAdmin(false));
    return () => { active = false; window.clearInterval(id); };
  }, [open, licenseKey, checkAdmin]);
  const range = useDateRange();
  const [pushOpen, setPushOpen] = useState(false);
  const [name, setName] = useState("Larptom.com");
  const [email, setEmail] = useState("");
  const [notif, setNotif] = useState("1");
  const [live, setLive] = useState("1");
  const [metrics, setMetrics] = useState(METRIC_DEFAULTS);
  const [activity, setActivity] = useState(ACTIVITY_DEFAULTS);
  const [avatars, setAvatars] = useState<AvatarSettings[]>([DEFAULT_AVATAR, DEFAULT_AVATAR]);
  const [avatarEditing, setAvatarEditing] = useState<number | null>(null);
  const [visibilityOpen, setVisibilityOpen] = useState(false);
  const [promoOpen, setPromoOpen] = useState(false);
  const [visible, setVisible] = useState<Record<string, boolean>>({});
  const [promoOrder, setPromoOrder] = useState<string[]>(PROMO_ITEMS.map(({ id }) => id));
  const [promoHidden, setPromoHidden] = useState<Record<string, boolean>>({});
  const [appVersion, setVersionState] = useState<AppVersion>("new");

  useEffect(() => {
    if (!open) return;
    const metricKey = metricsKey(range);
    const saved = readJSON<Record<string, { value: string; delta: string }>>(metricKey, {});
    setName(readStore("bisha.headerName", "Larptom.com"));
    setEmail(readStore("bisha.accountEmail", ""));
    setNotif(readStore("app.notificationCount", "1"));
    setLive(readStore(liveKey(range), liveDefault(range)));
    const nextMetrics: Record<string, { value: string; delta: string }> = {};
    METRIC_LABELS.forEach((label) => {
      const fallback = METRIC_DEFAULTS[label] ?? { value: "0", delta: "+0" };
      nextMetrics[label] = {
        value: saved[label]?.value ?? fallback.value,
        delta: saved[label]?.delta ?? fallback.delta,
      };
    });
    setMetrics(nextMetrics);
    setActivity(Object.fromEntries(ACTIVITY_FIELDS.map(([id]) => [id, readStore(`bisha.activity.${id}`, ACTIVITY_DEFAULTS[id])] )));
    setAvatars(AVATAR_KEYS.map((key) => ({ ...DEFAULT_AVATAR, ...readJSON<Partial<AvatarSettings>>(key, {}) })));
    setVisible(readJSON(ACTIVITY_VISIBILITY_KEY, {}));
    const order = readJSON<string[]>(PROMO_ORDER_KEY, []);
    setPromoOrder([...order.filter((id) => PROMO_ITEMS.some((item) => item.id === id)), ...PROMO_ITEMS.map(({ id }) => id).filter((id) => !order.includes(id))]);
    setPromoHidden(readJSON(PROMO_HIDDEN_KEY, {}));
    setVersionState(getAppVersion());
  }, [open, range]);

  if (!open) return null;

  const updateMetric = (label: string, patch: { value?: string; delta?: string }) => {
    const existing = metrics[label] ?? METRIC_DEFAULTS[label] ?? { value: "0", delta: "+0" };
    const next: Record<string, { value: string; delta: string }> = {
      ...metrics,
      [label]: {
        value: patch.value ?? existing.value,
        delta: patch.delta ?? existing.delta,
      },
    };
    setMetrics(next);
    writeJSON(metricsKey(range), next);
    if (patch.value !== undefined) bumpChartShape();
  };

  const copyKey = () => { if (!licenseKey) return; void navigator.clipboard?.writeText(licenseKey).then(() => { setCopied(true); window.setTimeout(() => setCopied(false), 1500); }); };

  return <div className="pointer-events-auto fixed inset-0 z-[100] mx-auto flex w-full max-w-[430px] flex-col bg-[#f1f1f1] text-[#303030] animate-[lp-fade-in_0.2s_ease_both]">
    <header className="flex h-14 shrink-0 items-center border-b border-[#e3e3e3] bg-white px-2 pt-[env(safe-area-inset-top)]">
      <button type="button" onClick={onClose} aria-label={translateAttribute("Close editor")} className="flex size-10 items-center justify-center rounded-lg text-[#303030] active:bg-[#f1f1f1]"><ArrowLeft className="size-5" /></button>
      <h2 className="flex-1 text-center text-[17px] font-semibold"><AppText>Edit content</AppText></h2>
      <button type="button" onClick={onClose} className="h-9 rounded-lg bg-[#303030] px-3 text-[14px] font-semibold text-white active:opacity-80"><AppText>Done</AppText></button>
    </header>

    <main className="hide-scrollbar min-h-0 flex-1 overflow-y-auto pb-[max(24px,env(safe-area-inset-bottom))]">
      <div className="space-y-6 px-4 py-4">
        <section className="overflow-hidden rounded-xl bg-white ring-1 ring-[#e3e3e3]">
          <div className="flex items-center gap-3 p-4">
            <div className="flex size-12 shrink-0 items-center justify-center rounded-xl bg-[#303030] text-[18px] font-bold text-white">{(name || "L").slice(0, 1).toUpperCase()}</div>
            <div className="min-w-0 flex-1">
              <p className="truncate text-[16px] font-semibold">{name || "Larptom.com"}</p>
              <p className="truncate text-[13px] text-[#616161]">{email || translateAttribute("No email set")}</p>
            </div>
            <span className="shrink-0 rounded-full bg-[#cdfee1] px-2.5 py-1 text-[12px] font-semibold text-[#0c5132]">{admin ? "Owner" : remainingText(expiresAt, now)}</span>
          </div>
          {licenseKey && <button type="button" onClick={copyKey} className="flex w-full items-center gap-2 border-t border-[#ebebeb] px-4 py-3 text-left active:bg-[#f7f7f7]">
            <span className="text-[13px] text-[#616161]"><AppText>License key</AppText></span>
            <span className="ml-auto truncate font-mono text-[13px] font-semibold">{licenseKey}</span>
            {copied ? <Check className="size-4 text-[#0c5132]" /> : <Copy className="size-4 text-[#8a8a8a]" />}
          </button>}
        </section>

        <Group title={translateAttribute("General")}>
          <div className="flex items-center gap-3 px-4 py-2">
            <span className="text-[15px]"><AppText>App version</AppText></span>
            <div className="ml-auto grid grid-cols-2 gap-1 rounded-lg bg-[#f1f1f1] p-1">
              {(["new", "old"] as const).map((version) => <button key={version} type="button" onClick={() => { setVersionState(version); setAppVersion(version); }} className={`h-8 rounded-md px-4 text-[13px] font-semibold capitalize ${appVersion === version ? "bg-white text-[#303030] shadow-sm" : "text-[#616161]"}`}>{version}</button>)}
            </div>
          </div>
          <div className="p-3"><LocalePicker language={language} currencyCode={currencyCode} onLanguageChange={(code) => { setLanguage(code); setCurrentLanguage(code); }} onCurrencyChange={(code) => { setCurrency(code); setCurrencyCode(code); }} /></div>
        </Group>
        <Group title={translateAttribute("Notifications")}>
          <Action label="Push notifications" onClick={() => setPushOpen(true)} />
        </Group>
        <Group title={translateAttribute("Profile")}>
          <Row label="Name">{Input({ label: "Name", value: name, text: true, onChange: (v) => { setName(v); writeStore("bisha.headerName", v); } })}</Row>
          <Row label="Email"><input aria-label={translateAttribute("Email")} type="email" autoComplete="email" placeholder={translateAttribute("name@email.com")} value={email} onChange={(event) => { setEmail(event.target.value); writeStore("bisha.accountEmail", event.target.value); }} className={field} /></Row>
          <Row label="Notifications">{Input({ label: "Notifications", value: notif, onChange: (v) => { const clean = v.replace(/\D/g, ""); setNotif(clean); writeStore("app.notificationCount", clean); } })}</Row>
          <Action label="Profile image" onClick={() => setAvatarEditing(0)} />
          <Action label="Store image" onClick={() => setAvatarEditing(1)} />
        </Group>

        <Group title={`Numbers · ${rangePill(range)}`}>
          <Row label="Live visitors">{Input({ label: "Live visitors", value: live, onChange: (v) => { setLive(v); writeStore(liveKey(range), v); } })}</Row>
          {METRIC_LABELS.map((label) => <div key={label} className="flex min-h-[52px] items-center gap-2 px-4">
            <span className="shrink-0 text-[15px]"><AppText>{label}</AppText></span>
            <div className="ml-auto flex min-w-0 flex-1 items-center justify-end gap-2">
              {Input({ label, value: metrics[label]?.value ?? "", onChange: (v) => updateMetric(label, { value: v }), onBlur: label === "Total sales" ? (v) => { const t = v.trim(); if (t && !t.includes(",")) updateMetric(label, { value: `${t},${String(1 + Math.floor(Math.random() * 99)).padStart(2, "0")}` }); } : undefined })}
              <div className="w-16 shrink-0 rounded-lg bg-[#f1f1f1] px-2">{Input({ label: `${label} change`, value: metrics[label]?.delta ?? "", text: true, onChange: (v) => updateMetric(label, { delta: v }) })}</div>
            </div>
          </div>)}
          <Action label="Randomize numbers" onClick={() => { randomizeMetrics(); setMetrics(readJSON<Record<string, { value: string; delta: string }>>(metricsKey(range), {})); }} />
        </Group>

        <Group title={translateAttribute("Activity")}>
          {ACTIVITY_FIELDS.map(([id, label]) => <Row key={id} label={label}>{Input({ label, value: activity[id] ?? "", onChange: (v) => { setActivity((current) => ({ ...current, [id]: v })); writeStore(`bisha.activity.${id}`, v); } })}</Row>)}
          <Action label="Visible boxes" onClick={() => setVisibilityOpen(true)} />
          <Action label="Bottom sections" onClick={() => setPromoOpen(true)} />
        </Group>

        {licenseKey && <Group title={translateAttribute(admin ? "Owner" : "Affiliate")}>
          {admin && <Action label="Admin" onClick={() => onOpenAdmin?.()} />}
          {admin && <Action label="Insights" onClick={() => setInsightsOpen(true)} />}
          <Action label={admin ? "Affiliates" : "Affiliate program · earn 30%"} onClick={() => setAffiliatesOpen(true)} />
        </Group>}

        {onLogout && <div className="overflow-hidden rounded-xl bg-white ring-1 ring-[#e3e3e3]"><Action danger label="Log out" onClick={() => { onClose(); onLogout(); }} /></div>}
      </div>
    </main>
    {licenseKey && <InsightsPanel open={insightsOpen} onClose={() => setInsightsOpen(false)} licenseKey={licenseKey} />}
    {licenseKey && admin && <AffiliateAdminPanel open={affiliatesOpen} onClose={() => setAffiliatesOpen(false)} licenseKey={licenseKey} />}
    {licenseKey && !admin && <AffiliatePanel open={affiliatesOpen} onClose={() => setAffiliatesOpen(false)} licenseKey={licenseKey} />}
    <PushNotificationPanel open={pushOpen} onClose={() => setPushOpen(false)} />
    <AvatarEditorDialog open={avatarEditing !== null} onOpenChange={(next) => { if (!next) setAvatarEditing(null); }} value={avatars[avatarEditing ?? 0] ?? DEFAULT_AVATAR} onChange={(next) => { const index = avatarEditing; if (index === null) return; setAvatars((current) => current.map((avatar, i) => i === index ? next : avatar)); writeJSON(AVATAR_KEYS[index] ?? AVATAR_KEYS[0], next); }} />
    <VisibilityDialog open={visibilityOpen} onOpenChange={setVisibilityOpen} items={ACTIVITY_ITEMS} visible={visible} onToggle={(id, next) => { const updated = { ...visible, [id]: next }; setVisible(updated); writeJSON(ACTIVITY_VISIBILITY_KEY, updated); }} />
    <PromoOrderDialog open={promoOpen} onOpenChange={setPromoOpen} items={promoOrder.map((id) => PROMO_ITEMS.find((item) => item.id === id)).filter((item): item is (typeof PROMO_ITEMS)[number] => Boolean(item))} hidden={promoHidden} onToggleHidden={(id) => { const updated = { ...promoHidden, [id]: !promoHidden[id] }; setPromoHidden(updated); writeJSON(PROMO_HIDDEN_KEY, updated); }} onMove={(id, direction) => { const index = promoOrder.indexOf(id); const other = index + direction; if (index < 0 || other < 0 || other >= promoOrder.length) return; const updated = [...promoOrder]; [updated[index], updated[other]] = [updated[other] ?? id, updated[index] ?? id]; setPromoOrder(updated); writeJSON(PROMO_ORDER_KEY, updated); }} />
  </div>;
}
