import { useEffect, useState } from "react";
import { createPortal } from "react-dom";

import type { ChartMetric } from "@/components/MetricsChart";
import upArrowAsset from "@/assets/tooltip-up-arrow.png.asset.json";
import downArrowAsset from "@/assets/tooltip-down-arrow.png.asset.json";

/** Format a numeric value the way the metric card shows it. */
function formatValue(value: number, metric: ChartMetric) {
  const prefix = metric.prefix ?? "";
  const suffix = metric.suffix ?? "";
  if (suffix === "%") return `${value.toFixed(1)}%`;
  const rounded = value >= 100 ? Math.round(value) : Math.round(value * 100) / 100;
  const str = rounded.toLocaleString("de-DE", {
    minimumFractionDigits: value >= 100 ? 0 : 2,
    maximumFractionDigits: 2,
  });
  return `${prefix}${str}${suffix}`;
}

/** "+146%" style delta, compacted to 1.5K% past 1000. */
function formatDelta(current: number, previous: number) {
  if (previous <= 0) {
    if (current <= 0) return null;
    return { up: true, text: "100%" };
  }
  const pct = ((current - previous) / previous) * 100;
  const up = pct >= 0;
  const abs = Math.abs(pct);
  const text =
    abs >= 1000 ? `${(abs / 1000).toFixed(1)}K%` : `${Math.round(abs)}%`;
  return { up, text };
}

function ArrowUp({ className }: { className?: string }) {
  return (
    <img
      src={upArrowAsset.url}
      alt=""
      className={className}
      aria-hidden="true"
      draggable={false}
    />
  );
}

function ArrowDown({ className }: { className?: string }) {
  return (
    <img
      src={downArrowAsset.url}
      alt=""
      className={className}
      aria-hidden="true"
      draggable={false}
    />
  );
}


export function ChartScrubTooltip({
  metric,
  current,
  previous,
  currentLabel,
  previousLabel,
  left,
  top,
}: {
  metric: ChartMetric;
  current: number;
  previous: number;
  currentLabel: string;
  previousLabel: string;
  left: number;
  top: number;
}) {
  const delta = formatDelta(current, previous);
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);
  if (!mounted) return null;

  return createPortal(
    <div
      className="pointer-events-none fixed z-[90] -translate-x-1/2 animate-fade-in"
      style={{ left, top }}
    >
      <div className="w-max max-w-[calc(100vw-16px)] rounded-[12px] bg-[#2c2c2e] px-3 py-2 shadow-2xl">
        <div className="grid grid-cols-[auto_auto] gap-x-5 gap-y-1">
          <div className="flex items-center gap-1.5 whitespace-nowrap">
            <span className="h-[7px] w-[7px] rounded-full bg-[#0a84ff]" />
            <span className="text-[13px] font-normal leading-none tracking-[-0.01em] text-[#f2f2f7]">
              {currentLabel}
            </span>
          </div>
          <div className="flex items-center gap-1.5 whitespace-nowrap">
            <span className="h-[7px] w-[7px] rounded-full bg-[#8e8e93]" />
            <span className="text-[13px] font-normal leading-none tracking-[-0.01em] text-[#f2f2f7]">
              {previousLabel}
            </span>
          </div>
          <div className="flex items-center gap-1.5 whitespace-nowrap">
            <span className="text-[13px] font-semibold leading-none tracking-[-0.01em] text-white">
              {formatValue(current, metric)}
            </span>
              {delta ? (
                <span
                  className={`inline-flex items-center gap-0.5 text-[13px] font-semibold leading-none tracking-[-0.01em] ${
                    delta.up ? "text-[#60a45e]" : "text-[#b6b6b6]"
                  }`}
                >
                  {delta.up ? (
                    <ArrowUp className="h-[11px] w-[11px] translate-y-[2px] object-contain" />
                  ) : (
                    <ArrowDown className="h-[11px] w-[11px] translate-y-[2px] object-contain" />
                  )}
                  {delta.text}
                </span>
              ) : null}
          </div>
          <span className="whitespace-nowrap text-[13px] font-semibold leading-none tracking-[-0.01em] text-white">
            {formatValue(previous, metric)}
          </span>
        </div>
      </div>
    </div>,
    document.body
  );
}

