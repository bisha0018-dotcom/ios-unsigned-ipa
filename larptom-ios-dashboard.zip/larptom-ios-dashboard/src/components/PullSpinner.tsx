const BARS = 8;

export function PullSpinner({
  progress,
  spinning,
}: {
  progress: number;
  spinning: boolean;
}) {
  const clamped = Math.min(1, Math.max(0, progress));
  const visible = spinning ? BARS : Math.round(clamped * BARS);

  return (
    <div
      className="relative w-7 h-7"
      style={{ animation: spinning ? "ios-spin 1.4s linear infinite" : undefined }}
      aria-hidden
    >
      {Array.from({ length: BARS }).map((_, i) => (
        <div
          key={i}
          className="absolute left-1/2 top-0 w-[3.5px] h-[9px] rounded-full bg-gray-400"
          style={{
            transformOrigin: "center 14px",
            transform: `translateX(-50%) rotate(${45 * i}deg)`,
            opacity: i < visible ? 1 - i * 0.1 : 0,
            transition: "opacity 0.09s ease-out",
          }}
        />
      ))}
      <style>{`@keyframes ios-spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }`}</style>
    </div>
  );
}
