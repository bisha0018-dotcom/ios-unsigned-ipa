import { useAppTranslation } from "@/components/AppTranslation";
import { AppText } from "@/components/AppTranslation";
import { useEffect } from "react";
import { createPortal } from "react-dom";
import { Bell, ChevronRight } from "lucide-react";

import { Button } from "@/components/ui/button";
import type { AvatarSettings } from "@/components/app-colors";

function ManageAccountIcon() {
  return <svg aria-hidden="true" className="size-5 shrink-0" viewBox="0 0 20 20" fill="currentColor">
    <path fillRule="evenodd" d="M10 3a3.5 3.5 0 1 0 0 7 3.5 3.5 0 0 0 0-7Zm-2 3.5a2 2 0 1 1 4 0 2 2 0 0 1-4 0Z" />
    <path fillRule="evenodd" d="M15.484 14.227a6.274 6.274 0 0 0-10.968 0l-.437.786a1.338 1.338 0 0 0 1.17 1.987h9.502a1.338 1.338 0 0 0 1.17-1.987l-.437-.786Zm-9.657.728a4.773 4.773 0 0 1 8.346 0l.302.545h-8.951l.303-.545Z" />
  </svg>;
}

function HelpCenterIcon() {
  return <svg aria-hidden="true" className="size-5 shrink-0" viewBox="0 0 20 20" fill="currentColor">
    <path d="M9.75 6.5a.75.75 0 0 0-1.5 0v2.5c0 .284.16.544.415.671l1.5.75a.75.75 0 1 0 .67-1.341L9.75 8.536V6.5Z" />
    <path fillRule="evenodd" d="M9 14.5c1.248 0 2.4-.416 3.323-1.117l2.897 2.897a.75.75 0 1 0 1.06-1.06l-2.897-2.897A5.5 5.5 0 1 0 9 14.5ZM9 13a4 4 0 1 0 0-8 4 4 0 0 0 0 8Z" />
  </svg>;
}

export function AccountSheet({ open, onClose, onManageAccount, onNotifications, onLogout, avatar, name, email }: {
  open: boolean;
  onClose: () => void;
  onManageAccount: () => void;
  onNotifications: () => void;
  onLogout: () => void;
  avatar: AvatarSettings;
  name: string;
  email: string;
}) {
  const translateAttribute = useAppTranslation();
  useEffect(() => {
    if (!open) return;
    const onKeyDown = (event: KeyboardEvent) => { if (event.key === "Escape") onClose(); };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [open, onClose]);

  if (!open || typeof document === "undefined") return null;
  return createPortal(
    <div className="fixed inset-0 z-[210] flex items-end justify-center" role="presentation">
      <div className="absolute inset-0 bg-black/40" onClick={onClose} aria-hidden="true" />
      <section role="dialog" aria-modal="true" aria-label={translateAttribute("Account menu")} className="relative w-full max-w-[430px] rounded-t-[24px] bg-account-sheet pb-[max(22px,env(safe-area-inset-bottom))] text-account-ink shadow-2xl animate-in slide-in-from-bottom-4 duration-200">
        <div className="mx-auto my-3 h-1 w-9 rounded-full bg-account-border" />
        <div className="flex items-center gap-3 border-b border-account-border px-4 pb-4 pt-1">
          <div className="flex h-11 w-11 shrink-0 items-center justify-center overflow-hidden rounded-full" style={{ backgroundColor: avatar.background }}>
            {avatar.mode === "image" && avatar.image ? <img src={avatar.image} alt="" className="h-full w-full object-cover" /> : <span className="font-semibold uppercase" style={{ color: avatar.textColor }}>{avatar.initials}</span>}
          </div>
          <div className="min-w-0 flex-1">
            <p className="truncate text-[17px] font-semibold">{name || "Larptom.com"}</p>
            {email && <p className="truncate text-[14px] text-account-muted">{email}</p>}
          </div>
        </div>
        <div className="divide-y divide-account-border">
          <Button variant="ghost" className="flex h-[52px] w-full justify-start gap-3 rounded-none px-5 text-[16px] font-normal text-account-ink hover:bg-account-hover hover:text-account-ink" onClick={onManageAccount}><ManageAccountIcon /><span className="flex-1 text-left"><AppText>Manage account</AppText></span><ChevronRight className="size-4 text-account-muted" /></Button>
          <Button variant="ghost" className="flex h-[52px] w-full justify-start gap-3 rounded-none px-5 text-[16px] font-normal text-account-ink hover:bg-account-hover hover:text-account-ink" onClick={onNotifications}><Bell className="size-5" /><span className="flex-1 text-left"><AppText>Notification settings</AppText></span><ChevronRight className="size-4 text-account-muted" /></Button>
          <Button variant="ghost" asChild className="flex h-[52px] w-full justify-start gap-3 rounded-none px-5 text-[16px] font-normal text-account-ink hover:bg-account-hover hover:text-account-ink"><a href="https://t.me/+qogSlK-Vy2g3MmNh" target="_blank" rel="noopener noreferrer" onClick={onClose}><HelpCenterIcon /><span className="flex-1 text-left"><AppText>Help center</AppText></span><ChevronRight className="size-4 text-account-muted" /></a></Button>
          <Button variant="ghost" className="flex h-[54px] w-full justify-start gap-3 rounded-none px-5 text-[16px] font-normal text-account-logout hover:bg-account-hover hover:text-account-logout" onClick={onLogout}><span><AppText>Log out</AppText></span></Button>
        </div>
      </section>
    </div>, document.body,
  );
}