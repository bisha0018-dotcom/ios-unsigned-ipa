import { RotateCcw, Shuffle, X } from "lucide-react";
import { AppText, useAppTranslation } from "@/components/AppTranslation";
import { Button } from "@/components/ui/button";
import { Dialog, DialogPortal, DialogOverlay, DialogTitle, DialogClose } from "@/components/ui/dialog";
import * as DialogPrimitive from "@radix-ui/react-dialog";
import { LIVE_REGIONS, type LiveRegion, livePositionFromRevenue, liveRevenueFromPosition } from "@/lib/live-view-data";

export function LiveViewSetup({ open, onOpenChange, revenue, onRevenueChange, onShuffle, onReset, region, onRegionChange }: {
  open: boolean; onOpenChange: (open: boolean) => void; revenue: number;
  onRevenueChange: (value: number) => void; onShuffle: () => void; onReset: () => void;
  region: LiveRegion; onRegionChange: (region: LiveRegion) => void;
}) {
  const translate = useAppTranslation();
  const money = new Intl.NumberFormat("en-US", { style: "currency", currency: "USD", minimumFractionDigits: 2, maximumFractionDigits: 2 });
  return <Dialog open={open} onOpenChange={onOpenChange}><DialogPortal>
    <DialogOverlay className="z-[75]" />
    <DialogPrimitive.Content className="live-setup-panel fixed left-[50%] top-[50%] translate-x-[-50%] translate-y-[-50%]" aria-describedby={undefined}>
      <div className="live-setup-heading"><DialogTitle><AppText>Live View</AppText></DialogTitle><DialogClose asChild><Button variant="ghost" size="icon" aria-label={translate("Close")}><X /></Button></DialogClose></div>
      <div className="live-setup-revenue"><span><AppText>Total sales</AppText></span><strong>{money.format(revenue)}</strong></div>
      <input className="live-setup-slider" type="range" min="0" max="100" step="0.1" value={livePositionFromRevenue(revenue)} onChange={e => onRevenueChange(liveRevenueFromPosition(Number(e.target.value)))} aria-label={translate("Revenue")} aria-valuetext={money.format(revenue)} />
      <div className="live-setup-limits"><span>$0</span><span>$10M</span></div>
      <fieldset className="live-setup-regions"><legend>Visitor locations</legend><div>{LIVE_REGIONS.map(item => <Button key={item.id} variant="outline" aria-pressed={region === item.id} onClick={() => onRegionChange(item.id)}>{item.label}</Button>)}</div></fieldset>
      <div className="live-setup-actions"><Button variant="outline" onClick={onReset}><RotateCcw /><AppText>Reset</AppText></Button><Button variant="outline" onClick={onShuffle} disabled={revenue === 0}><Shuffle /><AppText>Shuffle</AppText></Button><Button variant="account" onClick={() => onOpenChange(false)}><AppText>Done</AppText></Button></div>
    </DialogPrimitive.Content>
  </DialogPortal></Dialog>;
}