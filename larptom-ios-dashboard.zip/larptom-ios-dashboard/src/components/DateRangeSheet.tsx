import { useAppTranslation } from "@/components/AppTranslation";
import { AppText } from "@/components/AppTranslation";
import { useEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { ChevronRight, Check } from "lucide-react";
import fixedDatesIcon from "@/assets/fixed-dates-icon.png.asset.json";
import rollingPeriodIcon from "@/assets/rolling-period-icon.png.asset.json";
import { RANGE_OPTIONS, setRange, useDateRange, type RangeId } from "@/lib/date-range";

const quickRanges: { label: string; id?: RangeId }[] = [
  ...RANGE_OPTIONS.map((o) => ({ label: o.label, id: o.id })),
  { label: "Last 90 days" },
  { label: "Last 365 days" },
];


export function DateRangeSheet({
  open,
  onClose,
}: {
  open: boolean;
  onClose: () => void;
}) {
  const translateAttribute = useAppTranslation();
  const selected = useDateRange();
  const [mounted, setMounted] = useState(false);

  const [exiting, setExiting] = useState(false);
  const [box, setBox] = useState<{ top: number; height: number } | null>(null);
  const wasOpen = useRef(false);
  const visible = open || exiting;

  useEffect(() => setMounted(true), []);

  // Match the white activity section exactly, on every phone size.
  useEffect(() => {
    if (!open) return undefined;
    const measure = () => {
      const el = document.getElementById("activity-white-section");
      const vh = window.visualViewport?.height ?? window.innerHeight;
      if (!el) {
        setBox({ top: vh * 0.41, height: vh * 0.59 - 26 });
        return;
      }
      const r = el.getBoundingClientRect();
      const top = Math.max(8, r.top);
      setBox({ top, height: Math.max(220, vh - top - 26) });
    };
    measure();
    window.addEventListener("resize", measure);
    window.visualViewport?.addEventListener("resize", measure);
    return () => {
      window.removeEventListener("resize", measure);
      window.visualViewport?.removeEventListener("resize", measure);
    };
  }, [open]);


  useEffect(() => {
    if (open) {
      wasOpen.current = true;
      setExiting(false);
      return undefined;
    }
    if (!wasOpen.current) return undefined;
    wasOpen.current = false;
    setExiting(true);
    const t = setTimeout(() => setExiting(false), 200);
    return () => clearTimeout(t);
  }, [open]);

  if (!visible || !mounted) return null;

  const enter = open;

  return createPortal(
    <div
      className={[
        "fixed inset-x-0 top-0 z-[100] flex h-[100dvh] justify-center",
        enter ? "" : "pointer-events-none",
      ].join(" ")}
    >
      {/* click-catcher over the app above the sheet */}
      <div className="absolute inset-0" onClick={onClose} aria-hidden />



      {/* floating card */}
      <div
        className="absolute inset-x-[10px] max-w-md"
        style={{ top: box?.top ?? "41dvh", height: box?.height ?? "59dvh" }}
      >


        <div
          role="dialog"
          aria-label={translateAttribute("Date range")}
          className={[
            "flex h-full flex-col overflow-hidden rounded-[26px] bg-white shadow-[0_18px_40px_-12px_rgba(0,0,0,0.35)]",
            enter ? "animate-sheet-up" : "animate-sheet-up-out",
          ].join(" ")}
        >

          {/* grab handle */}
          <div className="mx-auto mt-1.5 h-1 w-9 shrink-0 rounded-full bg-gray-300" />

          {/* header + top two rows */}
          <div className="shrink-0 px-5 pt-1.5">
            <h3 className="text-[20px] leading-tight font-bold text-gray-900"><AppText>
              Date range
            </AppText></h3>

            <button
              type="button"
              className="flex w-full items-center justify-between py-3 text-left"
            >
              <div className="flex items-center gap-3.5">
                <img
                  src={fixedDatesIcon.url}
                  alt=""
                  className="h-[20px] w-[20px] shrink-0 object-contain"
                />
                <div>
                  <div className="text-[16px] leading-tight text-gray-900"><AppText>
                    Fixed dates
                  </AppText></div>
                  <div className="mt-0 text-[12px] font-semibold text-gray-900"><AppText>
                    Sep 1
                  </AppText></div>
                </div>
              </div>
              <ChevronRight
                className="h-4 w-4 text-gray-400"
                strokeWidth={1.8}
              />
            </button>

            <button
              type="button"
              className="flex w-full items-center justify-between py-3 text-left"
            >
              <div className="flex items-center gap-3.5">
                <img
                  src={rollingPeriodIcon.url}
                  alt=""
                  className="h-[20px] w-[20px] shrink-0 object-contain"
                />
                <div>
                  <div className="text-[16px] leading-tight text-gray-900"><AppText>
                    Rolling period
                  </AppText></div>
                  <div className="mt-0 text-[12px] text-gray-500"><AppText>
                    Define a time period relative to today
                  </AppText></div>
                </div>
              </div>
              <ChevronRight
                className="h-4 w-4 text-gray-400"
                strokeWidth={1.8}
              />
            </button>
          </div>

          {/* separator band */}
          <div className="h-[9px] shrink-0 bg-[#f1f2f3]" />

          {/* quick ranges (no scrolling; the last row is clipped by design) */}
          <div className="relative min-h-0 flex-1 max-h-[308px]">
            <div className="h-full overflow-hidden">
              {quickRanges.map((range) => (
                <button
                  key={range.label}
                  type="button"
                  disabled={!range.id}
                  onClick={() => {
                    if (!range.id) return;
                    setRange(range.id);
                    onClose();
                  }}
                  className="flex w-full items-center justify-between border-b border-gray-200/80 px-6 py-[17px] text-left disabled:cursor-default"
                >
                  <span className="text-[17px] leading-tight text-gray-900">
                    <AppText>{range.label}</AppText>
                  </span>
                  {range.id === selected && (
                    <Check className="h-5 w-5 text-gray-900" strokeWidth={2} />
                  )}
                </button>
              ))}
            </div>

            {/* clean clip at the bottom edge */}
            <div className="pointer-events-none absolute inset-x-0 bottom-0 h-4 bg-gradient-to-b from-white/20 to-white" />
          </div>

        </div>
      </div>
    </div>,
    document.body
  );
}
