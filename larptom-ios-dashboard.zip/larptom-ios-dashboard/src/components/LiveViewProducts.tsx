import { useEffect, useState } from "react";
import { ImageIcon } from "lucide-react";
import { AppText, useAppLanguage, useAppTranslation } from "@/components/AppTranslation";
import { getStoredProducts, productPriceSchema, type StoredProduct } from "@/lib/products-store";
import { distributeLiveTotal, formatLiveNumber, type LiveViewData } from "@/lib/live-view-data";
import { LiveViewEmpty } from "@/components/LiveViewEmpty";

/** Saved local product references only; never paid sales or reporting. */
export function LiveViewProducts({ data, seed }: { data: LiveViewData; seed: number }) {
  const translate = useAppTranslation();
  const language = useAppLanguage();
  const [products, setProducts] = useState<StoredProduct[]>([]);
  useEffect(() => {
    const update = () => setProducts(getStoredProducts());
    update();
    window.addEventListener("products-updated", update);
    window.addEventListener("storage", update);
    return () => {
      window.removeEventListener("products-updated", update);
      window.removeEventListener("storage", update);
    };
  }, []);
  const sales = distributeLiveTotal(Math.round(data.totalSales * 100), products.length, seed + products.reduce((sum, product) => sum + (productPriceSchema.safeParse(product.price).success ? Math.round((product.price ?? 0) * 100) : 0), 0));
  return (
    <section className="live-metric-card live-products" aria-label={translate("Total sales by product")}>
      <div className="live-metric-heading"><h2><AppText>Total sales by product</AppText></h2></div>
      {products.length === 0 || data.totalSales === 0 ? <LiveViewEmpty /> : (
        <ul className="live-product-list">
          {products.map((product, index) => {
            return <li key={product.id}>
              <div className="live-product-image">{product.image ? <img src={product.image} alt={product.title} /> : <ImageIcon size={16} aria-hidden="true" />}</div>
              <span className="live-product-title">{product.title}</span>
              <strong>{formatLiveNumber((sales[index] ?? 0) / 100, true, language)}</strong>
            </li>;
          })}
        </ul>
      )}
    </section>
  );
}