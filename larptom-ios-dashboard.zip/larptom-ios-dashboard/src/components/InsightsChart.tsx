import { AppText, useAppLanguage } from "@/components/AppTranslation";
import { ComposedChart, Line, ReferenceDot, ReferenceLine, ResponsiveContainer, XAxis, YAxis } from "recharts";
import { useMemo, useState } from "react";

type Pt = { usd: number; paidAt: string };
type Range = "today" | "yesterday" | "7d" | "30d" | "365d";
const RANGES: { id: Range; label: string }[] = [
  { id: "today", label: "Today" },
  { id: "yesterday", label: "Yesterday" },
  { id: "7d", label: "7 days" },
  { id: "30d", label: "30 days" },
  { id: "365d", label: "365 days" },
];
const usd = (n: number) => `$${n.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

function buckets(range: Range, language: string) {
  const now = new Date();
  const out: { start: number; end: number; label: string }[] = [];
  if (range === "today" || range === "yesterday") {
    const d = new Date(now);
    d.setHours(0, 0, 0, 0);
    if (range === "yesterday") d.setDate(d.getDate() - 1);
    for (let h = 0; h < 24; h++) {
      const s = new Date(d); s.setHours(h);
      const e = new Date(d); e.setHours(h + 1);
      out.push({ start: s.getTime(), end: e.getTime(), label: s.toLocaleTimeString(language, { hour: "numeric" }) });
    }
  } else if (range === "365d") {
    for (let i = 11; i >= 0; i--) {
      const s = new Date(now.getFullYear(), now.getMonth() - i, 1);
      const e = new Date(now.getFullYear(), now.getMonth() - i + 1, 1);
      out.push({ start: s.getTime(), end: e.getTime(), label: s.toLocaleDateString(language, { month: "short" }) });
    }
  } else {
    const n = range === "7d" ? 7 : 30;
    for (let i = n - 1; i >= 0; i--) {
      const s = new Date(now); s.setHours(0, 0, 0, 0); s.setDate(s.getDate() - i);
      const e = new Date(s); e.setDate(e.getDate() + 1);
      out.push({ start: s.getTime(), end: e.getTime(), label: s.toLocaleDateString(language, { month: "short", day: "numeric" }) });
    }
  }
  return out;
}

function shift(range: Range) {
  if (range === "today" || range === "yesterday") return 86400000;
  if (range === "7d") return 7 * 86400000;
  if (range === "30d") return 30 * 86400000;
  return 365 * 86400000;
}

const trimZero = (s: string) => s.replace(/\.0$/, "");
const fmtTick = (v: number) => (v >= 1000 ? `$${trimZero((v / 1000).toFixed(v >= 10000 ? 0 : 1))}K` : `$${Math.round(v)}`);

export function InsightsChart({ points }: { points: Pt[] }) {
  const language = useAppLanguage();
  const [range, setRange] = useState<Range>("7d");
  const [hover, setHover] = useState<number | null>(null);
  const data = useMemo(() => {
    const bs = buckets(range, language);
    const sh = shift(range);
    const ts = points.map((p) => ({ t: new Date(p.paidAt).getTime(), usd: p.usd }));
    const now = Date.now();
    return bs.map((b, i) => {
      const rows = ts.filter((p) => p.t >= b.start && p.t < b.end);
      const prev = ts.filter((p) => p.t >= b.start - sh && p.t < b.end - sh);
      return {
        i,
        label: b.label,
        current: b.start > now ? null : rows.reduce((s, r) => s + r.usd, 0),
        orders: rows.length,
        previous: prev.reduce((s, r) => s + r.usd, 0),
      };
    });
  }, [points, range, language]);
  const total = data.reduce((s, d) => s + (d.current ?? 0), 0);
  const orders = data.reduce((s, d) => s + d.orders, 0);
  const prevTotal = data.reduce((s, d) => s + d.previous, 0);
  const rawMax = Math.max(1, ...data.map((d) => Math.max(d.current ?? 0, d.previous)));
  const step = Math.pow(10, Math.floor(Math.log10(rawMax / 3)));
  const unit = [1, 2, 5, 10].map((m) => m * step).find((u) => u * 3 >= rawMax) ?? step * 10;
  const yTicks = [0, unit, unit * 2, unit * 3];
  const sel = hover !== null ? data[hover] : null;
  const pct = prevTotal ? ((total - prevTotal) / prevTotal) * 100 : null;
  const n = data.length - 1;

  return (
    <div className="mt-3 rounded-2xl border border-[#3c3c3c] bg-[#141414] py-4">
      <div className="flex gap-1.5 overflow-x-auto px-4 pb-1">
        {RANGES.map((r) => (
          <button
            key={r.id}
            type="button"
            onClick={() => setRange(r.id)}
            className={`flex h-8 shrink-0 items-center rounded-xl border px-3 text-[11px] whitespace-nowrap ${range === r.id ? "border-neutral-400 bg-[#262626] text-white" : "border-[#3c3c3c] bg-[#141414] text-neutral-300"}`}
          >
            <AppText>{r.label}</AppText>
          </button>
        ))}
      </div>
      <div className="px-4">
        <p className="mt-3 text-[12px] text-neutral-400"><AppText>{sel ? sel.label : "Total sales"}</AppText></p>
        <div className="flex items-baseline gap-2">
          <p className="text-insights-ink text-[24px] font-semibold tabular-nums">{usd(sel ? sel.current ?? 0 : total)}</p>
          {!sel && pct !== null && (
            <span className={`text-[12px] ${pct >= 0 ? "text-[#5bc0de]" : "text-neutral-400"}`}><AppText>
              {pct >= 0 ? "↑" : "↓"} {Math.abs(pct).toFixed(0)}%
            </AppText></span>
          )}
        </div>
        <p className="text-[11px] text-neutral-500"><AppText>
          {sel ? `${sel.orders} orders · previous ${usd(sel.previous)}` : `${orders} orders`}
        </AppText></p>
      </div>
      <div
        className="relative mt-2 h-40 touch-none select-none pr-4 pl-2"
        onPointerMove={(e) => {
          const r = e.currentTarget.getBoundingClientRect();
          const left = 42 + 8;
          const t = (e.clientX - r.left - left) / (r.width - left - 16 - 5);
          setHover(Math.max(0, Math.min(n, Math.round(t * n))));
        }}
        onPointerLeave={() => setHover(null)}
        onPointerUp={() => setHover(null)}
      >
        <ResponsiveContainer width="100%" height="100%">
          <ComposedChart data={data} margin={{ top: 5, right: 5, bottom: 0, left: 0 }}>
            {yTicks.map((t) => (
              <ReferenceLine key={t} y={t} stroke="#3c3c3c" strokeOpacity={0.8} />
            ))}
            <XAxis
              dataKey="i"
              type="number"
              domain={[0, Math.max(1, n)]}
              ticks={[0, Math.floor(n / 2), n]}
              tickFormatter={(v: number) => data[v]?.label ?? ""}
              tickLine={false}
              axisLine={false}
              tick={{ fill: "#9ca3af", fontSize: 10 }}
            />
            <YAxis
              domain={[0, unit * 3]}
              ticks={yTicks}
              interval={0}
              tickFormatter={fmtTick}
              tickLine={false}
              axisLine={false}
              width={42}
              tick={{ fill: "var(--color-insights-ink)", fontSize: 10 }}
            />
            <Line type="monotoneX" dataKey="previous" stroke="#5bc0de" strokeWidth={1.5} strokeDasharray="5 3" strokeOpacity={0.5} strokeLinecap="round" dot={false} isAnimationActive={false} />
            <Line type="monotoneX" dataKey="current" connectNulls={false} stroke="#5bc0de" strokeWidth={2} strokeLinecap="round" dot={false} animationDuration={600} />
            {hover !== null && <ReferenceLine x={hover} stroke="#9ca3af" strokeOpacity={0.6} />}
            {sel && hover !== null && sel.current !== null && <ReferenceDot x={hover} y={sel.current} r={5} fill="#5bc0de" stroke="none" />}
          </ComposedChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}
