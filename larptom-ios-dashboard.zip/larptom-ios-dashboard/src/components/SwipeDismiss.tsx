import { useAppTranslation } from "@/components/AppTranslation";
import { AppText } from "@/components/AppTranslation";
import { useRef, useState, type ReactNode } from "react";

const REVEAL = 112;

/** Slide the card left to reveal a grey "Dismiss" pill on the right. */
export function SwipeDismiss({ children, onDismiss }: { children: ReactNode; onDismiss: () => void }) {
  const translateAttribute = useAppTranslation();
  const [x, setX] = useState(0);
  const [dragging, setDragging] = useState(false);
  const start = useRef<{ x: number; y: number; base: number; lock: "h" | "v" | null } | null>(null);

  return (
    <div className="relative overflow-hidden">
      <button
        type="button"
        onClick={onDismiss}
        className="absolute top-0 right-0 bottom-0 flex flex-col items-center justify-center gap-2 rounded-3xl bg-[#f6f6f6] text-gray-500"
        style={{ width: REVEAL - 12, opacity: Math.min(1, -x / 60) }}
        aria-label={translateAttribute("Dismiss")}
      >
        <svg width="18" height="18" viewBox="0 0 18 18" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round">
          <path d="M3 3l12 12M15 3L3 15" />
        </svg>
        <span className="text-[15px]"><AppText>Dismiss</AppText></span>
      </button>
      <div
        data-no-pull
        style={{
          transform: `translateX(${x}px)`,
          transition: dragging ? "none" : "transform 280ms cubic-bezier(0.2,0.8,0.2,1)",
          touchAction: "pan-y",
        }}
        onTouchStart={(e) => {
          const t = e.touches[0]!;
          start.current = { x: t.clientX, y: t.clientY, base: x, lock: null };
        }}
        onTouchMove={(e) => {
          const s = start.current;
          if (!s) return;
          const t = e.touches[0]!;
          const dx = t.clientX - s.x;
          const dy = t.clientY - s.y;
          if (!s.lock && (Math.abs(dx) > 6 || Math.abs(dy) > 6)) s.lock = Math.abs(dx) > Math.abs(dy) ? "h" : "v";
          if (s.lock !== "h") return;
          e.stopPropagation();
          setDragging(true);
          let next = s.base + dx;
          if (next > 0) next = next * 0.2;
          if (next < -REVEAL) next = -REVEAL + (next + REVEAL) * 0.3;
          setX(next);
        }}
        onTouchEnd={() => {
          start.current = null;
          setDragging(false);
          setX((v) => (v < -REVEAL / 2 ? -REVEAL : 0));
        }}
        onTouchCancel={() => {
          start.current = null;
          setDragging(false);
          setX(0);
        }}
      >
        {children}
      </div>
    </div>
  );
}
