import larptomBag from "@/assets/larptom-bag.png.asset.json";

export const SWATCHES = [
  "#ef4444",
  "#f97316",
  "#eab308",
  "#22c55e",
  "#34d399",
  "#14b8a6",
  "#06b6d4",
  "#3b82f6",
  "#6366f1",
  "#8b5cf6",
  "#a855f7",
  "#d946ef",
  "#ec4899",
  "#f43f5e",
  "#ffffff",
  "#000000",
  "#6b7280",
  "#475569",
] as const;

export type AvatarSettings = {
  initials: string;
  background: string;
  textColor: string;
  image: string | null;
  mode: "image" | "color";
};

export const DEFAULT_AVATAR: AvatarSettings = {
  initials: "LA",
  background: "#000000",
  textColor: "#ffffff",
  image: larptomBag.url,
  mode: "image",
};
