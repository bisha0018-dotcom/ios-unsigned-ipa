import { useAppTranslation } from "@/components/AppTranslation";
import { AppText } from "@/components/AppTranslation";
import { useEffect, useState } from "react";
import { useCurrency, withCurrency } from "@/lib/currency";
import { onStoreChange, readStore, writeStore } from "@/lib/app-store";
import { SwipeDismiss } from "@/components/SwipeDismiss";
import payoutsIcon from "@/assets/payouts-icon.png.asset.json";
import fulfillIcon from "@/assets/icon-orders-fulfill.png.asset.json";
import captureIcon from "@/assets/icon-payments-capture.png.asset.json";
import returnsIcon from "@/assets/icon-return-requests.png.asset.json";
import highRiskIcon from "@/assets/icon-high-risk.png.asset.json";
import chargebacksIcon from "@/assets/icon-chargebacks.png.asset.json";
import blockIcon from "@/assets/icon-orders-block.png.asset.json";
import editionsBanner from "@/assets/shopify-editions-banner.png.asset.json";
import shopStoreImg from "@/assets/shop-store.png.asset.json";
import partnersImg from "@/assets/shopify-partners.png.asset.json";
import simGymImg from "@/assets/simgym-robot.png.asset.json";
import euPackageImg from "@/assets/eu-package-return.png.asset.json";
import thatsItCardImg from "@/assets/thats-it-for-now-card.png.asset.json";
import communityImg from "@/assets/community-peer-advice.png.asset.json";

type ActivityCard = {
  id: string;
  label: string;
  alt: string;
  icon: string;
  prefix?: string;
  defaultValue: string;
};

const CARDS: ActivityCard[] = [
  { id: "payouts", label: "Payouts today", alt: "Payouts", icon: payoutsIcon.url, prefix: "€", defaultValue: "1250" },
  { id: "fulfill", label: "Fulfill orders", alt: "Orders", icon: fulfillIcon.url, defaultValue: "50" },
  { id: "capture", label: "Capture payments", alt: "Payments", icon: captureIcon.url, defaultValue: "8" },
  { id: "returns", label: "Return requests", alt: "Returns", icon: returnsIcon.url, defaultValue: "2" },
  { id: "highrisk", label: "High risk orders", alt: "High Risk", icon: highRiskIcon.url, defaultValue: "3" },
  { id: "chargebacks", label: "Chargebacks", alt: "Chargebacks", icon: chargebacksIcon.url, defaultValue: "5" },
  { id: "block", label: "Orders with block...", alt: "Orders Block", icon: blockIcon.url, defaultValue: "1" },
];

type Promo = {
  id: string;
  label: string;
  title: string;
  lines: string[];
  cta: string;
  image: string;
  imageWidth: number;
  learnMore: boolean;
  banner?: boolean;
  tilted?: boolean;
};

const PROMOS: Promo[] = [
  {
    id: "editions",
    label: "Shopify Editions",
    title: "",
    lines: [],
    cta: "",
    image: editionsBanner.url,
    imageWidth: 0,
    learnMore: false,
    banner: true,
  },
  {
    id: "community",
    label: "Community",
    title: "Turn social traffic into orders with peer advice",
    lines: ["Share your store in Community and ask what to improve."],
    cta: "Post your store",
    image: communityImg.url,
    imageWidth: 270,
    learnMore: false,
    tilted: true,
  },


  {
    id: "shopstore",
    label: "Shop Store",
    title: "Showcase your brand on the Shop app",
    lines: ["Add a branded header and featured collections", "to boost sales."],
    cta: "Customize Shop Store",
    image: shopStoreImg.url,
    imageWidth: 176,
    learnMore: true,
  },
  {
    id: "partners",
    label: "Shopify Partners",
    title: "Grow your business with Shopify Partners",
    lines: ["Connect with skilled professionals to accelerate", "your growth."],
    cta: "Find a Partner",
    image: partnersImg.url,
    imageWidth: 176,
    learnMore: false,
  },
  {
    id: "simgym",
    label: "SimGym",
    title: "Test your changes with AI shoppers",
    lines: ["Find friction and drop-off points to guide", "storefront improvements."],
    cta: "Install SimGym",
    image: simGymImg.url,
    imageWidth: 240,
    learnMore: true,
  },
  {
    id: "euwithdrawal",
    label: "EU Withdrawal Rules",
    title: "Updated EU withdrawal rules apply June 19",
    lines: [
      "Give EU buyers a way to cancel or return orders",
      "from your online store, up to 14 days after",
      "delivery.",
    ],
    cta: "Learn more",
    image: euPackageImg.url,
    imageWidth: 160,
    learnMore: false,
  },
];

const PROMO_ORDER_KEY = "bisha.promos.order";
const PROMO_HIDDEN_KEY = "bisha.promos.hidden";

/** Format a raw digit/decimal string with thousand separators (1250 -> 1,250). */
function formatAmount(raw: string) {
  const cleaned = raw.replace(/[^\d.,]/g, "").replace(",", ".");
  if (cleaned === "") return "";
  const [intPart, decPart] = cleaned.split(".");
  const withSeps = (intPart ?? "").replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  return decPart !== undefined ? `${withSeps}.${decPart}` : withSeps;
}

function EditableAmount({
  storageKey,
  defaultValue,
  prefix,
}: {
  storageKey: string;
  defaultValue: string;
  prefix?: string | undefined;
}) {
  const [value, setValue] = useState(defaultValue);
  const currency = useCurrency();

  useEffect(() => {
    const sync = () => {
      const stored = localStorage.getItem(storageKey);
      setValue(stored !== null ? stored : defaultValue);
    };
    sync();
    return onStoreChange(sync);
  }, [storageKey, defaultValue]);

  return (
    <div className="text-[11px] leading-none font-semibold text-gray-900">
      {withCurrency(prefix, currency)}
      {formatAmount(value)}
    </div>
  );
}

const VISIBILITY_KEY = "bisha.activity.visibility";

/** White activity sheet with rounded top corners and a swipeable activity row. */
export function ActivitySection() {
  const translateAttribute = useAppTranslation();
  const [promoOrder, setPromoOrder] = useState<string[]>(PROMOS.map((p) => p.id));
  const [promoHidden, setPromoHidden] = useState<Record<string, boolean>>({});

  useEffect(() => {
    const sync = () => {
    const o = localStorage.getItem(PROMO_ORDER_KEY);
    if (o) {
      try {
        const parsed = JSON.parse(o) as string[];
        const valid = parsed.filter((id) => PROMOS.some((p) => p.id === id));
        const missing = PROMOS.map((p) => p.id).filter((id) => !valid.includes(id));
        setPromoOrder([...valid, ...missing]);
      } catch {
        /* ignore */
      }
    }
    const h = localStorage.getItem(PROMO_HIDDEN_KEY);
    if (h) {
      try {
        setPromoHidden(JSON.parse(h) as Record<string, boolean>);
      } catch {
        /* ignore */
      }
    }
    };
    sync();
    return onStoreChange(sync);
  }, []);

  const [visible, setVisible] = useState<Record<string, boolean>>(() =>
    Object.fromEntries(CARDS.map((c) => [c.id, true])),
  );

  useEffect(() => {
    const sync = () => {
    const stored = localStorage.getItem(VISIBILITY_KEY);
    if (stored) {
      try {
        const parsed = JSON.parse(stored) as Record<string, boolean>;
        setVisible((prev) => ({ ...prev, ...parsed }));
      } catch {
        /* ignore malformed state */
      }
    }
    };
    sync();
    return onStoreChange(sync);
  }, []);

  const dismissPromo = (id: string) => {
    let current: Record<string, boolean> = {};
    try {
      current = JSON.parse(readStore(PROMO_HIDDEN_KEY, "{}")) as Record<string, boolean>;
    } catch {
      /* ignore malformed state */
    }
    writeStore(PROMO_HIDDEN_KEY, JSON.stringify({ ...current, [id]: true }));
  };

  const shown = CARDS.filter((card) => visible[card.id] ?? true);
  const single = shown.length === 1;
  const even = shown.length === 2 || shown.length === 3;

  return (
    <div id="activity-white-section" className="relative z-10 flex flex-col flex-grow rounded-t-[2rem] bg-white text-gray-900">
      <h2 className="cursor-pointer pt-6 pr-4 pb-5 pl-4 text-left text-xl font-medium text-gray-900">
        <span className="text-gray-500"><AppText>Hey there!</AppText></span><AppText> Here is your activity
      </AppText></h2>

      <div className="flex max-w-full min-w-0 flex-grow flex-col overflow-x-hidden bg-white pb-16">
        {single && shown[0] ? (
          <div className="bg-white px-3 pb-0">
            <div className="flex w-full items-center gap-2 rounded-xl border border-gray-200 bg-white px-3 shadow-[0_2px_4px_rgba(0,0,0,0.06)]" style={{ height: 50 }}>
              <span className="flex-shrink-0 text-gray-400">
                <img src={shown[0].icon} alt={shown[0].alt} style={{ width: 16, height: 16 }} />
              </span>
              <span className="flex-1 truncate text-left text-[13px] text-gray-500">
                <AppText>{shown[0].label}</AppText>
              </span>
              <EditableAmount
                storageKey={`bisha.activity.${shown[0].id}`}
                defaultValue={shown[0].defaultValue}
                prefix={shown[0].prefix}
              />
              <span className="text-sm leading-none text-gray-400 select-none">›</span>
            </div>
          </div>
        ) : (
          <div
            className="horizontal-swipe-row flex w-full min-w-0 max-w-full gap-2 bg-white px-3 pb-0"
            style={{ overflow: "auto hidden", touchAction: "pan-x", scrollbarWidth: "none" }}
          >
            {shown.map((card) => (
              <div
                key={card.id}
                className={`flex flex-col justify-center gap-0.5 rounded-xl border border-gray-200 bg-white px-3 py-1.5 shadow-[0_2px_4px_rgba(0,0,0,0.06)] ${
                  even ? "min-w-0 flex-1" : "flex-shrink-0"
                }`}
                style={even ? { height: 50 } : { width: 112, height: 50 }}
              >
                <div className="truncate text-left text-[10px] leading-none whitespace-nowrap text-gray-500">
                  <AppText>{card.label}</AppText>
                </div>
                <div className="flex items-end justify-between">
                  <EditableAmount
                    storageKey={`bisha.activity.${card.id}`}
                    defaultValue={card.defaultValue}
                    prefix={card.prefix}
                  />
                   <span className="text-gray-400">
                    <img src={card.icon} alt={card.alt} style={{ width: 14, height: 14 }} />
                   </span>
                </div>
              </div>
            ))}
          </div>
        )}

        <div className="mt-6 px-3 pb-4 text-gray-600">
          {PROMOS.every((p) => promoHidden[p.id]) ? (
            <div className="-mt-3 block w-full">
              <img
                src={thatsItCardImg.url}
                alt={translateAttribute("That's it for now")}
                className="w-full rounded-2xl"
              />
            </div>
          ) : (
            promoOrder.map((id) => {
              const promo = PROMOS.find((p) => p.id === id);
              if (!promo || promoHidden[id]) return null;
              if (promo.banner) {
                return (
                  <div key={id} className="-mt-3 mb-3">
                    <SwipeDismiss onDismiss={() => dismissPromo(id)}>
                      <img
                        src={promo.image}
                        alt={translateAttribute("Shopify Editions Spring '26 - 150+ updates")}
                         className="block h-auto w-full rounded-2xl"
                      />
                    </SwipeDismiss>
                  </div>
                );
              }
              return (
                <div key={id}>
                  <SwipeDismiss onDismiss={() => dismissPromo(id)}>
                    <div className={`relative overflow-hidden rounded-3xl border border-gray-200 bg-white p-5 pb-20 shadow-[0_2px_12px_rgba(0,0,0,0.08)] ${promo.tilted ? "min-h-[320px]" : "min-h-[260px]"}`}>
                      <button
                        type="button"
                        aria-label="Dismiss card"
                        onClick={() => dismissPromo(id)}
                        onPointerDown={(e) => e.stopPropagation()}
                        className="absolute top-4 right-4 z-20 flex h-6 w-6 items-center justify-center rounded-md text-gray-500 hover:bg-gray-100"
                      >
                        <svg viewBox="0 0 20 20" width="18" height="18" fill="currentColor" aria-hidden="true">
                          <path d="M13.97 15.03a.75.75 0 1 0 1.06-1.06l-3.97-3.97 3.97-3.97a.75.75 0 0 0-1.06-1.06l-3.97 3.97-3.97-3.97a.75.75 0 0 0-1.06 1.06l3.97 3.97-3.97 3.97a.75.75 0 1 0 1.06 1.06l3.97-3.97 3.97 3.97Z" />
                        </svg>
                      </button>
                      <h2 className="mb-2 pr-8 text-left text-[15px] leading-tight font-bold text-gray-900">
                        <AppText>{promo.title}</AppText>
                      </h2>
                      <p className="mb-2 pr-6 text-left text-[14px] leading-snug text-gray-700">
                        {promo.lines.map((line, i) => (
                          <span key={i}>
                            <AppText>{line}</AppText>
                            {i < promo.lines.length - 1 && <br />}
                          </span>
                        ))}
                      </p>
                      {promo.learnMore && (
                        <span className="text-[14px] font-medium text-[#2563eb]"><AppText>
                          Learn more
                        </AppText></span>
                      )}
                      {promo.tilted ? (
                        <img
                          src={promo.image}
                          alt={promo.label}
                          style={{ width: promo.imageWidth, transform: "rotate(-3deg)", transformOrigin: "bottom right", right: -14, bottom: -10 }}
                          className="absolute h-auto rounded-xl select-none"
                        />
                      ) : (
                      <img
                        src={promo.image}
                        alt={promo.label}
                        style={{ width: promo.imageWidth }}
                         className="absolute right-0 bottom-0 h-auto select-none"
                      />
                      )}
                       <span className="absolute bottom-4 left-4 rounded-full border border-gray-200 bg-white px-4 py-2 text-[13px] font-semibold text-gray-800 shadow-[0_2px_8px_rgba(0,0,0,0.12)]">
                        <AppText>{promo.cta}</AppText>
                       </span>
                    </div>
                  </SwipeDismiss>
                  <div className="h-4" />
                </div>
              );
            })
          )}


        </div>
      </div>

    </div>
  );
}
