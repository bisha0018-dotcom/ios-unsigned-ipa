import { AppText } from "@/components/AppTranslation";
import { useAppTranslation } from "@/components/AppTranslation";
import { BottomSheet } from "@/components/BottomSheet";
import { Switch } from "@/components/ui/switch";

export type VisibilityItem = { id: string; label: string; alt: string; icon: string };

export function VisibilityDialog({
  open,
  onOpenChange,
  items,
  visible,
  onToggle,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  items: VisibilityItem[];
  visible: Record<string, boolean>;
  onToggle: (id: string, next: boolean) => void;
}) {
  const translateAttribute = useAppTranslation();
  return (
    <BottomSheet
      open={open}
      onClose={() => onOpenChange(false)}
      title={translateAttribute("Adjust visibility")}
      subtitle="Choose which boxes should be displayed"
    >
      <div className="mt-4 max-h-[60vh] overflow-y-auto px-5">
        {items.map((item) => (
          <div key={item.id} className="flex items-center gap-3 py-3">
            <img
              src={item.icon}
              alt={item.alt}
              style={{ width: 16, height: 16 }}
              className="flex-shrink-0 opacity-60"
            />
            <span className="flex-1 truncate text-[15px] text-gray-900"><AppText>{item.label}</AppText></span>
            <Switch
              checked={visible[item.id] ?? true}
              onCheckedChange={(next) => onToggle(item.id, next)}
              className="data-[state=checked]:bg-[#0f172a] data-[state=unchecked]:bg-gray-200"
            />
          </div>
        ))}
      </div>
    </BottomSheet>
  );
}
