import { useAppTranslation } from "@/components/AppTranslation";
import { AppText } from "@/components/AppTranslation";
import { useCallback, useEffect, useState } from "react";
import { createPortal } from "react-dom";
import { useServerFn } from "@tanstack/react-start";
import { ChevronLeft, Copy, ExternalLink, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";

import { InsightsChart } from "@/components/InsightsChart";
import {
  adminApproveAffiliate,
  adminDeleteAffiliate,
  adminListAffiliates,
  adminMarkAffiliatePaid,
  adminRejectAffiliate,
  applyAffiliate,
  getMyAffiliate,
  requestAffiliatePayout,
  saveUsdcAddress,
  type AdminAffiliate,
} from "@/lib/affiliate.functions";

const usd = (n: number) => `$${n.toFixed(2)}`;
const errMsg = (e: unknown) => (e instanceof Error ? e.message : "Something went wrong.");

function Shell({ title, subtitle, onClose, children }: { title: string; subtitle: string; onClose: () => void; children: React.ReactNode }) {
  const translateAttribute = useAppTranslation();
  return createPortal(
    <div className="fixed inset-0 z-[210] flex flex-col bg-black">
      <div className="shrink-0 px-4 pt-[max(env(safe-area-inset-top),12px)] pb-4">
        <div className="flex items-center gap-3">
          <button type="button" onClick={onClose} aria-label={translateAttribute("Back")} className="-ml-2 flex h-9 w-9 items-center justify-center rounded-full text-white active:opacity-60">
            <ChevronLeft className="h-6 w-6" />
          </button>
          <div className="min-w-0">
            <h1 className="truncate text-[20px] font-semibold text-white"><AppText>{title}</AppText></h1>
            <p className="truncate text-[12px] text-white/50"><AppText>{subtitle}</AppText></p>
          </div>
        </div>
      </div>
      <div className="min-h-0 flex-1 overflow-y-auto rounded-t-[22px] bg-white px-5 pt-5 pb-32 text-gray-900">{children}</div>
    </div>,
    document.body,
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-2xl bg-gray-50 px-3 py-3">
      <p className="text-[11px] font-semibold tracking-wide text-gray-500 uppercase"><AppText>{label}</AppText></p>
      <p className="mt-1 text-[18px] font-bold">{value}</p>
    </div>
  );
}

type Mine = Awaited<ReturnType<typeof getMyAffiliate>>;

/** Customer side: apply, then code, earnings chart, USDC address and payouts. */
export function AffiliatePanel({ open, onClose, licenseKey }: { open: boolean; onClose: () => void; licenseKey: string }) {
  const translateAttribute = useAppTranslation();
  const fetchMine = useServerFn(getMyAffiliate);
  const apply = useServerFn(applyAffiliate);
  const saveAddr = useServerFn(saveUsdcAddress);
  const payout = useServerFn(requestAffiliatePayout);
  const [me, setMe] = useState<Mine | null>(null);
  const [link, setLink] = useState("");
  const [addr, setAddr] = useState("");
  const [msg, setMsg] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [copied, setCopied] = useState(false);

  const load = useCallback(async () => {
    try {
      const r = await fetchMine({ data: { key: licenseKey } });
      setMe(r);
      if (r.status !== "none") setAddr(r.usdcAddress ?? "");
    } catch (e) {
      setMsg(errMsg(e));
    }
  }, [fetchMine, licenseKey]);

  useEffect(() => {
    if (open) void load();
  }, [open, load]);

  const run = async (fn: () => Promise<unknown>, ok: string) => {
    setBusy(true);
    setMsg(null);
    try {
      await fn();
      setMsg(ok);
      await load();
    } catch (e) {
      setMsg(errMsg(e));
    } finally {
      setBusy(false);
    }
  };

  if (!open) return null;

  return (
    <Shell title={translateAttribute("Affiliate program")} subtitle="Earn 30% on every sale and renewal" onClose={onClose}>
      {!me && <p className="text-[14px] text-gray-500"><AppText>Loading…</AppText></p>}

      {me && (me.status === "none" || me.status === "rejected") && (
        <div>
          <div className="rounded-2xl bg-gray-50 p-4">
            <p className="text-[16px] font-semibold"><AppText>Become an affiliate</AppText></p>
            <ul className="mt-2 space-y-1 text-[13px] text-gray-600">
              <li><AppText>• Your own code gives buyers 20% off</AppText></li>
              <li><AppText>• You earn 30% of every purchase</AppText></li>
              <li><AppText>• Plus 30% of every renewal, forever</AppText></li>
              <li><AppText>• Paid in USDC (ERC20), $20 minimum</AppText></li>
            </ul>
          </div>
          {me.status === "rejected" && <p className="mt-3 text-[13px] text-red-600"><AppText>Your last application wasn't approved. You can apply again.</AppText></p>}
          <label className="mt-5 block text-[12px] font-semibold text-gray-500 uppercase">Your TikTok or Instagram link</label>
          <input value={link} onChange={(e) => setLink(e.target.value)} placeholder={translateAttribute("https://www.tiktok.com/@yourname")} className="mt-2 w-full rounded-xl border border-gray-200 bg-white px-3 py-3 text-[14px] outline-none" />
          <button type="button" disabled={busy || !link} onClick={() => run(() => apply({ data: { key: licenseKey, socialLink: link } }), "Application sent.")} className="mt-3 w-full rounded-xl bg-gray-900 py-3 text-[15px] font-semibold text-white disabled:opacity-40"><AppText>
            Apply
          </AppText></button>
        </div>
      )}

      {me?.status === "pending" && (
        <div className="rounded-2xl border border-amber-200 bg-amber-50 p-4">
          <p className="text-[15px] font-semibold text-amber-900"><AppText>Application under review</AppText></p>
          <p className="mt-1 text-[13px] break-all text-amber-800">{me.socialLink}</p>
          <p className="mt-2 text-[12px] text-amber-700"><AppText>You'll unlock your code here once approved.</AppText></p>
        </div>
      )}

      {me?.status === "approved" && (
        <div>
          {me.demo && <p className="mb-3 text-[13px] text-account-muted"><AppText>Test account · sample earnings · no real money</AppText></p>}
          <div className="rounded-2xl bg-gray-900 p-4 text-white">
            <p className="text-[11px] font-semibold tracking-wide text-white/60 uppercase"><AppText>Your code · 20% off for buyers</AppText></p>
            <div className="mt-1 flex items-center justify-between">
              <p className="font-mono text-[26px] font-bold">{me.code}</p>
              <button type="button" onClick={() => { void navigator.clipboard.writeText(me.code ?? ""); setCopied(true); setTimeout(() => setCopied(false), 1500); }} className="flex items-center gap-1 rounded-full bg-white/15 px-3 py-1.5 text-[12px] font-semibold">
                <Copy className="h-3.5 w-3.5" /><AppText> {copied ? "Copied" : "Copy"}
              </AppText></button>
            </div>
            <p className="mt-2 text-[12px] text-white/60"><AppText>Buyers enter it at checkout. You earn 30% on their purchase and every renewal.</AppText></p>
          </div>

          <div className="mt-4 grid grid-cols-2 gap-2">
            <Stat label="Total earned" value={usd(me.earnedUsd)} />
            <Stat label="Balance" value={usd(me.balanceUsd)} />
            <Stat label="Sales" value={String(me.sales)} />
            <Stat label="Renewals" value={String(me.renewals)} />
          </div>

          <div className="mt-5">
            <InsightsChart points={me.points} />
          </div>

          <div className="mt-6">
            <p className="text-[12px] font-semibold text-gray-500 uppercase"><AppText>USDC payout address (ERC20 only)</AppText></p>
            <input value={addr} onChange={(e) => setAddr(e.target.value)} placeholder={translateAttribute("0x…")} className="mt-2 w-full rounded-xl border border-gray-200 px-3 py-3 font-mono text-[13px] outline-none" />
            <button type="button" disabled={busy || !addr} onClick={() => run(() => saveAddr({ data: { key: licenseKey, address: addr } }), "Address saved.")} className="mt-2 w-full rounded-xl border border-gray-300 py-3 text-[14px] font-semibold disabled:opacity-40"><AppText>
              Save address
            </AppText></button>
          </div>

          <div className="mt-5 rounded-2xl bg-gray-50 p-4">
            <div className="flex justify-between text-[13px]">
              <span className="text-gray-500"><AppText>Withdrawable</AppText></span>
              <span className="font-semibold">{usd(me.balanceUsd)} / $20.00 min</span>
            </div>
            <div className="mt-2 h-2 overflow-hidden rounded-full bg-gray-200">
              <div className="h-full bg-gray-900" style={{ width: `${Math.min(100, (me.balanceUsd / 20) * 100)}%` }} />
            </div>
            {me.payoutRequestedAt ? (
              <p className="mt-3 text-[13px] font-semibold text-green-700"><AppText>{me.demo ? "Test payout requested — no funds will be sent." : "Payout requested — you'll be paid in USDC soon."}</AppText></p>
            ) : (
              <Button variant="account" type="button" disabled={busy || me.balanceUsd < 20} onClick={() => run(() => payout({ data: { key: licenseKey } }), me.demo ? "Test payout requested." : "Payout requested.")} className="mt-3 w-full"><AppText>
                {me.demo ? "Request test payout" : "Request payout"}
              </AppText></Button>
            )}
            <p className="mt-2 text-[12px] text-gray-500"><AppText>Paid out so far: {usd(me.paidOutUsd)}</AppText></p>
          </div>
        </div>
      )}

      {msg && <p className="mt-4 text-center text-[13px] text-gray-600">{msg}</p>}
    </Shell>
  );
}

/** Owner side: approve applications, assign codes, see earnings and pay out. */
export function AffiliateAdminPanel({ open, onClose, licenseKey }: { open: boolean; onClose: () => void; licenseKey: string }) {
  const translateAttribute = useAppTranslation();
  const list = useServerFn(adminListAffiliates);
  const approve = useServerFn(adminApproveAffiliate);
  const reject = useServerFn(adminRejectAffiliate);
  const markPaid = useServerFn(adminMarkAffiliatePaid);
  const deleteAffiliate = useServerFn(adminDeleteAffiliate);
  const [rows, setRows] = useState<AdminAffiliate[] | null>(null);
  const [codes, setCodes] = useState<Record<string, string>>({});
  const [msg, setMsg] = useState<string | null>(null);
  const [busy, setBusy] = useState<string | null>(null);
  const [tab, setTab] = useState<"pending" | "approved" | "rejected">("pending");

  const load = useCallback(async (sync = false) => {
    try {
      setRows(await list({ data: { key: licenseKey, sync } }));
    } catch (e) {
      setMsg(errMsg(e));
    }
  }, [list, licenseKey]);

  useEffect(() => {
    if (open) void load(true);
  }, [open, load]);

  const act = async (id: string, fn: () => Promise<unknown>) => {
    setBusy(id);
    setMsg(null);
    try {
      await fn();
      await load();
    } catch (e) {
      setMsg(errMsg(e));
    } finally {
      setBusy(null);
    }
  };

  if (!open) return null;
  const shown = (rows ?? []).filter((r) => r.status === tab);
  const count = (s: string) => (rows ?? []).filter((r) => r.status === s).length;
  const owed = (rows ?? []).reduce((s, r) => s + (r.status === "approved" && !r.demo ? r.balanceUsd : 0), 0);

  return (
    <Shell title={translateAttribute("Affiliates")} subtitle={`Owed in total: ${usd(owed)}`} onClose={onClose}>
      <div className="flex items-center gap-2">
        {(["pending", "approved", "rejected"] as const).map((t) => (
          <button key={t} type="button" onClick={() => setTab(t)} className={`rounded-full px-3.5 py-1.5 text-[13px] font-semibold capitalize ${tab === t ? "bg-gray-900 text-white" : "border border-gray-200 text-gray-700"}`}>
            {t} · {count(t)}
          </button>
        ))}
        <button type="button" onClick={() => void load(true)} className="ml-auto text-[12px] font-semibold underline"><AppText>Refresh</AppText></button>
      </div>
      {msg && <p className="mt-3 text-[13px] text-red-600">{msg}</p>}
      {!rows && <p className="mt-4 text-[14px] text-gray-500"><AppText>Loading…</AppText></p>}
      {rows && !shown.length && <p className="mt-6 text-center text-[14px] text-gray-500"><AppText>Nothing here yet.</AppText></p>}

      <div className="mt-4 space-y-3">
        {shown.map((r) => (
          <div key={r.id} className="rounded-2xl border border-gray-200 p-4">
            <div className="flex items-start justify-between gap-2">
              <div className="min-w-0">
                <p className="truncate text-[14px] font-semibold">{r.email ?? "No email"}</p>
                <p className="font-mono text-[11px] text-gray-500">{r.licenseKey}</p>
              </div>
              {r.code && <span className="rounded-full bg-gray-900 px-2.5 py-1 font-mono text-[12px] font-bold text-white">{r.code}</span>}
            </div>
            <a href={r.socialLink} target="_blank" rel="noreferrer" className="mt-2 flex items-center gap-1 text-[13px] break-all text-blue-600 underline">
              {r.socialLink} <ExternalLink className="h-3 w-3 shrink-0" />
            </a>

            {r.status === "pending" && (
              <div className="mt-3">
                <input value={codes[r.id] ?? ""} onChange={(e) => setCodes((c) => ({ ...c, [r.id]: e.target.value.toUpperCase().replace(/[^A-Z0-9]/g, "") }))} placeholder={translateAttribute("Coupon code e.g. ALEX20")} className="w-full rounded-xl border border-gray-200 px-3 py-2.5 font-mono text-[14px] outline-none" />
                <div className="mt-2 grid grid-cols-2 gap-2">
                  <button type="button" disabled={busy === r.id || (codes[r.id] ?? "").length < 3} onClick={() => act(r.id, () => approve({ data: { key: licenseKey, id: r.id, code: codes[r.id] ?? "" } }))} className="rounded-xl bg-gray-900 py-2.5 text-[14px] font-semibold text-white disabled:opacity-40"><AppText>
                    {busy === r.id ? "Approving…" : "Approve"}
                  </AppText></button>
                  <button type="button" disabled={busy === r.id} onClick={() => act(r.id, () => reject({ data: { key: licenseKey, id: r.id } }))} className="rounded-xl border border-gray-300 py-2.5 text-[14px] font-semibold"><AppText>
                    Reject
                  </AppText></button>
                </div>
              </div>
            )}

            {r.status === "approved" && (
              <div className="mt-3">
                {r.demo && <p className="mb-2 text-[12px] text-account-muted"><AppText>Test account · sample stats · excluded from total owed</AppText></p>}
                <div className="grid grid-cols-4 gap-1 text-center text-[11px]">
                  <div><p className="text-gray-500"><AppText>Earned</AppText></p><p className="font-bold">{usd(r.earnedUsd)}</p></div>
                  <div><p className="text-gray-500"><AppText>Owed</AppText></p><p className="font-bold">{usd(r.balanceUsd)}</p></div>
                  <div><p className="text-gray-500"><AppText>Sales</AppText></p><p className="font-bold">{r.sales}</p></div>
                  <div><p className="text-gray-500"><AppText>Renewals</AppText></p><p className="font-bold">{r.renewals}</p></div>
                </div>
                <div className="mt-3 rounded-xl bg-gray-50 px-3 py-2">
                  <p className="text-[11px] text-gray-500"><AppText>USDC (ERC20)</AppText></p>
                  {r.usdcAddress ? (
                    <button type="button" onClick={() => void navigator.clipboard.writeText(r.usdcAddress ?? "")} className="flex w-full items-center gap-1 text-left font-mono text-[12px] break-all">
                      {r.usdcAddress} <Copy className="h-3 w-3 shrink-0" />
                    </button>
                  ) : (
                    <p className="text-[12px] text-gray-400"><AppText>Not added yet</AppText></p>
                  )}
                </div>
                {r.payoutRequestedAt && <p className="mt-2 text-[12px] font-semibold text-amber-700"><AppText>{r.demo ? "Test payout requested" : "Payout requested"} {new Date(r.payoutRequestedAt).toLocaleDateString()}</AppText></p>}
                <Button variant="account" type="button" disabled={busy === r.id || r.balanceUsd <= 0} onClick={() => { if (window.confirm(r.demo ? `Record a test payout of ${usd(r.balanceUsd)}? No real funds or commissions are affected.` : `Mark ${usd(r.balanceUsd)} as paid to ${r.code}?`)) void act(r.id, () => markPaid({ data: { key: licenseKey, id: r.id } })); }} className="mt-2 w-full"><AppText>
                  {r.demo ? `Mark test ${usd(r.balanceUsd)} paid` : `Mark ${usd(r.balanceUsd)} paid`}
                </AppText></Button>
                <p className="mt-2 text-[12px] text-account-muted"><AppText>{r.demo ? "Test paid so far" : "Paid so far"}: {usd(r.paidOutUsd)}</AppText></p>
              </div>
            )}

            <Button type="button" variant="ghost" size="sm" disabled={busy === r.id}
              onClick={() => {
                if (window.confirm(`Delete this affiliate and reset them to the application screen? This disables their code and permanently clears their affiliate earnings and payout history. Their app license stays active.`)) {
                  void act(r.id, () => deleteAffiliate({ data: { key: licenseKey, id: r.id } }));
                }
              }}
              className="mt-3 text-account-logout hover:bg-account-hover hover:text-account-logout">
              <Trash2 /><AppText> Delete affiliate
            </AppText></Button>
          </div>
        ))}
      </div>
    </Shell>
  );
}
