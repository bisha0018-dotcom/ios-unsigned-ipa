import { useAppTranslation } from "@/components/AppTranslation";
import { AppText } from "@/components/AppTranslation";
import { useEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { useServerFn } from "@tanstack/react-start";
import { ChevronLeft } from "lucide-react";

import { getRevenueInsights, type RevenueInsights } from "@/lib/checkout.functions";
import { InsightsChart } from "@/components/InsightsChart";

const usd = (n: number) => `$${n.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

/** Owner-only revenue insights; polls every 5s so new paid orders show up live. */
export function InsightsPanel({ open, onClose, licenseKey }: { open: boolean; onClose: () => void; licenseKey: string }) {
  const translateAttribute = useAppTranslation();
  const fetchInsights = useServerFn(getRevenueInsights);
  const [data, setData] = useState<RevenueInsights | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [flash, setFlash] = useState(false);
  const [live, setLive] = useState(false);
  const lastCount = useRef<number | null>(null);

  useEffect(() => {
    if (!open) return;
    let active = true;
    const load = async () => {
      try {
        const res = await fetchInsights({ data: { key: licenseKey } });
        if (!active) return;
        if (lastCount.current !== null && res.orders > lastCount.current) {
          setFlash(true);
          window.setTimeout(() => setFlash(false), 1500);
        }
        lastCount.current = res.orders;
        setData(res);
        setError(null);
      } catch (e) {
        if (active) setError(e instanceof Error ? e.message : "Could not load insights.");
      }
    };
    void load();
    const id = window.setInterval(load, 5000);
    return () => {
      active = false;
      window.clearInterval(id);
    };
  }, [open, licenseKey, fetchInsights]);

  if (!open) return null;
  return createPortal(
    <div className="fixed inset-0 z-[220] flex flex-col bg-black text-white">
      <div className="flex shrink-0 items-center gap-3 px-4 pt-[max(env(safe-area-inset-top),12px)] pb-4">
        <button type="button" onClick={onClose} aria-label={translateAttribute("Back")} className="-ml-2 flex h-9 w-9 items-center justify-center rounded-full active:opacity-60">
          <ChevronLeft className="h-6 w-6" />
        </button>
        <h1 className="text-[20px] font-bold"><AppText>{live ? "Live view" : "Insights"}</AppText></h1>
        <button
          type="button"
          onClick={() => setLive((v) => !v)}
          aria-pressed={live}
          className={`ml-auto flex items-center gap-1.5 rounded-full border px-3 py-1.5 text-[12px] font-semibold transition-colors active:scale-[0.97] ${live ? "border-green-500 bg-green-500/15 text-green-400" : "border-white/15 text-white/70"}`}
        >
          <span className="h-2 w-2 animate-pulse rounded-full bg-green-500" /><AppText> {live ? "All time" : "Live"}
        </AppText></button>
      </div>
      <div className="flex-1 overflow-y-auto px-5 pb-10">
        {error && <p className="mb-3 text-[13px] text-red-500">{error}</p>}
        {!data ? (
          <p className="text-white/60"><AppText>Loading…</AppText></p>
        ) : live ? (
          <LiveToday data={data} flash={flash} />
        ) : (
          <>
            <div className={`rounded-2xl border border-white/10 p-5 transition-colors ${flash ? "bg-green-500/20" : "bg-white/5"}`}>
              <p className="text-[12px] text-white/60 uppercase"><AppText>Total earned</AppText></p>
              <p className="mt-1 text-[34px] font-bold tabular-nums">{usd(data.totalUsd)}</p>
              <div className="mt-3 flex gap-6 text-[13px] text-white/70">
                <span><AppText>{data.orders} paid orders</AppText></span>
                <span><AppText>Today {usd(data.todayUsd)}</AppText></span>
              </div>
            </div>
            <div className="mt-3 grid grid-cols-2 gap-3">
              <div className="rounded-2xl border border-white/10 bg-white/5 p-4">
                <p className="text-[11px] text-white/60 uppercase"><AppText>New sales</AppText></p>
                <p className="mt-1 text-[20px] font-bold tabular-nums">{usd(data.newUsd)}</p>
                <p className="text-[12px] text-white/50">{data.newOrders} orders</p>
              </div>
              <div className="rounded-2xl border border-white/10 bg-white/5 p-4">
                <p className="text-[11px] text-white/60 uppercase"><AppText>Renewals</AppText></p>
                <p className="mt-1 text-[20px] font-bold tabular-nums">{usd(data.renewalUsd)}</p>
                <p className="text-[12px] text-white/50"><AppText>{data.renewalOrders} renewals · today {usd(data.renewalTodayUsd)}</AppText></p>
              </div>
            </div>
            <InsightsChart points={data.points ?? []} />
            <SubsAndMonths data={data} />
            <p className="mt-6 mb-2 text-[11px] font-semibold text-white/50 uppercase"><AppText>By product</AppText></p>
            <div className="divide-y divide-white/10 rounded-2xl border border-white/10 bg-white/5">
              {data.byPlan.map((p) => (
                <div key={p.plan} className="flex items-center justify-between px-4 py-3.5">
                  <div>
                    <p className="text-[15px] font-semibold capitalize">{p.plan}</p>
                    <p className="text-[12px] text-white/50"><AppText>
                      {p.orders} orders{p.plan !== "lifetime" ? ` · ${p.renewals} renewals (${usd(p.renewalUsd)})` : ""}
                    </AppText></p>
                  </div>
                  <p className="text-[16px] font-semibold tabular-nums">{usd(p.usd)}</p>
                </div>
              ))}
            </div>
            <p className="mt-6 mb-2 text-[11px] font-semibold text-white/50 uppercase"><AppText>Latest orders</AppText></p>
            <div className="divide-y divide-white/10 rounded-2xl border border-white/10 bg-white/5">
              {data.latest.length === 0 && <p className="px-4 py-3.5 text-[13px] text-white/50"><AppText>No paid orders yet.</AppText></p>}
              {data.latest.map((o, i) => (
                <div key={i} className="flex items-center justify-between px-4 py-3">
                  <div>
                    <p className="text-[14px] font-medium capitalize"><AppText>{o.plan} · {o.renewal ? "renewal" : o.source}</AppText></p>
                    <p className="text-[12px] text-white/50">{new Date(o.paidAt).toLocaleString()}</p>
                  </div>
                  <p className="text-[14px] font-semibold tabular-nums">{usd(o.usd)}</p>
                </div>
              ))}
            </div>
          </>
        )}
      </div>
    </div>,
    document.body,
  );
}

function LiveToday({ data, flash }: { data: RevenueInsights; flash: boolean }) {
  const today = data.today ?? [];
  const revenue = today.reduce((s, r) => s + r.usd, 0);
  const renewals = today.filter((r) => r.renewal);
  const newOnes = today.filter((r) => !r.renewal);
  const avg = today.length ? revenue / today.length : 0;
  const last = today[0];
  const card = "rounded-2xl border border-white/10 bg-white/5 p-4";
  return (
    <>
      <p className="mb-3 text-[12px] text-white/50"><AppText>
        Today since midnight (UTC) · updates every 5 seconds
      </AppText></p>
      <div className="grid grid-cols-2 gap-3">
        <div className={`${card} transition-colors ${flash ? "bg-green-500/20" : ""}`}>
          <p className="text-[11px] text-white/60 uppercase"><AppText>Total revenue</AppText></p>
          <p className="mt-1 text-[22px] font-bold tabular-nums">{usd(revenue)}</p>
        </div>
        <div className={card}>
          <p className="text-[11px] text-white/60 uppercase"><AppText>Total orders</AppText></p>
          <p className="mt-1 text-[22px] font-bold tabular-nums">{today.length}</p>
        </div>
        <div className={card}>
          <p className="text-[11px] text-white/60 uppercase"><AppText>New sales</AppText></p>
          <p className="mt-1 text-[18px] font-bold tabular-nums">{usd(newOnes.reduce((s, r) => s + r.usd, 0))}</p>
          <p className="text-[12px] text-white/50">{newOnes.length} orders</p>
        </div>
        <div className={card}>
          <p className="text-[11px] text-white/60 uppercase"><AppText>Renewals</AppText></p>
          <p className="mt-1 text-[18px] font-bold tabular-nums">{usd(renewals.reduce((s, r) => s + r.usd, 0))}</p>
          <p className="text-[12px] text-white/50">{renewals.length} renewals</p>
        </div>
        <div className={card}>
          <p className="text-[11px] text-white/60 uppercase"><AppText>Avg order</AppText></p>
          <p className="mt-1 text-[18px] font-bold tabular-nums">{usd(avg)}</p>
        </div>
        <div className={card}>
          <p className="text-[11px] text-white/60 uppercase"><AppText>Last sale</AppText></p>
          <p className="mt-1 text-[18px] font-bold tabular-nums"><AppText>
            {last ? new Date(last.paidAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }) : "—"}
          </AppText></p>
        </div>
      </div>
      <p className="mt-6 mb-2 text-[11px] font-semibold text-white/50 uppercase"><AppText>Today by product</AppText></p>
      <div className="space-y-3 rounded-2xl border border-white/10 bg-white/5 p-4">
        {["weekly", "monthly", "lifetime"].map((plan) => {
          const rows = today.filter((r) => r.plan === plan);
          const amt = rows.reduce((s, r) => s + r.usd, 0);
          const pct = revenue ? (amt / revenue) * 100 : 0;
          return (
            <div key={plan}>
              <div className="flex justify-between text-[13px]">
                <span className="font-semibold capitalize">{plan}</span>
                <span className="text-white/60 tabular-nums">{rows.length} · {usd(amt)}</span>
              </div>
              <div className="mt-1.5 h-1.5 overflow-hidden rounded-full bg-white/10">
                <div className="h-full rounded-full bg-green-500 transition-all" style={{ width: `${pct}%` }} />
              </div>
            </div>
          );
        })}
      </div>
      <p className="mt-6 mb-2 text-[11px] font-semibold text-white/50 uppercase"><AppText>Today's orders</AppText></p>
      <div className="divide-y divide-white/10 rounded-2xl border border-white/10 bg-white/5">
        {today.length === 0 && <p className="px-4 py-3.5 text-[13px] text-white/50"><AppText>No orders yet today.</AppText></p>}
        {today.map((o, i) => (
          <div key={i} className="flex items-center justify-between px-4 py-3">
            <div>
              <p className="text-[14px] font-medium capitalize"><AppText>{o.plan} · {o.renewal ? "renewal" : o.source}</AppText></p>
              <p className="text-[12px] text-white/50">{new Date(o.paidAt).toLocaleTimeString()}</p>
            </div>
            <p className="text-[14px] font-semibold tabular-nums">{usd(o.usd)}</p>
          </div>
        ))}
      </div>
    </>
  );
}

function SubsAndMonths({ data }: { data: RevenueInsights }) {
  const subs = data.subs;
  const monthName = (m: string) =>
    new Date(`${m}-01T00:00:00Z`).toLocaleDateString("en-US", { month: "long", year: "numeric", timeZone: "UTC" });
  return (
    <>
      <p className="mt-6 mb-2 text-[11px] font-semibold text-white/50 uppercase"><AppText>Active subscriptions</AppText></p>
      {subs?.error && <p className="mb-2 text-[12px] text-red-500">{subs.error}</p>}
      <div className="grid grid-cols-2 gap-3">
        <div className="rounded-2xl border border-white/10 bg-white/5 p-4">
          <p className="text-[11px] text-white/60 uppercase"><AppText>Active</AppText></p>
          <p className="mt-1 text-[22px] font-bold tabular-nums">{subs?.active ?? 0}</p>
          <p className="text-[12px] text-white/50"><AppText>{subs?.renewing ?? 0} will renew</AppText></p>
        </div>
        <div className="rounded-2xl border border-white/10 bg-white/5 p-4">
          <p className="text-[11px] text-white/60 uppercase"><AppText>Per month</AppText></p>
          <p className="mt-1 text-[22px] font-bold tabular-nums">{usd(subs?.mrrUsd ?? 0)}</p>
          <p className="text-[12px] text-white/50"><AppText>from renewing subs</AppText></p>
        </div>
      </div>
      <div className="mt-3 divide-y divide-white/10 rounded-2xl border border-white/10 bg-white/5">
        {(subs?.byProduct ?? []).map((p) => (
          <div key={`${p.app}-${p.plan}`} className="flex items-center justify-between px-4 py-3">
            <div>
              <p className="text-[14px] font-semibold">
                <span className={`mr-1.5 rounded-full px-1.5 py-0.5 text-[10px] font-bold ${p.app === "phantom" ? "bg-purple-600 text-white" : "bg-green-600 text-white"}`}><AppText>
                  {p.app === "desktop" ? "Desktop" : p.app === "phantom" ? "Phantom" : "Mobile"}
                </AppText></span>
                <span className="capitalize">{p.plan}</span>
              </p>
              <p className="text-[12px] text-white/50"><AppText>{p.active} active · {p.renewing} renewing</AppText></p>
            </div>
            <div className="text-right">
              <p className="text-[15px] font-semibold tabular-nums">{usd(p.mrrUsd)}</p>
              <p className="text-[11px] text-white/50">/ month</p>
            </div>
          </div>
        ))}
      </div>
      <p className="mt-6 mb-2 text-[11px] font-semibold text-white/50 uppercase"><AppText>Each month</AppText></p>
      <div className="divide-y divide-white/10 rounded-2xl border border-white/10 bg-white/5">
        {(data.monthly ?? []).length === 0 && <p className="px-4 py-3.5 text-[13px] text-white/50"><AppText>No sales yet.</AppText></p>}
        {(data.monthly ?? []).map((m) => (
          <div key={m.month} className="px-4 py-3">
            <div className="flex items-center justify-between">
              <p className="text-[14px] font-semibold">{monthName(m.month)}</p>
              <p className="text-[15px] font-bold tabular-nums">{usd(m.usd)}</p>
            </div>
            <p className="mt-0.5 text-[12px] text-white/50"><AppText>
              {m.orders} orders · new {usd(m.newUsd)} · renewals {usd(m.renewalUsd)}
            </AppText></p>
            <p className="text-[12px] text-white/50 capitalize">
              {["weekly", "monthly", "lifetime"].map((pl) => `${pl} ${usd(m.byPlan[pl] ?? 0)}`).join(" · ")}
            </p>
          </div>
        ))}
      </div>
    </>
  );
}
