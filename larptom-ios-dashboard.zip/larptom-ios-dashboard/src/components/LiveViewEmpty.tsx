import { AppText } from "@/components/AppTranslation";

export function LiveViewEmpty() {
  return <div className="live-empty"><AppText>No data for this date range</AppText></div>;
}