import { useAppTranslation } from "@/components/AppTranslation";
import { AppText } from "@/components/AppTranslation";
import { useCallback, useEffect, useMemo, useState } from "react";
import { createPortal } from "react-dom";
import { useServerFn } from "@tanstack/react-start";
import { ChevronLeft, Search, Trash2, RotateCcw, Ban } from "lucide-react";

import { readCurrencyCode, setCurrency } from "@/lib/currency";
import { readLanguage, setLanguage } from "@/lib/app-locale";
import { LocalePicker } from "@/components/LocalePicker";
import { getLicenseState, LICENSE_FILTERS } from "@/lib/license-status";
import { applyBigStorePreset } from "@/lib/randomize-metrics";
import { InsightsPanel } from "@/components/InsightsPanel";
import { AffiliateAdminPanel, AffiliatePanel } from "@/components/AffiliatePanel";
import {
  deleteLicense,
  generateAdminLicense,
  isAdminKey,
  listLicenses,
  setLicenseRevoked,
  type LicenseRow,
} from "@/lib/checkout.functions";

function formatRemaining(ms: number) {
  if (ms <= 0) return "Expired";
  const total = Math.floor(ms / 1000);
  const days = Math.floor(total / 86400);
  const hours = Math.floor((total % 86400) / 3600);
  const minutes = Math.floor((total % 3600) / 60);
  const seconds = total % 60;
  const pad = (n: number) => String(n).padStart(2, "0");
  if (days > 0) return `${days}d ${pad(hours)}h ${pad(minutes)}m`;
  return `${pad(hours)}:${pad(minutes)}:${pad(seconds)}`;
}

const FILTERS = LICENSE_FILTERS;
type Filter = (typeof FILTERS)[number];

const SORTS = [
  { id: "newest", label: "Newest" },
  { id: "oldest", label: "Oldest" },
  { id: "expiry", label: "Expiring soon" },
] as const;
type SortId = (typeof SORTS)[number]["id"];

/** Full-page profile: license time, currency, and (admin only) key management. */
export function ProfilePanel({
  open,
  onClose,
  expiresAt,
  licenseKey,
}: {
  open: boolean;
  onClose: () => void;
  expiresAt?: string | undefined;
  licenseKey?: string | undefined;
}) {
  const translateAttribute = useAppTranslation();
  const [now, setNow] = useState(() => Date.now());
  const [currencyCode, setCurrencyCode] = useState("EUR");
  const [language, setCurrentLanguage] = useState("en");
  const [admin, setAdmin] = useState(false);
  const [rows, setRows] = useState<LicenseRow[] | null>(null);
  const [adminError, setAdminError] = useState<string | null>(null);
  const [pendingId, setPendingId] = useState<string | null>(null);
  const [filter, setFilter] = useState<Filter>("All");
  const [sort, setSort] = useState<SortId>("newest");
  const [query, setQuery] = useState("");
  const [confirmId, setConfirmId] = useState<string | null>(null);
  const [presetDone, setPresetDone] = useState(false);
  const [insightsOpen, setInsightsOpen] = useState(false);
  const [adminOpen, setAdminOpen] = useState(false);
  const [affiliatesOpen, setAffiliatesOpen] = useState(false);

  const checkAdmin = useServerFn(isAdminKey);
  const fetchLicenses = useServerFn(listLicenses);
  const revoke = useServerFn(setLicenseRevoked);
  const removeLicense = useServerFn(deleteLicense);

  useEffect(() => {
    if (!open) return;
    setCurrencyCode(readCurrencyCode());
    setCurrentLanguage(readLanguage());
    setNow(Date.now());
    const id = window.setInterval(() => setNow(Date.now()), 1000);
    return () => window.clearInterval(id);
  }, [open]);

  const loadLicenses = useCallback(async () => {
    if (!licenseKey) return;
    try {
      setAdminError(null);
      const list = await fetchLicenses({ data: { key: licenseKey } });
      setRows(list);
    } catch (error) {
      setAdminError(error instanceof Error ? error.message : "Could not load licenses.");
    }
  }, [fetchLicenses, licenseKey]);

  useEffect(() => {
    if (!open || !licenseKey) return;
    let active = true;
    void checkAdmin({ data: { key: licenseKey } })
      .then((res) => {
        if (!active) return;
        setAdmin(res.admin);
        if (res.admin) void loadLicenses();
      })
      .catch(() => setAdmin(false));
    return () => {
      active = false;
    };
  }, [open, licenseKey, checkAdmin, loadLicenses]);

  async function toggleRevoke(row: LicenseRow) {
    if (!licenseKey) return;
    setPendingId(row.id);
    setAdminError(null);
    try {
      await revoke({
        data: {
          key: licenseKey,
          target: { id: row.id, source: row.source },
          revoked: !row.revoked,
        },
      });
      await loadLicenses();
    } catch (error) {
      setAdminError(error instanceof Error ? error.message : "Could not update that license.");
    } finally {
      setPendingId(null);
    }
  }

  async function handleDelete(row: LicenseRow) {
    if (!licenseKey) return;
    setPendingId(row.id);
    setAdminError(null);
    try {
      await removeLicense({
        data: { key: licenseKey, target: { id: row.id, source: row.source } },
      });
      setConfirmId(null);
      await loadLicenses();
    } catch (error) {
      setAdminError(error instanceof Error ? error.message : "Could not delete that license.");
    } finally {
      setPendingId(null);
    }
  }

  const expiry = expiresAt ? new Date(expiresAt).getTime() : null;
  const remaining = expiry === null ? null : expiry - now;
  const lifetime = expiry !== null && expiry - Date.now() > 1000 * 60 * 60 * 24 * 365 * 5;

  const stateOf = useCallback(
    (row: LicenseRow): Filter => {
      return getLicenseState(row, now);
    },
    [now],
  );

  const [section, setSection] = useState<"customers" | "generated">("customers");
  const [genApp, setGenApp] = useState<"shopify" | "desktop">("shopify");
  const [genDays, setGenDays] = useState(30);
  const [genNote, setGenNote] = useState("");
  const [genBusy, setGenBusy] = useState(false);
  const [genKey, setGenKey] = useState<string | null>(null);
  const generate = useServerFn(generateAdminLicense);
  const scopedRows = useMemo(
    () => (rows ?? []).filter((r) => (section === "generated") === !!r.generated),
    [rows, section],
  );
  const generatedCount = useMemo(() => (rows ?? []).filter((r) => r.generated).length, [rows]);

  async function handleGenerate() {
    if (!licenseKey) return;
    setGenBusy(true);
    setAdminError(null);
    try {
      const res = await generate({ data: { key: licenseKey, app: genApp, days: genDays, note: genNote || undefined } });
      setGenKey(res.key);
      setGenNote("");
      await loadLicenses();
    } catch (error) {
      setAdminError(error instanceof Error ? error.message : "Could not create the key.");
    } finally {
      setGenBusy(false);
    }
  }

  const counts = useMemo(() => {
    const base: Record<Filter, number> = { All: 0, Active: 0, Canceled: 0, Expired: 0, Revoked: 0 };
    for (const row of scopedRows) {
      base.All += 1;
      base[stateOf(row)] += 1;
    }
    return base;
  }, [scopedRows, stateOf]);

  const [appFilter, setAppFilter] = useState<"all" | "shopify" | "phantom" | "desktop">("all");
  const visibleRows = useMemo(() => {
    let list = [...scopedRows];
    if (filter !== "All") list = list.filter((r) => stateOf(r) === filter);
    if (appFilter !== "all") list = list.filter((r) => (r.app ?? "shopify") === appFilter);
    const q = query.trim().toLowerCase();
    if (q) {
      list = list.filter(
        (r) =>
          r.key.toLowerCase().includes(q) ||
          r.plan.toLowerCase().includes(q) ||
          (r.email ?? "").toLowerCase().includes(q) ||
          r.app.toLowerCase().includes(q),
      );
    }
    list.sort((a, b) => {
      if (sort === "oldest")
        return new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime();
      if (sort === "expiry") {
        const av = a.lifetime || !a.expiresAt ? Infinity : new Date(a.expiresAt).getTime();
        const bv = b.lifetime || !b.expiresAt ? Infinity : new Date(b.expiresAt).getTime();
        return av - bv;
      }
      return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    });
    return list;
  }, [scopedRows, filter, appFilter, query, sort, stateOf]);

  if (!open) return null;

  return createPortal(
    <div className="fixed inset-0 z-[200] flex flex-col bg-black">
      {licenseKey && <InsightsPanel open={insightsOpen} onClose={() => setInsightsOpen(false)} licenseKey={licenseKey} />}
      {licenseKey && admin && <AffiliateAdminPanel open={affiliatesOpen} onClose={() => setAffiliatesOpen(false)} licenseKey={licenseKey} />}
      {licenseKey && !admin && <AffiliatePanel open={affiliatesOpen} onClose={() => setAffiliatesOpen(false)} licenseKey={licenseKey} />}
      {/* Header */}
      <div className="animate-header-fade shrink-0 bg-black px-4 pt-[max(env(safe-area-inset-top),12px)] pb-4">
        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={onClose}
            aria-label={translateAttribute("Back")}
            className="-ml-2 flex h-9 w-9 items-center justify-center rounded-full text-white active:opacity-60"
          >
            <ChevronLeft className="h-6 w-6" />
          </button>
          <div className="min-w-0">
            <h1 className="truncate text-[20px] leading-tight font-semibold text-white"><AppText>Profile</AppText></h1>
            <p className="truncate text-[12px] text-white/50"><AppText>
              {admin ? "Owner access · key management" : "Access & preferences"}
            </AppText></p>
          </div>
        </div>
      </div>

      {/* Content panel */}
      <div className="flex min-h-0 flex-1 flex-col overflow-hidden rounded-t-[22px] bg-white">
        <div className="min-h-0 flex-1 overflow-y-auto pb-32">
          {/* License time */}
          {!admin && <div className="px-5 pt-5">
            <div className="rounded-2xl bg-gray-50 px-4 py-4 text-center">
              <p className="text-[11px] font-semibold tracking-wide text-gray-500 uppercase"><AppText>
                License time left
              </AppText></p>
              <p className="mt-1.5 font-mono text-[26px] leading-none font-bold text-gray-900"><AppText>
                {remaining === null ? "—" : lifetime ? "Lifetime" : formatRemaining(remaining)}
              </AppText></p>
              {expiry !== null && !lifetime && (
                <p className="mt-2 text-[12px] text-gray-500"><AppText>
                  Valid until{" "}
                  {new Date(expiry).toLocaleString(undefined, {
                    dateStyle: "medium",
                    timeStyle: "short",
                  })}
                </AppText></p>
              )}
            </div>
          </div>}

          {/* Language and currency */}
          <div className="mt-6 px-5">
            <p className="text-[11px] font-semibold tracking-wide text-gray-500 uppercase"><AppText>
              Language & currency
            </AppText></p>
            <p className="mt-1 text-[12px] text-gray-500"><AppText>
              Changes dashboard labels and every sales amount in the app.
            </AppText></p>
            <div className="mt-3"><LocalePicker language={language} currencyCode={currencyCode} onLanguageChange={(code) => { setLanguage(code); setCurrentLanguage(code); }} onCurrencyChange={(code) => { setCurrency(code); setCurrencyCode(code); }} /></div>
          </div>

          {admin && (
            <div className="mt-8 px-5">
              <button
                type="button"
                onClick={() => {
                  applyBigStorePreset();
                  setPresetDone(true);
                  window.setTimeout(() => setPresetDone(false), 2000);
                }}
                className="w-full rounded-xl border border-gray-200 bg-gray-50 py-3 text-[15px] font-semibold text-black active:opacity-70"
              ><AppText>
                {presetDone ? "Applied ✓" : "Larptom big store preset"}
              </AppText></button>
            </div>
          )}

          {admin && (
            <div className="mt-6 grid grid-cols-2 gap-2 px-5">
              <button type="button" onClick={() => setAdminOpen((v) => !v)} className="rounded-xl bg-gray-900 py-3 text-[15px] font-semibold text-white active:opacity-70"><AppText>
                {adminOpen ? "Close admin" : "Admin"}
              </AppText></button>
              <button type="button" onClick={() => setInsightsOpen(true)} className="rounded-xl bg-gray-900 py-3 text-[15px] font-semibold text-white active:opacity-70"><AppText>
                Insights
              </AppText></button>
              <button type="button" onClick={() => setAffiliatesOpen(true)} className="col-span-2 rounded-xl bg-gray-900 py-3 text-[15px] font-semibold text-white active:opacity-70"><AppText>
                Affiliates
              </AppText></button>
            </div>
          )}

          {!admin && licenseKey && (
            <div className="mt-6 px-5">
              <button type="button" onClick={() => setAffiliatesOpen(true)} className="w-full rounded-xl bg-gray-900 py-3 text-[15px] font-semibold text-white active:opacity-70"><AppText>
                Affiliate program · earn 30%
              </AppText></button>
            </div>
          )}

          {admin && adminOpen && (
            <div className="mt-8">
              <div className="mb-4 grid grid-cols-2 gap-2 px-5">
                {(["customers", "generated"] as const).map((s) => (
                  <button key={s} type="button" onClick={() => { setSection(s); setFilter("All"); }}
                    className={`rounded-xl py-2.5 text-[13px] font-semibold ${section === s ? "bg-gray-900 text-white" : "bg-gray-100 text-gray-700"}`}>
                    {s === "customers" ? `Customers · ${(rows ?? []).length - generatedCount}` : `Generated · ${generatedCount}`}
                  </button>
                ))}
              </div>
              {section === "generated" && (
                <div className="mx-5 mb-4 rounded-2xl border border-gray-200 bg-gray-50 p-3.5">
                  <p className="text-[13px] font-semibold text-gray-900">Generate license key</p>
                  <div className="mt-2 flex gap-2">
                    {(["shopify", "desktop"] as const).map((a) => (
                      <button key={a} type="button" onClick={() => setGenApp(a)}
                        className={`flex-1 rounded-full py-1.5 text-[12px] font-semibold ${genApp === a ? "bg-gray-900 text-white" : "bg-white text-gray-700 border border-gray-200"}`}>
                        {a === "shopify" ? "Mobile" : "Desktop"}
                      </button>
                    ))}
                  </div>
                  <div className="mt-2 flex gap-2">
                    {[{ d: 7, l: "7 days" }, { d: 30, l: "30 days" }, { d: 36500, l: "Lifetime" }].map((o) => (
                      <button key={o.d} type="button" onClick={() => setGenDays(o.d)}
                        className={`flex-1 rounded-full py-1.5 text-[12px] font-semibold ${genDays === o.d ? "bg-gray-900 text-white" : "bg-white text-gray-700 border border-gray-200"}`}>
                        {o.l}
                      </button>
                    ))}
                  </div>
                  <input value={genNote} onChange={(e) => setGenNote(e.target.value)} maxLength={80} placeholder="Note or email (optional)"
                    className="mt-2 w-full rounded-xl border border-gray-200 bg-white px-3 py-2 text-[13px] text-gray-900 outline-none placeholder:text-gray-400" />
                  <button type="button" disabled={genBusy} onClick={() => void handleGenerate()}
                    className="mt-2 w-full rounded-xl bg-gray-900 py-2.5 text-[13px] font-semibold text-white disabled:opacity-50">
                    {genBusy ? "Generating…" : "Generate key"}
                  </button>
                  {genKey && (
                    <button type="button" onClick={() => void navigator.clipboard?.writeText(genKey)}
                      className="mt-2 w-full rounded-xl border border-green-300 bg-green-50 py-2 font-mono text-[13px] font-bold text-green-800">
                      {genKey} · tap to copy
                    </button>
                  )}
                </div>
              )}
              <div className="flex items-center justify-between px-5">
                <p className="text-[11px] font-semibold tracking-wide text-gray-500 uppercase"><AppText>
                  Licenses · {counts.All}
                </AppText></p>
                <button
                  type="button"
                  onClick={() => void loadLicenses()}
                  className="text-[12px] font-semibold text-gray-900 underline active:opacity-60"
                ><AppText>
                  Refresh
                </AppText></button>
              </div>

              {/* Search */}
              <div className="mt-3 px-5">
                <div className="flex items-center gap-2 rounded-xl border border-gray-200 bg-gray-50 px-3 py-2.5">
                  <Search className="h-4 w-4 shrink-0 text-gray-400" />
                  <input
                    value={query}
                    onChange={(e) => setQuery(e.target.value)}
                    placeholder={translateAttribute("Search key, plan or email")}
                    className="w-full bg-transparent text-[14px] text-gray-900 outline-none placeholder:text-gray-400"
                  />
                </div>
              </div>

              {/* Filter chips */}
              <div className="mt-3 flex gap-2 overflow-x-auto px-5 pb-1">
                {FILTERS.map((f) => {
                  const active = filter === f;
                  return (
                    <button
                      key={f}
                      type="button"
                      onClick={() => setFilter(f)}
                      className={`shrink-0 rounded-full px-3.5 py-1.5 text-[13px] font-semibold transition-all active:scale-[0.98] ${
                        active
                          ? "bg-gray-900 text-white"
                          : "border border-gray-200 bg-white text-gray-700"
                      }`}
                    >
                      {f} · {counts[f]}
                    </button>
                  );
                })}
              </div>

              {/* App */}
              <div className="mt-2 flex gap-2 px-5">
                {(["all", "shopify", "desktop", "phantom"] as const).map((a) => {
                  const active = appFilter === a;
                  const n = (rows ?? []).filter((r) => a === "all" || (r.app ?? "shopify") === a).length;
                  const cls = active
                    ? a === "phantom" ? "bg-purple-600 text-white" : a === "shopify" ? "bg-green-600 text-white" : "bg-gray-900 text-white"
                    : a === "phantom" ? "bg-purple-50 text-purple-700" : a === "shopify" ? "bg-green-50 text-green-700" : "bg-gray-100 text-gray-600";
                  return (
                    <button key={a} type="button" onClick={() => setAppFilter(a)}
                      className={`rounded-full px-3 py-1.5 text-[12px] font-semibold transition-all active:scale-[0.98] ${cls}`}><AppText>
                      {a === "all" ? "All apps" : a === "desktop" ? "Desktop" : a === "phantom" ? "Phantom" : "Mobile"} · {n}
                    </AppText></button>
                  );
                })}
              </div>

              {/* Sort */}
              <div className="mt-2 flex gap-2 px-5">
                {SORTS.map((s) => {
                  const active = sort === s.id;
                  return (
                    <button
                      key={s.id}
                      type="button"
                      onClick={() => setSort(s.id)}
                      className={`rounded-full px-3 py-1.5 text-[12px] font-medium transition-all active:scale-[0.98] ${
                        active ? "bg-gray-100 text-gray-900" : "text-gray-500"
                      }`}
                    >
                      <AppText>{s.label}</AppText>
                    </button>
                  );
                })}
              </div>

              {adminError && <p className="mt-3 px-5 text-[12px] text-red-600">{adminError}</p>}

              {/* List */}
              <div className="mt-3 space-y-2 px-5">
                {rows === null && <p className="text-[12px] text-gray-500"><AppText>Loading…</AppText></p>}
                {rows !== null && visibleRows.length === 0 && (
                  <p className="text-[12px] text-gray-500"><AppText>No licenses match this view.</AppText></p>
                )}
                {visibleRows.map((row) => {
                  const state = stateOf(row);
                  const badge =
                    state === "Active"
                      ? "bg-green-100 text-green-700"
                      : state === "Expired" || state === "Canceled"
                        ? "bg-amber-100 text-amber-700"
                        : "bg-red-100 text-red-700";
                  const busy = pendingId === row.id;
                  return (
                    <div
                      key={`${row.source}-${row.id}`}
                      className={`rounded-2xl border px-3.5 py-3 ${row.app === "phantom" ? "border-purple-300 bg-purple-50 border-l-4 border-l-purple-500" : "border-gray-200 bg-white"}`}
                    >
                      <div className="flex items-start justify-between gap-3">
                        <div className="min-w-0">
                          <p className="truncate font-mono text-[13px] font-bold text-gray-900">
                            {row.key}
                          </p>
                          <p className="mt-0.5 truncate text-[11px] text-gray-500">
                            <span className={`mr-1 rounded-full px-1.5 py-0.5 text-[10px] font-bold ${row.app === "phantom" ? "bg-purple-600 text-white" : "bg-green-100 text-green-700"}`}><AppText>{row.app === "desktop" ? "Desktop" : row.app === "phantom" ? "Phantom" : "Mobile"}</AppText></span><AppText>{row.plan} · {row.source === "card" ? (row.card ?? "Card") : "Crypto"} · $
                            {row.amountUsd.toFixed(2)}
                          </AppText></p>
                          <p className="mt-0.5 truncate text-[12px] font-medium text-gray-800">
                            {row.email ?? "No email"}
                          </p>
                          <p className="mt-0.5 text-[11px] text-gray-500"><AppText>
                            {row.lifetime
                              ? "Lifetime"
                              : row.expiresAt
                                ? state === "Expired"
                                  ? `Expired ${new Date(row.expiresAt).toLocaleDateString()}`
                                  : `Left ${formatRemaining(new Date(row.expiresAt).getTime() - now)}`
                                : "—"}
                          </AppText></p>
                        </div>
                        <span
                          className={`shrink-0 rounded-full px-2.5 py-1 text-[11px] font-semibold ${badge}`}
                        >
                          {state}
                        </span>
                      </div>

                      {confirmId === row.id ? (
                        <div className="mt-3 flex items-center gap-2">
                          <button
                            type="button"
                            disabled={busy}
                            onClick={() => void handleDelete(row)}
                            className="flex-1 rounded-full bg-red-600 px-3 py-2 text-[12px] font-semibold text-white active:scale-[0.98] disabled:opacity-50"
                          ><AppText>
                            {busy ? "Deleting…" : "Delete permanently"}
                          </AppText></button>
                          <button
                            type="button"
                            onClick={() => setConfirmId(null)}
                            className="rounded-full border border-gray-200 px-3 py-2 text-[12px] font-semibold text-gray-900 active:scale-[0.98]"
                          ><AppText>
                            Cancel
                          </AppText></button>
                        </div>
                      ) : (
                        <div className="mt-3 flex items-center gap-2">
                          <button
                            type="button"
                            disabled={busy}
                            onClick={() => void toggleRevoke(row)}
                            className={`flex flex-1 items-center justify-center gap-1.5 rounded-full px-3 py-2 text-[12px] font-semibold transition-all active:scale-[0.98] disabled:opacity-50 ${
                              row.revoked
                                ? "border border-gray-200 bg-white text-gray-900"
                                : "bg-gray-900 text-white"
                            }`}
                          >
                            {row.revoked ? (
                              <RotateCcw className="h-3.5 w-3.5" />
                            ) : (
                              <Ban className="h-3.5 w-3.5" />
                            )}
                            {busy ? "…" : row.revoked ? "Restore" : "Revoke"}
                          </button>
                          <button
                            type="button"
                            aria-label={translateAttribute("Delete key")}
                            onClick={() => setConfirmId(row.id)}
                            className="flex h-9 w-9 items-center justify-center rounded-full border border-gray-200 text-red-600 active:scale-[0.95]"
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>,
    document.body,
  );
}
