import { useAppLanguage } from "@/components/AppTranslation";
import { useAppTranslation } from "@/components/AppTranslation";
import { AppText } from "@/components/AppTranslation";
import useEmblaCarousel from "embla-carousel-react";
import { useCallback, useEffect, useRef, useState } from "react";

import { onStoreChange, readStore, writeStore } from "@/lib/app-store";
import { RollingNumber } from "@/components/RollingNumber";
import { Button } from "@/components/ui/button";

import { liveDefault, liveKey, metricsKey, useDateRange } from "@/lib/date-range";
import { useCurrency, withCurrency } from "@/lib/currency";
import { appText, useLanguage } from "@/lib/app-locale";
import liveIcon from "@/assets/live-indicator.png.asset.json";
import zeroBarAsset from "@/assets/zero-bar.png.asset.json";

type Metric = {
  label: string;
  value: string;
  prefix?: string;
  suffix?: string;
  delta: string;
  sparkId: string;
  path: string;
};

const DOWN_PATH =
  "M 1.00 3.23 Q 3.40 5.43 4.60 3.70 Q 5.80 1.98 7.00 5.20 Q 8.20 8.42 9.40 6.44 Q 10.60 4.45 11.80 6.20 T 13.00 7.95 L 13.00 10 L 1.00 10 Z";

export const INITIAL_METRICS: Metric[] = [
  {
    label: "Total sales",
    value: "591.760,03",
    prefix: "€",
    delta: "+395",
    sparkId: "spark-grad-totalsales",
    path: "M 1.00 8.42 Q 3.40 5.51 4.60 4.73 Q 5.80 3.95 7.00 2.76 Q 8.20 1.58 9.40 2.44 Q 10.60 3.30 11.80 2.44 T 13.00 1.58 L 13.00 10 L 1.00 10 Z",
  },
  {
    label: "Orders",
    value: "46.344",
    delta: "+426",
    sparkId: "spark-grad-orders",
    path: "M 1.00 7.49 Q 3.40 7.92 4.60 5.93 Q 5.80 3.94 7.00 2.97 Q 8.20 2.00 9.40 3.70 Q 10.60 5.40 11.80 3.95 T 13.00 2.49 L 13.00 10 L 1.00 10 Z",
  },
  {
    label: "Conversion rate",
    value: "5,90",
    suffix: "%",
    delta: "+696",
    sparkId: "spark-grad-conversionrate",
    path: "M 1.00 6.78 Q 3.40 6.62 4.60 5.33 Q 5.80 4.03 7.00 3.75 Q 8.20 3.46 9.40 2.89 Q 10.60 2.32 11.80 2.04 T 13.00 1.77 L 13.00 10 L 1.00 10 Z",
  },
  {
    label: "Sessions",
    value: "493.999",
    delta: "+290",
    sparkId: "spark-grad-sessions",
    path: "M 1.00 8.42 Q 3.40 7.51 4.60 6.73 Q 5.80 5.95 7.00 4.76 Q 8.20 3.58 9.40 4.44 Q 10.60 5.30 11.80 4.44 T 13.00 3.58 L 13.00 10 L 1.00 10 Z",
  },
];


/** Parse a signed delta string like "+395" or "-426" into {sign, body}. */
function parseDelta(delta: string): { sign: "+" | "-"; body: string } {
  const trimmed = delta.trim();
  const sign: "+" | "-" = trimmed.startsWith("-") ? "-" : "+";
  const body = trimmed.replace(/^[+-]/, "");
  return { sign, body };
}

/** Parse a European formatted number ("0", "1.234,56", "0%") into a number. */
function parseValue(raw: string | undefined | null) {
  if (!raw) return 0;
  const cleaned = String(raw).replace(/\./g, "").replace(",", ".").replace(/[^\d.]/g, "");
  const n = Number.parseFloat(cleaned);
  return Number.isFinite(n) ? n : 0;
}

/** Grey placeholder bar shown for zero-value metrics. */
function ZeroBar({ className }: { className?: string; id?: string }) {
  return (
    <span className={`inline-flex items-center align-middle ${className ?? ""}`} aria-hidden="true">
      <img src={zeroBarAsset.url} alt="" className="h-[6px] w-auto object-contain" />
    </span>
  );
}




function Sparkline({ id, path }: { id: string; path: string }) {
  // stroke only the top line: drop the closing segments (baseline + right edge)
  const linePath = path.replace(/\s*L\s[^Z]*Z\s*$/, "");
  return (
    <svg width="18" height="11" viewBox="0 0 14 10" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <linearGradient id={id} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="currentColor" stopOpacity="0.45" />
          <stop offset="100%" stopColor="currentColor" stopOpacity="0" />
        </linearGradient>
      </defs>
      <path d={path} fill={`url(#${id})`} stroke="none" />
      <path
        d={linePath}
        stroke="currentColor"
        strokeWidth="1.7"
        strokeLinecap="round"
        strokeLinejoin="round"
        fill="none"
      />
    </svg>
  );
}

export function MetricsCarousel({
  onActiveChange,
  onEmptyClick,
  onActiveClick,
  onLiveClick,
  expanded = true,
  onDragOffset,
}: {
  onDragOffset?: (dx: number, dragging: boolean) => void;
  onEmptyClick?: () => void;
  onActiveClick?: () => void;
  onLiveClick?: () => void;
  expanded?: boolean;
  onActiveChange?: (metric: {
    label: string;
    value: string;
    prefix?: string | undefined;
    suffix?: string | undefined;
    down: boolean;
  }) => void;
}) {
  const translateAttribute = useAppTranslation();
  const [emblaRef, emblaApi] = useEmblaCarousel({
    align: "start",
    dragFree: false,
    loop: true,
    containScroll: false,
  });
  const [selected, setSelected] = useState(0);
  const dragStart = useRef<{ x: number; y: number } | null>(null);
  const currency = useCurrency();
  const language = useAppLanguage();
  const [metrics, setMetrics] = useState<Metric[]>(INITIAL_METRICS);
  const [liveCount, setLiveCount] = useState("1");
  const range = useDateRange();
  const STORAGE_KEY = metricsKey(range);
  const LIVE_KEY = liveKey(range);

  useEffect(() => {
    const active = metrics[selected];
    if (active && onActiveChange)
      onActiveChange({
        label: active.label,
        value: active.value,
        prefix: withCurrency(active.prefix, currency),
        suffix: active.suffix,
        down: parseDelta(active.delta).sign === "-",
      });
  }, [selected, metrics, currency, language, onActiveChange]);

  useEffect(() => {
    const sync = () => {
      try {
        const raw = localStorage.getItem(STORAGE_KEY);
        const saved = raw
          ? (JSON.parse(raw) as Record<string, { value: string; delta: string }>)
          : {};
        setMetrics(
          INITIAL_METRICS.map((m) => (saved[m.label] ? { ...m, ...saved[m.label] } : m)),
        );
      } catch {
        setMetrics(INITIAL_METRICS);
      }

      // Live is global, so an edited value remains unchanged across ranges.
      setLiveCount(readStore(liveKey(range), liveDefault(range)));
    };
    sync();
    return onStoreChange(sync);
  }, [STORAGE_KEY, LIVE_KEY, range]);

  // Live drifts on its own every few seconds by a few numbers, up or down.
  useEffect(() => {
    let timer: ReturnType<typeof setTimeout>;
    const tick = () => {
      const delay = 3000 + Math.floor(Math.random() * 4000); // 3–7s
      timer = setTimeout(() => {
          const current = parseInt(readStore(liveKey(), "1").replace(/\D/g, ""), 10) || 0;
          const magnitude = 1 + Math.floor(Math.random() * 5); // 1–5
          const up = Math.random() < 0.5;
          let next = up ? current + magnitude : current - magnitude;
          if (next < 0) next = magnitude;
          if (next > 999) next = 999 - magnitude;
          writeStore(liveKey(), String(next));
        tick();
      }, delay);
    };
    tick();
    return () => clearTimeout(timer);
  }, []);

  const onSelect = useCallback(() => {
    if (emblaApi) setSelected(emblaApi.selectedScrollSnap() % metrics.length);
  }, [emblaApi, metrics.length]);


  useEffect(() => {
    if (!emblaApi) return;
    onSelect();
    emblaApi.on("select", onSelect);
    emblaApi.on("reInit", onSelect);
  }, [emblaApi, onSelect]);

  // Standalone PWA can measure the carousel before layout settles, which makes
  // embla silently disable looping. Re-measure once things are painted.
  useEffect(() => {
    if (!emblaApi) return;
    const reInit = () => emblaApi.reInit();
    const raf = requestAnimationFrame(reInit);
    const t1 = window.setTimeout(reInit, 150);
    const t2 = window.setTimeout(reInit, 600);
    window.addEventListener("orientationchange", reInit);
    window.addEventListener("resize", reInit);
    return () => {
      cancelAnimationFrame(raf);
      window.clearTimeout(t1);
      window.clearTimeout(t2);
      window.removeEventListener("orientationchange", reInit);
      window.removeEventListener("resize", reInit);
    };
  }, [emblaApi, metrics]);

  return (
    <div
      className="bg-black"
      onTouchStart={(e) => {
        dragStart.current = { x: e.touches[0]!.clientX, y: e.touches[0]!.clientY };
      }}
      onTouchMove={(e) => {
        const st = dragStart.current;
        if (!st) return;
        const dx = e.touches[0]!.clientX - st.x;
        const dy = e.touches[0]!.clientY - st.y;
        if (Math.abs(dx) > Math.abs(dy)) onDragOffset?.(dx, true);
      }}
      onTouchEnd={() => {
        dragStart.current = null;
        onDragOffset?.(0, false);
      }}
      onTouchCancel={() => {
        dragStart.current = null;
        onDragOffset?.(0, false);
      }}
    >
      <div className="relative mt-1 w-full">
        <Button variant="ghost" onClick={onLiveClick} aria-label={translateAttribute("Live View")} className="absolute top-0 bottom-0 left-0 z-10 flex h-auto flex-shrink-0 flex-col items-start justify-start gap-0 rounded-none bg-transparent px-3 py-1 opacity-60 select-none hover:bg-transparent">
          <div className="mb-1 text-xs font-semibold text-gray-400"><AppText>Live</AppText></div>
          <div className="-mt-1 mb-0 flex items-center text-[13px] font-semibold text-white">
            <span className="relative mr-1 inline-flex h-4 w-4 items-center justify-center">
              <img src={liveIcon.url} alt={translateAttribute("Live")} className="h-4 w-4 object-contain" />
            </span>
            <RollingNumber value={liveCount} animKey="live" />
            
          </div>
        </Button>

        <div className="pointer-events-auto w-full pl-[54px]">
          <div
            className="relative w-full overflow-hidden"
            role="region"
            aria-roledescription="carousel"
          >
            <div className="overflow-hidden" ref={emblaRef}>
              <div
                className="flex w-full gap-1"
                onClick={(e) => {
                  const target = e.target as HTMLElement | null;
                  if (!target?.closest("[data-metric-card]")) onEmptyClick?.();
                }}
              >
                {[...metrics, ...metrics].map((metric, index) => {
                  const active = index % metrics.length === selected;

                  const { sign, body } = parseDelta(metric.delta);
                  const down = sign === "-";
                  const trendColor = down ? "text-gray-500" : "text-green-500";
                  const sparkPath = down ? DOWN_PATH : metric.path;
                  const isZero = parseValue(metric.value) === 0;
                  return (
                    <div
                      key={`${metric.label}-${index}`}
                      role="group"
                      aria-roledescription="slide"
                      className="flex min-w-0 flex-none items-center pl-0"
                    >

                      <div className="pr-3 pl-0.5">
                        <div
                          data-metric-card
                          onClick={() => {
                            if (active) {
                              onActiveClick?.();
                            } else {
                              emblaApi?.scrollTo(index);
                            }
                          }}
                          className={`cursor-pointer rounded-2xl border px-3 py-1.5 transition-all duration-500 ease-out ${
                            active
                              ? expanded
                                ? "border-white/10 bg-white/[0.09] backdrop-blur-sm"
                                : "border-transparent bg-transparent"
                              : "border-transparent bg-transparent opacity-50"
                          }`}
                        >
                          <div
                            className={`mb-1 text-xs font-medium whitespace-nowrap transition-all duration-300 ${
                              active ? "text-gray-300" : "text-gray-400"
                            }`}
                          >
                            {appText(language, metric.label === "Total sales" ? "total_sales" : metric.label === "Orders" ? "orders" : metric.label === "Conversion rate" ? "conversion_rate" : "sessions")}
                          </div>
                          <div
                            className={`-mt-0.5 mb-0 flex items-baseline whitespace-nowrap text-white transition-all duration-300 ${
                              active
                                ? "text-[15px] font-bold"
                                : "text-[13px] font-semibold opacity-50"
                            }`}
                          >
                            <span className="inline-block">
                              <span className="text-inherit">
                                {metric.prefix && (
                                  <span className="mr-0.5">
                                    {withCurrency(metric.prefix, currency)}
                                  </span>
                                )}
                                <RollingNumber value={metric.value} animKey={range} />
                                {metric.suffix}
                              </span>
                            </span>
                          {!isZero && (
                            <>
                              {(!active || !expanded) && (
                                <span
                                  className={`-mr-0.5 ml-1 inline-flex items-center ${trendColor}`}
                                  aria-hidden="true"
                                >
                                  <Sparkline id={`${metric.sparkId}-${index}`} path={sparkPath} />
                                </span>
                              )}
                              <span
                                className={`inline-flex items-center text-[11px] font-semibold ${trendColor} ${
                                  active ? "ml-1.5" : "ml-1"
                                }`}
                              >
                                <span>
                                   <span>{sign}</span>
                                  <RollingNumber value={body} animKey={range} className="font-medium" />
                                  %
                                </span>
                              </span>
                            </>
                          )}
                          {isZero && <ZeroBar id={`zero-${metric.sparkId}-${index}`} className="ml-1.5" />}
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
