import { useAppTranslation } from "@/components/AppTranslation";
import { AppText } from "@/components/AppTranslation";
import { forwardRef, useEffect, useState } from "react";

import bellIcon from "@/assets/bell-icon.png.asset.json";
import { AccountSheet } from "@/components/AccountSheet";
import { StoresSheet } from "@/components/StoresSheet";
import { Button } from "@/components/ui/button";
import { DEFAULT_AVATAR, type AvatarSettings } from "@/components/app-colors";
import { onStoreChange, readStore } from "@/lib/app-store";

const AVATAR_KEY = "app.avatar";
const AVATAR2_KEY = "app.avatarSmall";
const COUNT_KEY = "app.notificationCount";

function AvatarButton({
  avatar,
  size,
  textClass,
  shape = "square",
}: {
  avatar: AvatarSettings;
  size: string;
  textClass: string;
  shape?: "square" | "circle";
}) {
  const translateAttribute = useAppTranslation();
  return (
    <div
      className={`${size} relative overflow-hidden ${shape === "circle" ? "rounded-full" : "rounded-lg"}`}
    >
      <div
        className="flex h-full w-full items-center justify-center"
        style={{ backgroundColor: avatar.background }}
      >
        {avatar.mode === "image" && avatar.image ? (
          <img src={avatar.image} alt={translateAttribute("Avatar")} className="h-full w-full object-cover" />
        ) : (
          <span
            className={`${textClass} font-semibold leading-none uppercase`}
            style={{ color: avatar.textColor, textShadow: "0 1px 2px rgba(0,0,0,0.3)" }}
          >
            {avatar.initials}
          </span>
        )}
      </div>
    </div>
  );
}

type AppHeaderProps = {
  tabKey?: string;
  chartEditMode?: boolean;
  onBellClick: () => void;
  onManageAccount: () => void;
  onNotifications: () => void;
  onLogout: () => void;
};

export const AppHeader = forwardRef<HTMLDivElement, AppHeaderProps>(function AppHeader(
  { tabKey, chartEditMode = false, onBellClick, onManageAccount, onNotifications, onLogout },
  ref,
) {
  const translateAttribute = useAppTranslation();
  const [avatar, setAvatar] = useState<AvatarSettings>(DEFAULT_AVATAR);
  const [avatar2, setAvatar2] = useState<AvatarSettings>(DEFAULT_AVATAR);
  const [count, setCount] = useState(1);
  const [name, setName] = useState("Larptom.com");
  const [email, setEmail] = useState("");
  const [accountOpen, setAccountOpen] = useState(false);
  const [storesOpen, setStoresOpen] = useState(false);
  const [animating, setAnimating] = useState(true);

  useEffect(() => {
    const sync = () => {
      setName(readStore("bisha.headerName", "Larptom.com"));
      setEmail(readStore("bisha.accountEmail", ""));
      const c = readStore("app.notificationCount", "");
      if (c !== "") setCount(Number(c) || 0);
      try {
        const first = localStorage.getItem(AVATAR_KEY);
        const second = localStorage.getItem(AVATAR2_KEY);
        if (first) setAvatar({ ...DEFAULT_AVATAR, ...JSON.parse(first) });
        if (second) setAvatar2({ ...DEFAULT_AVATAR, ...JSON.parse(second) });
      } catch { /* ignore invalid avatar data */ }
    };
    sync();
    return onStoreChange(sync);
  }, []);

  useEffect(() => {
    try {
      const storedAvatar = localStorage.getItem(AVATAR_KEY);
      if (storedAvatar) setAvatar({ ...DEFAULT_AVATAR, ...JSON.parse(storedAvatar) });
      const storedAvatar2 = localStorage.getItem(AVATAR2_KEY);
      if (storedAvatar2) setAvatar2({ ...DEFAULT_AVATAR, ...JSON.parse(storedAvatar2) });
      const storedCount = localStorage.getItem(COUNT_KEY);
      if (storedCount !== null) setCount(Number(storedCount) || 0);
    } catch {
      /* ignore */
    }
  }, []);

  useEffect(() => {
    setAnimating(true);
    const id = window.setTimeout(() => setAnimating(false), 650);
    return () => window.clearTimeout(id);
  }, [tabKey]);

  return (
    <>
    <div
      ref={ref}
      className="fixed inset-x-0 top-0 z-50 bg-black"
      style={{ height: "var(--header-h)" }}
    >
      <div key={animating ? `fade-${tabKey}` : `static-${tabKey}`} className={`flex h-full items-center gap-3 px-3 pb-1 ${animating ? "animate-header-fade" : ""}`}>

        <div className="flex flex-1 items-center justify-start">
          <Button variant="ghost" size="icon" aria-label={translateAttribute("Open account menu")} onClick={() => setAccountOpen(true)} className="h-9 w-9 rounded-full p-0 hover:bg-transparent">
            <AvatarButton avatar={avatar} size="w-8 h-8" textClass="text-[11px]" shape="circle" />
          </Button>
        </div>

        <div className="flex flex-1 items-center justify-center gap-1.5">
          <Button variant="ghost" aria-label={translateAttribute("Open stores menu")} onClick={() => setStoresOpen(true)} className="h-9 gap-1.5 rounded-lg px-2 py-0 hover:bg-transparent">
            <AvatarButton
              avatar={avatar2}
              size="w-6 h-6"
              textClass="text-[10px]"
            />
            <h1 className="text-sm font-semibold text-white">{name}</h1>
          </Button>
        </div>

        <div className="flex flex-1 items-center justify-end">
          <div className="relative cursor-pointer">
            <button
              type="button"
              className="text-white"
              onClick={onBellClick}
              aria-label={chartEditMode ? "Finish editing chart" : "Edit chart"}
            >
              <img src={bellIcon.url} alt={translateAttribute("Notifications")} className="h-5 w-5" />
            </button>
            {!chartEditMode && count > 0 && (
              <div className="pointer-events-none absolute -top-1 -right-1 flex h-3.5 w-3.5 items-center justify-center rounded-full bg-red-500 text-[10px] text-white"><AppText>
                {count > 9 ? "9+" : count}
              </AppText></div>
            )}
            {chartEditMode && (
              <div className="pointer-events-none absolute -top-1 -right-1 flex h-3.5 w-3.5 items-center justify-center rounded-full bg-blue-500 text-[10px] font-bold text-white">
                ✎
              </div>
            )}
          </div>
        </div>
      </div>

    </div>
    <AccountSheet open={accountOpen} onClose={() => setAccountOpen(false)} avatar={avatar} name={name} email={email}
      onManageAccount={() => { setAccountOpen(false); onManageAccount(); }}
      onNotifications={() => { setAccountOpen(false); onNotifications(); }}
      onLogout={onLogout} />
    <StoresSheet open={storesOpen} onClose={() => setStoresOpen(false)} store={avatar2} name={name} />
    </>
  );
});
