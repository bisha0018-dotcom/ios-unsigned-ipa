import { useEffect, useRef } from "react";
import landAsset from "@/assets/live-land.geojson.asset.json";
import { liveStackHeight, liveVisitorIsRaised, liveVisitorStacks, type LiveRegion } from "@/lib/live-view-data";

type Ring = [number, number][];
type Land = { features: { geometry: { type: string; coordinates: Ring[] | Ring[][] } }[] };

function inside(lon: number, lat: number, ring: Ring) {
  let hit = false;
  for (let i = 0, j = ring.length - 1; i < ring.length; j = i++) {
    const a = ring[i]; const b = ring[j];
    if (a && b && (a[1] > lat) !== (b[1] > lat) && lon < (b[0] - a[0]) * (lat - a[1]) / (b[1] - a[1]) + a[0]) hit = !hit;
  }
  return hit;
}

/** Client-only globe: surface-following geographic hexagons, with no invented activity. */
export function LiveViewGlobe({ flat, focus, visitors, seed, region, zoom = 0 }: { flat: boolean; focus: { lat: number; lon: number } | null; visitors: number; seed: number; region: LiveRegion; zoom?: number }) {
  const host = useRef<HTMLDivElement>(null);
  const view = useRef({ flat, focus, visitors, seed, region, zoom });
  view.current = { flat, focus, visitors, seed, region, zoom };
  useEffect(() => {
    const container = host.current;
    if (!container) return;
    let stopped = false;
    let cleanup = () => {};
    void (async () => {
      const [THREE, data] = await Promise.all([import("three"), fetch(landAsset.url).then(r => {
        if (!r.ok) throw new Error("Map unavailable");
        return r.json() as Promise<Land>;
      })]);
      if (stopped) return;
      const css = getComputedStyle(container);
      const mint = new THREE.Color(css.getPropertyValue("--live-land-north").trim());
      const blue = new THREE.Color(css.getPropertyValue("--live-land-south").trim());
      const visitorBlue = new THREE.Color(css.getPropertyValue("--live-visitor-active").trim());
      const visitorBright = new THREE.Color(css.getPropertyValue("--live-visitor-bright").trim());
      const seaNorth = new THREE.Color(css.getPropertyValue("--live-sea-north").trim());
      const seaSouth = new THREE.Color(css.getPropertyValue("--live-sea-south").trim());
      const scene = new THREE.Scene();
      const camera = new THREE.PerspectiveCamera(35, 1, 0.1, 100);
      camera.position.z = 4;
      const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
      renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
      container.appendChild(renderer.domElement);
      const globe = new THREE.Group();
      scene.add(globe);
      const sphereGeometry = new THREE.SphereGeometry(1, 96, 64);
      const seaColors: number[] = [];
      const spherePositions = sphereGeometry.getAttribute("position");
      for (let i = 0; i < spherePositions.count; i++) {
        const color = seaSouth.clone().lerp(seaNorth, (spherePositions.getY(i) + 1) / 2);
        seaColors.push(color.r, color.g, color.b);
      }
      sphereGeometry.setAttribute("color", new THREE.Float32BufferAttribute(seaColors, 3));
      const sphereMaterial = new THREE.MeshBasicMaterial({ vertexColors: true });
      const sphere = new THREE.Mesh(sphereGeometry, sphereMaterial);
      globe.add(sphere);
      const rings = data.features.flatMap(f => f.geometry.type === "Polygon" ? [f.geometry.coordinates as Ring[]] : f.geometry.coordinates as Ring[][]);
      const polygons = rings.flatMap(polygon => {
        const outer = polygon[0];
        if (!outer?.length) return [];
        return [{ outer, holes: polygon.slice(1), minX: Math.min(...outer.map(p => p[0])), maxX: Math.max(...outer.map(p => p[0])), minY: Math.min(...outer.map(p => p[1])), maxY: Math.max(...outer.map(p => p[1])) }];
      });
      const globePoints: number[] = []; const mapPoints: number[] = []; const colors: number[] = [];
      const cells: { lon: number; lat: number }[] = [];
      let row = 0;
      const hexRadius = 0.95 / Math.sqrt(3) * 0.89;
      for (let lat = -85; lat <= 85; lat += 0.95 * Math.sqrt(3) / 2, row++) {
        const step = 0.95 / Math.max(0.15, Math.cos(lat * Math.PI / 180));
        for (let lon = -180 + (row % 2) * step / 2; lon < 180; lon += step) {
          if (!polygons.some(p => lon >= p.minX && lon <= p.maxX && lat >= p.minY && lat <= p.maxY && inside(lon, lat, p.outer) && !p.holes.some(r => inside(lon, lat, r)))) continue;
          const color = blue.clone().lerp(mint, (lat + 90) / 180);
          cells.push({ lon, lat });
          // Actual surface geometry, not screen-facing sprites: the hexagons
          // narrow naturally at the horizon and disappear behind the ocean.
          const vertex = (angle: number | null) => {
            const vertexLat = lat + (angle === null ? 0 : Math.sin(angle) * hexRadius);
            const vertexLon = lon + (angle === null ? 0 : Math.cos(angle) * hexRadius / Math.max(0.15, Math.cos(lat * Math.PI / 180)));
            const phi = vertexLat * Math.PI / 180; const theta = vertexLon * Math.PI / 180;
            globePoints.push(Math.cos(phi) * Math.sin(theta) * 1.002, Math.sin(phi) * 1.002, Math.cos(phi) * Math.cos(theta) * 1.002);
            mapPoints.push(vertexLon / 180 * 1.22, vertexLat / 90 * 0.72, 0);
            colors.push(color.r, color.g, color.b);
          };
          for (let side = 0; side < 6; side++) {
            vertex(null);
            vertex(Math.PI / 6 + side * Math.PI / 3);
            vertex(Math.PI / 6 + (side + 1) * Math.PI / 3);
          }
        }
      }
      const dotGeometry = new THREE.BufferGeometry();
      dotGeometry.setAttribute("position", new THREE.Float32BufferAttribute(globePoints, 3));
      dotGeometry.setAttribute("color", new THREE.Float32BufferAttribute(colors, 3));
      const dotMaterial = new THREE.MeshBasicMaterial({ vertexColors: true, side: THREE.DoubleSide });
      globe.add(new THREE.Mesh(dotGeometry, dotMaterial));
      const stackGeometry = new THREE.BufferGeometry();
      const stackMaterial = new THREE.MeshBasicMaterial({ vertexColors: true, side: THREE.DoubleSide });
      globe.add(new THREE.Mesh(stackGeometry, stackMaterial));
      const pinCanvas = document.createElement("canvas");
      pinCanvas.width = 64; pinCanvas.height = 96;
      const pen = pinCanvas.getContext("2d");
      if (pen) {
        pen.fillStyle = css.getPropertyValue("--live-pin").trim() || "#a15cff";
        pen.beginPath(); pen.moveTo(32, 91); pen.bezierCurveTo(27, 80, 8, 53, 8, 34); pen.bezierCurveTo(8, 2, 56, 2, 56, 34); pen.bezierCurveTo(56, 53, 37, 80, 32, 91); pen.fill();
        pen.globalCompositeOperation = "destination-out";
        pen.beginPath(); pen.arc(32, 33, 10, 0, Math.PI * 2); pen.fill();
        pen.globalCompositeOperation = "source-over";
      }
      const pinTexture = new THREE.CanvasTexture(pinCanvas);
      pinTexture.colorSpace = THREE.SRGBColorSpace;
      const pinMaterial = new THREE.SpriteMaterial({ map: pinTexture, depthTest: false, transparent: true });
      const pin = new THREE.Sprite(pinMaterial);
      pin.center.set(0.5, 0.05); pin.scale.set(0.034, 0.051, 1); pin.visible = false;
      pin.renderOrder = 10;
      globe.add(pin);
      const pinWorld = new THREE.Vector3();

      globe.rotation.set(0.05, -0.28, -0.12);
      let dragging = false; let x = 0; let y = 0; let lastFocus: typeof focus = null; let wasFlat = false;
      const MIN_Z = 1.6; const MAX_Z = 4;
      const setZoom = (z: number) => { camera.position.z = Math.max(MIN_Z, Math.min(MAX_Z, z)); };
      const pointers = new Map<number, { x: number; y: number }>(); let pinchDist = 0;
      const dist = () => { const [a, b] = [...pointers.values()]; if (!a || !b) return 0; return Math.hypot(a.x - b.x, a.y - b.y); };
      const down = (e: PointerEvent) => { pointers.set(e.pointerId, { x: e.clientX, y: e.clientY }); container.setPointerCapture(e.pointerId); if (pointers.size === 2) { dragging = false; pinchDist = dist(); } else { dragging = true; x = e.clientX; y = e.clientY; } };
      const move = (e: PointerEvent) => {
        if (pointers.has(e.pointerId)) pointers.set(e.pointerId, { x: e.clientX, y: e.clientY });
        if (pointers.size === 2 && !view.current.flat) { const d = dist(); if (pinchDist > 0 && d > 0) setZoom(camera.position.z * (pinchDist / d)); pinchDist = d; return; }
        if (!dragging || view.current.flat) return;
        const s = (camera.position.z - 1) / (MAX_Z - 1);
        globe.rotation.y += (e.clientX - x) * 0.006 * s; globe.rotation.x = Math.max(-1.3, Math.min(1.3, globe.rotation.x + (e.clientY - y) * 0.004 * s)); x = e.clientX; y = e.clientY;
      };
      const up = (e: PointerEvent) => { pointers.delete(e.pointerId); pinchDist = 0; if (pointers.size === 1) { const [p] = [...pointers.values()]; if (p) { x = p.x; y = p.y; } dragging = true; } else dragging = false; };
      const wheel = (e: WheelEvent) => { if (view.current.flat) return; e.preventDefault(); const dy = e.deltaY * (e.deltaMode === 1 ? 16 : e.deltaMode === 2 ? 100 : 1); setZoom(camera.position.z * Math.exp(dy * 0.0015)); };
      container.style.touchAction = "none"; container.style.overflow = "hidden";
      container.addEventListener("wheel", wheel, { passive: false });
      container.addEventListener("pointerdown", down); container.addEventListener("pointermove", move); container.addEventListener("pointerup", up); container.addEventListener("pointercancel", up);
      const resize = () => { renderer.setSize(container.clientWidth, container.clientHeight); camera.aspect = container.clientWidth / Math.max(1, container.clientHeight); camera.updateProjectionMatrix(); };
      const observer = new ResizeObserver(resize); observer.observe(container); resize();
      let frame = 0;
      let activityKey = ""; let previousRegion: LiveRegion = "all"; let previousZoom = 0;
      const animate = () => {
        if (stopped) return;
        const current = view.current;
        if (previousZoom !== current.zoom) { setZoom(4 * Math.exp(-current.zoom * 0.15)); previousZoom = current.zoom; }
        const nextActivityKey = `${current.visitors}:${current.seed}:${current.region}`;
        if (activityKey !== nextActivityKey) {
          activityKey = nextActivityKey;
          const active = liveVisitorStacks(cells, current.visitors, current.seed, current.region);
          const positions: number[] = []; const stackColors: number[] = [];
          let activityIndex = 0; let raisedCount = 0;
          for (const [cell, count] of active) {
            const raised = liveVisitorIsRaised(activityIndex++, current.seed);
            if (raised) raisedCount++;
            const height = raised ? liveStackHeight(count, cell, current.seed) : 0.0006;
            const topColor = visitorBlue.clone().lerp(visitorBright, (Math.sin(cell * 31 + current.seed) + 1) / 2);
            const addVertex = (vertex: number, raised: boolean, color: typeof visitorBlue) => {
              const offset = vertex * 3;
              const scale = raised ? (1.002 + height) / 1.002 : 1;
              positions.push((globePoints[offset] ?? 0) * scale, (globePoints[offset + 1] ?? 0) * scale, (globePoints[offset + 2] ?? 0) * scale);
              stackColors.push(color.r, color.g, color.b);
            };
            for (let side = 0; side < 6; side++) {
              const center = cell * 18 + side * 3; const a = center + 1; const b = center + 2;
              addVertex(center, true, topColor); addVertex(a, true, topColor); addVertex(b, true, topColor);
              if (raised) {
                addVertex(a, false, visitorBlue); addVertex(b, false, visitorBlue); addVertex(b, true, topColor);
                addVertex(a, false, visitorBlue); addVertex(b, true, topColor); addVertex(a, true, topColor);
              }
            }
          }
          stackGeometry.setAttribute("position", new THREE.Float32BufferAttribute(positions, 3));
          stackGeometry.setAttribute("color", new THREE.Float32BufferAttribute(stackColors, 3));
          stackGeometry.computeBoundingSphere();
          container.setAttribute("data-visitor-hexagons", String(active.size));
          container.setAttribute("data-visitor-raised", String(raisedCount));
          container.setAttribute("data-visitor-flat", String(active.size - raisedCount));
          container.setAttribute("data-visitor-stack-total", String([...active.values()].reduce((sum, count) => sum + count, 0)));
          container.setAttribute("data-visitor-region", current.region);
          if (previousRegion !== current.region && !current.flat) {
            const centers: Record<LiveRegion, [number, number]> = { all: [15, 0], us: [38, -100], eu: [52, 15], asia: [35, 100], africa: [5, 20], "south-america": [-20, -60], oceania: [-25, 135] };
            const [lat, lon] = centers[current.region];
            globe.rotation.set(lat * Math.PI / 180, -lon * Math.PI / 180, 0, "XYZ");
          }
          previousRegion = current.region;
        }
        if (wasFlat !== view.current.flat) {
          wasFlat = view.current.flat; sphere.visible = !wasFlat;
          dotGeometry.setAttribute("position", new THREE.Float32BufferAttribute(wasFlat ? mapPoints : globePoints, 3));
          globe.rotation.set(wasFlat ? 0 : 0.05, wasFlat ? 0 : -0.28, wasFlat ? 0 : -0.12);
        }
        stackGeometry.drawRange.count = view.current.flat ? 0 : Infinity;
        if (view.current.focus !== lastFocus) {
          lastFocus = view.current.focus;
          pin.visible = Boolean(lastFocus);
          if (lastFocus) {
            const phi = lastFocus.lat * Math.PI / 180; const theta = lastFocus.lon * Math.PI / 180;
            pin.position.set(Math.cos(phi) * Math.sin(theta) * 1.025, Math.sin(phi) * 1.025, Math.cos(phi) * Math.cos(theta) * 1.025);
            if (!wasFlat) globe.rotation.set(phi, -theta, 0, "XYZ");
            container.setAttribute("data-marker-city", `${lastFocus.lat},${lastFocus.lon}`);
          } else container.removeAttribute("data-marker-city");
        }
        if (pin.visible) {
          pin.getWorldPosition(pinWorld);
          const facing = wasFlat ? 1 : pinWorld.clone().normalize().dot(camera.position.clone().sub(globe.getWorldPosition(new THREE.Vector3())).normalize());
          pinMaterial.opacity = Math.max(0, Math.min(1, (facing - 0.15) / 0.35));
        }
        renderer.render(scene, camera); frame = requestAnimationFrame(animate);
      };
      animate();
      cleanup = () => { cancelAnimationFrame(frame); observer.disconnect(); container.removeEventListener("wheel", wheel); container.removeEventListener("pointerdown", down); container.removeEventListener("pointermove", move); container.removeEventListener("pointerup", up); container.removeEventListener("pointercancel", up); sphereGeometry.dispose(); sphereMaterial.dispose(); dotGeometry.dispose(); dotMaterial.dispose(); stackGeometry.dispose(); stackMaterial.dispose(); pinTexture.dispose(); pinMaterial.dispose(); renderer.dispose(); renderer.domElement.remove(); };
    })().catch(() => { if (!stopped) container.setAttribute("data-map-error", "true"); });
    return () => { stopped = true; cleanup(); };
  }, []);
  return <div ref={host} className={`live-globe${flat ? " is-flat" : ""}`} role="img" aria-label={flat ? "World map" : "Interactive world globe"} />;
}