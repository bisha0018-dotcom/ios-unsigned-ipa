import { useAppTranslation } from "@/components/AppTranslation";
import { AppText } from "@/components/AppTranslation";
import { useMemo, useState } from "react";
import { Banknote, Check, ChevronLeft, Globe2, Search } from "lucide-react";
import { Button } from "@/components/ui/button";
import { APP_LANGUAGES } from "@/lib/app-locale";
import { CURRENCIES } from "@/lib/currency";

type View = "main" | "language" | "currency";

export function LocalePicker({ language, currencyCode, onLanguageChange, onCurrencyChange }: {
  language: string;
  currencyCode: string;
  onLanguageChange: (code: string) => void;
  onCurrencyChange: (code: string) => void;
}) {
  const translateAttribute = useAppTranslation();
  const [view, setView] = useState<View>("main");
  const [query, setQuery] = useState("");
  const selectedLanguage = APP_LANGUAGES.find(([code]) => code === language) ?? APP_LANGUAGES[0];
  const selectedCurrency = CURRENCIES.find((item) => item.code === currencyCode) ?? CURRENCIES[0];
  const normalized = query.trim().toLocaleLowerCase();
  const languages = useMemo(() => APP_LANGUAGES.filter(([code, name]) => !normalized || `${code} ${name}`.toLocaleLowerCase().includes(normalized)), [normalized]);
  const currencies = useMemo(() => CURRENCIES.filter((item) => !normalized || `${item.code} ${item.label} ${item.symbol}`.toLocaleLowerCase().includes(normalized)), [normalized]);

  if (view === "main") return (
    <div className="grid grid-cols-2 gap-2">
      <Button variant="ghost" onClick={() => setView("language")} className="h-auto justify-start gap-3 rounded-lg border border-gray-200 bg-white px-3 py-3 text-left hover:bg-gray-50">
        <Globe2 className="h-5 w-5 shrink-0 text-gray-500" /><span className="min-w-0"><span className="block text-[12px] text-gray-500"><AppText>Language</AppText></span><span className="block truncate text-[14px] font-semibold text-gray-900">{selectedLanguage?.[1]}</span></span>
      </Button>
      <Button variant="ghost" onClick={() => setView("currency")} className="h-auto justify-start gap-3 rounded-lg border border-gray-200 bg-white px-3 py-3 text-left hover:bg-gray-50">
        <Banknote className="h-5 w-5 shrink-0 text-gray-500" /><span className="min-w-0"><span className="block text-[12px] text-gray-500"><AppText>Currency</AppText></span><span className="block truncate text-[14px] font-semibold text-gray-900">{selectedCurrency?.symbol} {selectedCurrency?.code}</span></span>
      </Button>
    </div>
  );

  const isLanguage = view === "language";
  return (
    <div>
      <div className="mb-3 flex items-center gap-2">
        <Button variant="ghost" size="icon" onClick={() => { setView("main"); setQuery(""); }} className="h-8 w-8 rounded-full bg-gray-100 text-gray-900 hover:bg-gray-200" aria-label={translateAttribute("Back")}><ChevronLeft className="h-5 w-5" /></Button>
        <p className="text-[15px] font-semibold text-gray-900"><AppText>{isLanguage ? "Language" : "Currency"}</AppText></p>
      </div>
      <label className="mb-3 flex h-10 items-center gap-2 rounded-lg bg-gray-100 px-3">
        <Search className="h-4 w-4 text-gray-400" /><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder={`Search ${isLanguage ? "languages" : "currencies"}`} className="min-w-0 flex-1 bg-transparent text-[14px] text-gray-900 outline-none placeholder:text-gray-400" />
      </label>
      <div className="max-h-[42vh] space-y-0.5 overflow-y-auto overscroll-contain">
        {isLanguage ? languages.map(([code, name]) => (
          <Button key={code} variant="ghost" onClick={() => { onLanguageChange(code); setView("main"); setQuery(""); }} className="h-11 w-full justify-between rounded-lg px-3 text-[14px] font-medium text-gray-900 hover:bg-gray-100">
            <span>{name}</span>{code === language && <Check className="h-4 w-4 text-green-600" />}
          </Button>
        )) : currencies.map((item) => (
          <Button key={item.code} variant="ghost" onClick={() => { onCurrencyChange(item.code); setView("main"); setQuery(""); }} className="h-12 w-full justify-start gap-3 rounded-lg px-3 text-gray-900 hover:bg-gray-100">
            <span className="w-10 text-left text-[14px] font-bold">{item.symbol}</span><span className="min-w-0 flex-1 truncate text-left text-[14px] font-medium"><AppText>{item.label}</AppText></span><span className="text-[11px] text-gray-400">{item.code}</span>{item.code === currencyCode && <Check className="h-4 w-4 text-green-600" />}
          </Button>
        ))}
      </div>
    </div>
  );
}