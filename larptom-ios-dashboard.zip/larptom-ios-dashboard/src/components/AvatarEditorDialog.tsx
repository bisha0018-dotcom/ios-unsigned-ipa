import { AppText } from "@/components/AppTranslation";
import { Image as ImageIcon, Palette } from "lucide-react";
import { useEffect, useRef, useState } from "react";

import { Dialog, DialogContent, DialogTitle } from "@/components/ui/dialog";
import { SWATCHES, type AvatarSettings } from "@/components/app-colors";
import { cn } from "@/lib/utils";

type Props = {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  value: AvatarSettings;
  onChange: (value: AvatarSettings) => void;
};

function SwatchGrid({
  label,
  selected,
  onSelect,
}: {
  label: string;
  selected: string;
  onSelect: (color: string) => void;
}) {
  return (
    <div className="space-y-2">
      <p className="text-sm text-muted-foreground"><AppText>{label}</AppText></p>
      <div className="grid grid-cols-6 gap-2">
        {SWATCHES.map((color) => (
          <button
            key={`${label}-${color}`}
            type="button"
            aria-label={color}
            onClick={() => onSelect(color)}
            style={{ backgroundColor: color }}
            className={cn(
              "h-8 w-full rounded-lg border border-border/40 transition-transform active:scale-95",
              selected === color && "ring-2 ring-white ring-offset-2 ring-offset-card",
            )}
          />
        ))}
      </div>
      <div
        className="h-7 w-full rounded-md border border-border/40"
        style={{ backgroundColor: selected }}
      />
    </div>
  );
}

export function AvatarEditorDialog({ open, onOpenChange, value, onChange }: Props) {
  const [draft, setDraft] = useState<AvatarSettings>(value);
  const fileRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (open) setDraft(value);
  }, [open, value]);

  const update = (patch: Partial<AvatarSettings>) => {
    const next = { ...draft, ...patch };
    setDraft(next);
    onChange(next);
  };

  const onPickFile = (file: File | undefined) => {
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => update({ image: String(reader.result), mode: "image" });
    reader.readAsDataURL(file);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="z-[110] max-w-[90vw] gap-4 rounded-2xl border-border/60 bg-card p-4 sm:max-w-sm">
        <DialogTitle className="sr-only"><AppText>Edit avatar</AppText></DialogTitle>

        <div className="grid grid-cols-2 gap-3">
          <button
            type="button"
            onClick={() => {
              update({ mode: "image" });
              fileRef.current?.click();
            }}
            className={cn(
              "flex items-center justify-center gap-2 rounded-lg border px-3 py-2.5 text-sm font-medium text-foreground transition-colors",
              draft.mode === "image"
                ? "border-foreground bg-secondary"
                : "border-border bg-secondary/40",
            )}
          >
            <ImageIcon className="h-4 w-4" /><AppText> Image
          </AppText></button>
          <button
            type="button"
            onClick={() => update({ mode: "color" })}
            className={cn(
              "flex items-center justify-center gap-2 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors",
              draft.mode === "color"
                ? "bg-[#2563eb] text-white"
                : "bg-secondary/40 text-foreground",
            )}
          >
            <Palette className="h-4 w-4" /><AppText> Color
          </AppText></button>
          <input
            ref={fileRef}
            className="hidden"
            accept="image/*"
            type="file"
            onChange={(event) => onPickFile(event.target.files?.[0])}
          />
        </div>

        <input
          value={draft.initials}
          onChange={(event) => update({ initials: event.target.value.slice(0, 3) })}
          className="w-full rounded-lg bg-secondary/60 px-3 py-2.5 text-center text-sm font-semibold text-foreground outline-none focus:ring-2 focus:ring-ring"
        />

        <SwatchGrid
          label="Background"
          selected={draft.background}
          onSelect={(color) => update({ background: color, mode: "color" })}
        />
        <SwatchGrid
          label="Text color"
          selected={draft.textColor}
          onSelect={(color) => update({ textColor: color })}
        />
      </DialogContent>
    </Dialog>
  );
}
