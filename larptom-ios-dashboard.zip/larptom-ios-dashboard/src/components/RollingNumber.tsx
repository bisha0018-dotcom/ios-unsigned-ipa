import { useEffect, useRef, useState } from "react";

const CYCLES = 2; // full 0-9 spins before settling

function DigitColumn({
  digit,
  index,
  totalDigits,
  animKey,
  animateOnMount,
}: {
  digit: string;
  index: number;
  totalDigits: number;
  animKey: string | number;
  animateOnMount: boolean;
}) {
  const target = Number(digit);
  const [offset, setOffset] = useState(target);
  const [animating, setAnimating] = useState(false);

  // Earlier digits settle quickly; the last digit takes much longer so it visibly slows down.
  const isLast = index === totalDigits - 1;
  const duration = isLast ? 1550 : 720;
  const easing = isLast
    ? "cubic-bezier(0.1, 0.9, 0.2, 1)"
    : "cubic-bezier(0.25, 0.75, 0.2, 1)";
  const delay = index * 60;

  // Derived-state tracker: bumps `roll` whenever this digit (or the anim key)
  // actually changes, so unchanged digits never re-roll.
  const [tracked, setTracked] = useState(() => ({
    digit: target,
    key: animKey,
    roll: animateOnMount ? 1 : 0,
  }));
  if (tracked.digit !== target || tracked.key !== animKey) {
    setTracked({ digit: target, key: animKey, roll: tracked.roll + 1 });
  }
  const rollId = tracked.roll;

  useEffect(() => {
    if (rollId === 0) {
      setAnimating(false);
      setOffset(target);
      return;
    }
    setAnimating(false);
    setOffset(target + CYCLES * 10);
    let inner = 0;
    const outer = requestAnimationFrame(() => {
      inner = requestAnimationFrame(() => {
        setAnimating(true);
        setOffset(target);
      });
    });
    return () => {
      cancelAnimationFrame(outer);
      cancelAnimationFrame(inner);
    };
  }, [rollId, target]);

  return (
    <span
      className="inline-block overflow-hidden"
      style={{ height: "1em", lineHeight: "1em", verticalAlign: "baseline" }}
      aria-hidden="true"
    >
      <span
        className="block"
        style={{
          transform: `translateY(-${offset}em)`,
          transition: animating
            ? `transform ${duration}ms ${easing} ${delay}ms`
            : "none",
        }}
      >
        {Array.from({ length: CYCLES * 10 + 10 }, (_, i) => (
          <span key={i} className="block" style={{ height: "1em", lineHeight: "1em" }}>
            {i % 10}
          </span>
        ))}
      </span>
    </span>
  );
}

/**
 * Renders a numeric string where digits roll into place like an odometer.
 * A digit only rolls when it actually changes (or when animKey changes, e.g.
 * switching time frame). Digits settle left-to-right and the last one slows
 * way down. Non-digit characters (., , % €) stay static.
 */
export function RollingNumber({
  value,
  animKey,
  className,
}: {
  value: string;
  animKey: string | number;
  className?: string;
}) {
  const mountedRef = useRef(false);
  useEffect(() => {
    mountedRef.current = true;
  }, []);

  const chars = String(value).split("");
  const totalDigits = chars.filter((ch) => /\d/.test(ch)).length;

  let digitIndex = 0;
  return (
    <span className={`inline-flex items-baseline ${className ?? ""}`}>
      {chars.map((ch, i) => {
        if (/\d/.test(ch)) {
          const idx = digitIndex;
          digitIndex += 1;
          return (
            <DigitColumn
              key={`d${i}`}
              digit={ch}
              index={idx}
              totalDigits={totalDigits}
              animKey={animKey}
              animateOnMount={mountedRef.current}
            />
          );
        }
        return <span key={`c${i}`}>{ch}</span>;
      })}
      <span className="sr-only">{value}</span>
    </span>
  );
}
