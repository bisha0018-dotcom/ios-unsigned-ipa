import { useId } from "react";
import { AppText, useAppTranslation } from "@/components/AppTranslation";
import { formatLiveNumber, type LiveViewData } from "@/lib/live-view-data";
import { LiveViewEmpty } from "@/components/LiveViewEmpty";

/** Static reference funnel, isolated from activity and payment reporting. */
export function LiveViewBehavior({ data }: { data: LiveViewData }) {
  const translate = useAppTranslation();
  const gradientId = `live-behavior-${useId().replace(/:/g, "")}`;
  const stages = [{ label: "Active carts", value: data.carts }, { label: "Checking out", value: data.checkingOut }, { label: "Purchased", value: data.orders }];
  return (
    <section className="live-metric-card live-behavior" aria-label={translate("Customer behavior")}>
      <div className="live-metric-heading"><h2><AppText>Customer behavior</AppText></h2></div>
      {data.sessions === 0 ? <><div className="live-behavior-zero">{stages.map(stage => <div key={stage.label}><span><AppText>{stage.label}</AppText></span><p>0</p></div>)}</div><LiveViewEmpty /></> : <div className="live-behavior-chart">
        <div className="live-behavior-labels">
          {stages.map(stage => <div key={stage.label}><span><AppText>{stage.label}</AppText></span><p>{formatLiveNumber(stage.value)}</p></div>)}
        </div>
        <svg viewBox="0 0 329 197" role="img" aria-label={stages.map(stage => `${translate(stage.label)}: ${stage.value}`).join(", ")}>
          <defs><linearGradient id={gradientId} x1="0%" x2="100%"><stop offset="0%" className="live-behavior-gradient-start" /><stop offset="100%" className="live-behavior-gradient-end" /></linearGradient></defs>
          <path className="live-behavior-divider" d="M116.8 0V197M235.6 0V197" />
          {stages.map((stage, i) => {
            const x = i * 118.8;
            const y = 197 - 110 * stage.value / Math.max(1, data.carts);
            return <g key={stage.label}><rect className="live-behavior-bar" x={x} y={y} width="89.1" height={197 - y} rx="3"><title>{translate(stage.label)}: {stage.value}</title></rect>{i < 2 && <path fill={`url(#${gradientId})`} d={`M${x + 90} ${y}L${x + 115.8} ${197 - 110 * (stages[i + 1]?.value ?? 0) / Math.max(1, data.carts)}V197H${x + 90}Z`} />}</g>;
          })}
        </svg>
      </div>}
    </section>
  );
}