import { useEffect, useRef, useState, type ReactNode } from "react";
import { MenuHomeIcon, MenuOrdersIcon, MenuProductsIcon, MenuCustomersIcon, MenuGrowthIcon, MenuDiscountsIcon, MenuContentIcon, MenuMarketsIcon, MenuSettingsIcon, MenuChevronDownIcon, MenuCloseIcon, MenuQuickSaleIcon } from "@/components/MobileNavigationIcons";
import { Button } from "@/components/ui/button";
import { useAppTranslation } from "@/components/AppTranslation";

const SUBMENU_MS = 520;

const ITEMS = [
  { label: "Home", icon: MenuHomeIcon, tab: "home" },
  { label: "Orders", icon: MenuOrdersIcon, tab: "clips", children: ["Drafts", "Abandoned checkouts"] },
  { label: "Products", icon: MenuProductsIcon, tab: "names", children: ["Collections", "Inventory", "Purchase orders", "Transfers", "Gift cards"] },
  { label: "Customers", icon: MenuCustomersIcon, children: ["Segments"] },
  { label: "Growth", icon: MenuGrowthIcon, children: ["Analytics", "Reports", "Live View"] },
  { label: "Discounts", icon: MenuDiscountsIcon },
  { label: "Content", icon: MenuContentIcon, children: ["Metaobjects", "Files", "Menus", "Blog posts"] },
  { label: "Markets", icon: MenuMarketsIcon, children: ["Catalogs"] },
];

/** Slide the sub navigation down when opening and back up when closing. */
function Submenu({ open, mounted, children }: { open: boolean; mounted: boolean; children: ReactNode }) {
  const innerRef = useRef<HTMLDivElement>(null);
  const [height, setHeight] = useState(0);

  useEffect(() => {
    const el = innerRef.current;
    if (!el) return;
    const measure = () => setHeight(el.scrollHeight);
    // Measure on the next frame so the browser paints height 0 first and the slide can animate.
    const frame = requestAnimationFrame(measure);
    const observer = new ResizeObserver(measure);
    observer.observe(el);
    return () => { cancelAnimationFrame(frame); observer.disconnect(); };
  }, [mounted]);

  if (!mounted) return null;

  return <div className="mobile-navigation-children-wrap" data-open={open ? "true" : "false"} style={{ height: open ? height : 0 }}>
    <div ref={innerRef} className="mobile-navigation-children">{children}</div>
  </div>;
}

export function MobileNavigationMenu({ active, onNavigate, onClose, onSettings, exiting = false }: {
  active: string;
  onNavigate: (tab: string) => void;
  onClose: () => void;
  onSettings: () => void;
  exiting?: boolean;
}) {
  const t = useAppTranslation();
  const [selected, setSelected] = useState(ITEMS.find((item) => item.tab === active)?.label ?? "Home");
  const [expanded, setExpanded] = useState<string | null>(null);
  const [closing, setClosing] = useState<string | null>(null);
  const closeRef = useRef<HTMLButtonElement>(null);
  const closeTimer = useRef<number | null>(null);

  const toggle = (label: string) => {
    if (closeTimer.current !== null) window.clearTimeout(closeTimer.current);
    const previous = expanded;
    if (previous === label) {
      setClosing(label);
      setExpanded(null);
    } else {
      setExpanded(label);
      setClosing(previous);
    }
    const pending = previous === label ? label : previous;
    if (pending) closeTimer.current = window.setTimeout(() => {
      closeTimer.current = null;
      setClosing((value) => (value === pending ? null : value));
    }, SUBMENU_MS);
    else closeTimer.current = null;
  };

  useEffect(() => {
    const previousFocus = document.activeElement;
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    closeRef.current?.focus();
    const handleKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") onClose();
      if (event.key !== "Tab") return;
      const controls = document.querySelectorAll<HTMLButtonElement>(".mobile-navigation-menu button");
      const first = controls[0];
      const last = controls[controls.length - 1];
      if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last?.focus(); }
      if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first?.focus(); }
    };
    document.addEventListener("keydown", handleKey);
    return () => {
      document.body.style.overflow = previousOverflow;
      document.removeEventListener("keydown", handleKey);
      if (closeTimer.current !== null) window.clearTimeout(closeTimer.current);
      if (previousFocus instanceof HTMLElement) previousFocus.focus();
    };
  }, [onClose]);

  return <section className="mobile-navigation-menu" data-closing={exiting ? "true" : undefined} role="dialog" aria-modal="true" aria-label={t("Menu")}>
    <nav className="mobile-navigation-list" aria-label={t("Store navigation")}>
      {ITEMS.map((item) => <div key={item.label} className="mobile-navigation-group">
        <Button variant="ghost" className="mobile-navigation-row" data-selected={selected === item.label} onClick={() => {
          if (item.tab) { onNavigate(item.tab); return; }
          setSelected(item.label);
          if (item.children) toggle(item.label);
        }}><item.icon aria-hidden="true" /><span>{t(item.label)}</span></Button>
        {item.children && <Button variant="ghost" size="icon" className="mobile-navigation-expand" aria-label={`${t("Toggle sub navigation")}: ${t(item.label)}`} aria-expanded={expanded === item.label} onClick={() => toggle(item.label)}><MenuChevronDownIcon className={expanded === item.label ? "rotate-180" : ""} /></Button>}
        <Submenu open={expanded === item.label} mounted={expanded === item.label || closing === item.label}>
          {item.children?.map((label) => <Button key={label} variant="ghost" className="mobile-navigation-child" data-selected={selected === label} onClick={() => {
            if (label === "Live View") { onNavigate("live"); return; }
            if (label === "Analytics") { onNavigate("home"); return; }
            setSelected(label);
          }}>{t(label)}</Button>)}
        </Submenu>
      </div>)}
    </nav>
    <footer className="mobile-navigation-footer">
      <Button variant="ghost" size="icon" className="mobile-navigation-action mobile-navigation-settings" aria-label={t("Settings")} onClick={onSettings}><MenuSettingsIcon /></Button>
      <Button variant="ghost" className="mobile-navigation-action mobile-navigation-sale" onClick={() => onNavigate("names")}><MenuQuickSaleIcon aria-hidden="true" /><span>{t("Quick sale")}</span></Button>
      <Button ref={closeRef} variant="ghost" size="icon" className="mobile-navigation-action" aria-label={t("Close menu")} onClick={onClose}><MenuCloseIcon /></Button>
    </footer>
  </section>;
}
