import { useEffect, useRef, useState } from "react";
import sidekickGlyph from "@/assets/sidekick-glyph.png.asset.json";
import profileIcon from "@/assets/nav-profile.png.asset.json";

const EASE = "cubic-bezier(0.3, 0.9, 0.35, 1)";
const ink = "rgb(26, 26, 26)";
const pill = "rgba(0, 0, 0, 0.1) 0px 6px 20px, rgba(0, 0, 0, 0.06) 0px 1px 4px";

/** Bottom-right Sidekick button that morphs into the "Ask anything..." bar (reference markup). */
export function MobileSidekick({ open, onOpenChange, onSettings }: { open: boolean; onOpenChange: (open: boolean) => void; onSettings: () => void }) {
  const [value, setValue] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);
  useEffect(() => { if (open) window.setTimeout(() => inputRef.current?.focus({ preventScroll: true }), 200); }, [open]);

  return <>
    <div aria-hidden="true" style={{ position: "fixed", left: 0, right: 0, bottom: 0, height: 190, background: "linear-gradient(to top, rgb(255,255,255) 55%, rgba(255,255,255,0))", zIndex: 28, opacity: open ? 1 : 0, transition: "opacity 220ms", pointerEvents: "none" }} />
    {/* Top action row */}
    <div style={{ position: "fixed", left: 16, right: 16, bottom: 108, zIndex: 61, display: "flex", gap: 10, opacity: open ? 1 : 0, transform: open ? "none" : "translateY(10px)", transition: `opacity 180ms ${open ? "120ms" : "0ms"}, transform 240ms ${EASE}`, pointerEvents: open ? "auto" : "none" }}>
      <button type="button" aria-label="Chat history" style={{ display: "inline-flex", alignItems: "center", gap: 8, height: 44, padding: "0 16px", borderRadius: 22, border: "none", background: "rgb(255,255,255)", boxShadow: pill, fontSize: 15, fontWeight: 600, color: ink }}>
        <svg width="19" height="19" viewBox="0 0 20 20" aria-hidden="true" style={{ flex: "0 0 auto" }}>
          <path d="M3.5 10a6.5 6.5 0 1 0 1.9-4.6" fill="none" stroke="#1a1a1a" strokeWidth="1.6" strokeLinecap="round" />
          <path d="M5.2 2.8v2.8H8" fill="none" stroke="#1a1a1a" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M10 6.8V10l2.2 1.4" fill="none" stroke="#1a1a1a" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
        Chat history
      </button>
      <button type="button" aria-label="Sidekick settings" onClick={() => { onOpenChange(false); onSettings(); }} style={{ width: 44, height: 44, borderRadius: 22, border: "none", background: "rgb(255,255,255)", boxShadow: pill, display: "inline-flex", alignItems: "center", justifyContent: "center" }}>
        <span aria-hidden="true" style={{ display: "inline-flex", width: 19, height: 19, color: ink, flex: "0 0 auto" }}>
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" width="19" height="19" fill="currentColor">
            <path fillRule="evenodd" d="M9.095 6.25a3.001 3.001 0 0 1 5.81 0h1.345a.75.75 0 0 1 0 1.5h-1.345a3.001 3.001 0 0 1-5.81 0h-5.345a.75.75 0 0 1 0-1.5h5.345Zm1.405.75a1.5 1.5 0 1 1 3 0 1.5 1.5 0 0 1-3 0Z" />
            <path fillRule="evenodd" d="M8 16a3.001 3.001 0 0 0 2.905-2.25h5.345a.75.75 0 0 0 0-1.5h-5.345a3.001 3.001 0 0 0-5.81 0h-1.345a.75.75 0 0 0 0 1.5h1.345a3.001 3.001 0 0 0 2.905 2.25Zm1.5-3a1.5 1.5 0 1 0-3 0 1.5 1.5 0 0 0 3 0Z" />
          </svg>
        </span>
      </button>
    </div>
    {/* Ask bar */}
    <div style={{ position: "fixed", left: 16, right: 16, bottom: 36, height: 56, zIndex: 61, pointerEvents: "none" }}>
      <div style={{ position: "absolute", left: 0, top: 0, bottom: 0, right: 64, borderRadius: 28, background: "rgb(255,255,255)", boxShadow: pill, display: "flex", alignItems: "center", padding: "0 12px 0 14px", gap: 10, opacity: open ? 1 : 0, transform: open ? "none" : "scaleX(0.2)", transformOrigin: "right center", transition: `opacity 180ms ${open ? "120ms" : "0ms"}, transform 240ms ${EASE}`, pointerEvents: open ? "auto" : "none" }}>
        <img alt="" src={sidekickGlyph.url} style={{ width: 26, height: 25, flex: "0 0 auto" }} />
        <input ref={inputRef} placeholder="Ask anything..." autoCapitalize="off" autoComplete="off" spellCheck={false} value={value} onChange={(e) => setValue(e.target.value)} onKeyDown={(e) => { if (e.key === "Enter") setValue(""); }}
          style={{ flex: "1 1 0%", minWidth: 0, border: "none", outline: "none", background: "transparent", fontSize: 17, fontWeight: 500, color: ink, caretColor: "rgb(52,120,246)" }} />
        <button type="button" aria-label="Add" style={{ border: "none", background: "transparent", padding: 4, display: "inline-flex" }}>
          <span aria-hidden="true" style={{ display: "inline-flex", width: 23, height: 23, color: ink }}>
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" width="23" height="23" fill="currentColor"><path d="M10.75 5.75c0-.414-.336-.75-.75-.75s-.75.336-.75.75v3.5h-3.5c-.414 0-.75.336-.75.75s.336.75.75.75h3.5v3.5c0 .414.336.75.75.75s.75-.336.75-.75v-3.5h3.5c.414 0 .75-.336.75-.75s-.336-.75-.75-.75h-3.5v-3.5Z" /></svg>
          </span>
        </button>
        <button type="button" aria-label="Voice" style={{ border: "none", background: "transparent", padding: 4, display: "inline-flex" }}>
          <svg width="23" height="23" viewBox="0 0 23 23" aria-hidden="true">
            <rect x="3.1" y="9" width="2.2" height="5" rx="1.1" fill="#1a1a1a" />
            <rect x="8.1" y="5.5" width="2.2" height="12" rx="1.1" fill="#1a1a1a" />
            <rect x="13.1" y="8" width="2.2" height="7" rx="1.1" fill="#1a1a1a" />
            <rect x="18.1" y="10" width="2.2" height="3" rx="1.1" fill="#1a1a1a" />
          </svg>
        </button>
      </div>
    </div>
  </>;
}

/** The morphing round button: Sidekick glyph when closed, X when open. */
export function SidekickToggle({ open, onToggle }: { open: boolean; onToggle: () => void }) {
  return <button type="button" aria-label={open ? "Close Sidekick" : "Profile"} onClick={onToggle}
    style={{ position: "relative", width: open ? 56 : 54, height: open ? 56 : 54, borderRadius: 28, border: open ? "1px solid transparent" : "1px solid rgb(229,231,235)", background: "rgb(255,255,255)", boxShadow: open ? pill : "0 4px 6px -1px rgba(0,0,0,.1), 0 2px 4px -2px rgba(0,0,0,.1)", transition: `width 240ms ${EASE}, height 240ms ${EASE}, box-shadow 200ms`, display: "inline-flex", alignItems: "center", justifyContent: "center", touchAction: "manipulation" }}>
    <img alt="" src={profileIcon.url} style={{ position: "absolute", width: 24, height: 24, borderRadius: 12, opacity: open ? 0 : 1, transform: open ? "rotate(45deg) scale(0.7)" : "none", transition: `opacity 160ms, transform 240ms ${EASE}` }} />
    <span aria-hidden="true" style={{ display: "inline-flex", width: 24, height: 24, color: ink, position: "absolute", opacity: open ? 1 : 0, transform: open ? "none" : "rotate(-45deg) scale(0.7)", transition: `opacity 160ms, transform 240ms ${EASE}` }}>
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" width="24" height="24" fill="currentColor"><path d="M13.97 15.03a.75.75 0 1 0 1.06-1.06l-3.97-3.97 3.97-3.97a.75.75 0 0 0-1.06-1.06l-3.97 3.97-3.97-3.97a.75.75 0 0 0-1.06 1.06l3.97 3.97-3.97 3.97a.75.75 0 1 0 1.06 1.06l3.97-3.97 3.97 3.97Z" /></svg>
    </span>
  </button>;
}
