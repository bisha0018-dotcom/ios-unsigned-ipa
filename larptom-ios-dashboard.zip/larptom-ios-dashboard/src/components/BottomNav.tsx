import { useAppTranslation } from "@/components/AppTranslation";
import { useRef, useState } from "react";
import { EditPanel } from "@/components/EditPanel";
import { PushNotificationPanel } from "@/components/PushNotificationPanel";
import { ProfilePanel } from "@/components/ProfilePanel";
import OrdersOverlay from "@/components/OrdersOverlay";
import ProductsOverlay from "@/components/ProductsOverlay";
import { LiveViewOverlay } from "@/components/LiveViewOverlay";
import { MobileNavigationMenu } from "@/components/MobileNavigationMenu";
import homeIcon from "@/assets/home-icon.png.asset.json";
import homeIconActive from "@/assets/home-icon-active.png.asset.json";
import clipsIcon from "@/assets/nav-clips.png.asset.json";
import clipsIconActive from "@/assets/clips-icon-active.png.asset.json";
import tagIcon from "@/assets/nav-tag.png.asset.json";
import { MobileSidekick, SidekickToggle } from "@/components/MobileSidekick";


const TABS = [
  { id: "home", alt: "Home", icon: homeIcon.url, activeIcon: homeIconActive.url },
  { id: "clips", alt: "Clips", icon: clipsIcon.url, activeIcon: clipsIconActive.url },
  { id: "names", alt: "Names", icon: tagIcon.url, activeIcon: tagIcon.url },
];

/** Floating bottom navigation: search pill, tab pill, profile pill. */
export function BottomNav({
  expiresAt,
  licenseKey,
  onLogout,
  active,
  onActiveChange,
  profileOpen,
  onProfileOpenChange,
  pushOpen,
  onPushOpenChange,
}: {
  expiresAt?: string | undefined;
  licenseKey?: string | undefined;
  onLogout?: (() => void) | undefined;
  active: string;
  onActiveChange: (id: string) => void;
  profileOpen: boolean;
  onProfileOpenChange: (open: boolean) => void;
  pushOpen: boolean;
  onPushOpenChange: (open: boolean) => void;
}) {
  const translateAttribute = useAppTranslation();
  const ordersOpen = active === "clips";
  const productsOpen = active === "names";
  const [editOpen, setEditOpen] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [menuClosing, setMenuClosing] = useState(false);
  const menuCloseTimer = useRef<number | null>(null);
  const openMenu = () => {
    if (menuCloseTimer.current !== null) window.clearTimeout(menuCloseTimer.current);
    menuCloseTimer.current = null;
    setMenuClosing(false);
    setMenuOpen(true);
  };
  const closeMenu = () => {
    if (menuCloseTimer.current !== null) window.clearTimeout(menuCloseTimer.current);
    setMenuOpen(false);
    setMenuClosing(true);
    menuCloseTimer.current = window.setTimeout(() => {
      menuCloseTimer.current = null;
      setMenuClosing(false);
    }, 220);
  };
  const [sidekickOpen, setSidekickOpen] = useState(false);
  const fade = { opacity: sidekickOpen ? 0 : 1, transform: sidekickOpen ? "scale(0.92)" : "none", transition: "opacity 160ms, transform 240ms cubic-bezier(0.3, 0.9, 0.35, 1)", pointerEvents: sidekickOpen ? "none" as const : "auto" as const };

  return (
    <>
      {ordersOpen && (
        <div className="fixed inset-0 z-[55] mx-auto flex w-full max-w-[430px] flex-col bg-black">
          <OrdersOverlay />
        </div>
      )}
      {productsOpen && (
        <div className="fixed inset-0 z-[55] mx-auto flex w-full max-w-[430px] flex-col bg-black">
          <ProductsOverlay />
        </div>
      )}
      {active === "live" && (
        <div className="fixed inset-0 z-[55] mx-auto flex w-full max-w-[430px] flex-col bg-editor-background">
          <LiveViewOverlay />
        </div>
      )}
    <div className="pointer-events-none fixed right-0 bottom-0 left-0 z-[60]">
      <div className="absolute bottom-0 left-0 h-28 w-full bg-gradient-to-t from-white/70 via-white/40 to-transparent" />
      <div className="pointer-events-auto relative z-[30] flex items-center justify-between gap-1 px-1 pt-1 pb-9">
        <div style={fade} className="ml-4 rounded-full border border-gray-200 bg-white p-1.5 shadow-md">
          <button
            type="button"
            aria-label={translateAttribute("Search")}
            onClick={() => setEditOpen(true)}
            className="relative flex h-10 w-10 items-center justify-center rounded-full transition-all"
          >
            <svg
              width="22"
              height="22"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="h-[22px] w-[22px] text-gray-600"
            >
              <circle cx="11" cy="11" r="8" />
              <path d="m21 21-4.35-4.35" />
            </svg>
          </button>
        </div>

        <div style={fade} className="max-w-56 flex-1 rounded-full border border-gray-200 bg-white shadow-md">
          <div className="flex items-center justify-around px-0 py-1.5">
            {TABS.map((tab) => (
              <button
                key={tab.id}
                type="button"
                 onClick={() => onActiveChange(tab.id)}
                aria-label={translateAttribute(tab.alt)}
                style={{ touchAction: "manipulation" }}
                className={`relative flex h-10 w-10 flex-col items-center justify-center rounded-full transition-all ${
                  active === tab.id ? "bg-[#efefef] shadow-[0_0_0_3px_#efefef]" : ""
                }`}
              >
                <img
                  src={active === tab.id ? tab.activeIcon : tab.icon}
                  alt={translateAttribute(tab.alt)}
                  className={`h-[22px] w-[22px] transition-all ${
                    tab.id === "names" && active === tab.id ? "brightness-0" : ""
                  }`}
                />
              </button>
            ))}
            <button
              type="button"
              aria-label={translateAttribute("Menu")}
              aria-current={active === "live" ? "page" : undefined}
              onClick={openMenu}
              className={`relative flex h-10 w-10 flex-col items-center justify-center rounded-full transition-all ${active === "live" ? "bg-[#efefef] shadow-[0_0_0_3px_#efefef]" : ""}`}
            >

              <svg
                width="22"
                height="22"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="h-[22px] w-[22px] text-gray-600"
              >
                <line x1="4" x2="20" y1="6" y2="6" />
                <line x1="4" x2="20" y1="12" y2="12" />
                <line x1="4" x2="20" y1="18" y2="18" />
              </svg>
            </button>
          </div>
        </div>

        <div className="mr-4"><SidekickToggle open={sidekickOpen} onToggle={() => setSidekickOpen((v) => !v)} /></div>
      </div>
      <MobileSidekick open={sidekickOpen} onOpenChange={setSidekickOpen} onSettings={() => setEditOpen(true)} />
      <EditPanel open={editOpen} onClose={() => setEditOpen(false)} licenseKey={licenseKey} expiresAt={expiresAt} onLogout={onLogout} onOpenAdmin={() => { setEditOpen(false); onProfileOpenChange(true); }} />
      {(menuOpen || menuClosing) && <MobileNavigationMenu active={active} exiting={menuClosing} onClose={closeMenu} onNavigate={(tab) => { onActiveChange(tab); closeMenu(); }} onSettings={() => { closeMenu(); setEditOpen(true); }} />}
       <PushNotificationPanel open={pushOpen} onClose={() => onPushOpenChange(false)} />
      <ProfilePanel
        open={profileOpen}
         onClose={() => onProfileOpenChange(false)}
        expiresAt={expiresAt}
        licenseKey={licenseKey}
      />

    </div>
    </>
  );
}
