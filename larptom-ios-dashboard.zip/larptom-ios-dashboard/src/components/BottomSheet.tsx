import { AppText } from "@/components/AppTranslation";
import { useAppTranslation } from "@/components/AppTranslation";
import { useEffect, useState } from "react";
import { createPortal } from "react-dom";

export function BottomSheet({
  open,
  onClose,
  title,
  subtitle,
  children,
}: {
  open: boolean;
  onClose: () => void;
  title: string;
  subtitle?: string;
  children: React.ReactNode;
}) {
  const translate = useAppTranslation();
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);

  if (!open || !mounted) return null;

  return createPortal(
    <div className="fixed inset-0 z-[110]">
      <div
        className="absolute inset-0 bg-black/40"
        onClick={onClose}
        aria-hidden
      />
      <div className="absolute right-0 bottom-0 left-0 flex justify-center">
        <div
          role="dialog"
          aria-label={translate(title)}
          className="w-full rounded-t-[1.75rem] bg-white px-0 pt-3 pb-6 text-gray-900 shadow-2xl"
        >
          <div className="mx-auto mb-3 h-1.5 w-10 rounded-full bg-gray-200" />
          <div className="px-5 text-center">
            <h3 className="text-[17px] font-semibold text-gray-900"><AppText>{title}</AppText></h3>
            {subtitle ? (
              <p className="mt-1 text-[13px] text-gray-500"><AppText>{subtitle}</AppText></p>
            ) : null}
          </div>
          {children}
        </div>
      </div>
    </div>,
    document.body
  );
}
