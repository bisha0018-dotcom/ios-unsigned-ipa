import { useEffect, useMemo, useRef, useState } from "react";
import { metricsKey, rangePointLabels, rangeTicks, useDateRange } from "@/lib/date-range";
import { ChartScrubTooltip } from "@/components/ChartScrubTooltip";
import { onStoreChange, readChartShape, readStore, writeStore } from "@/lib/app-store";

const SHOW_COMPARISON_KEY = "bisha:show-comparison";

/** The dashed comparison line shows by default and can be toggled off. */
function showComparisonLine() {
  return readStore(SHOW_COMPARISON_KEY, "true") !== "false";
}

/** Re-renders the chart when the shape token changes (randomize / manual edit). */
function useChartShape() {
  const [token, setToken] = useState("0");
  useEffect(() => {
    setToken(readChartShape());
    return onStoreChange(() => setToken(readChartShape()));
  }, []);
  return token;
}

import { ComposedChart, Line, ReferenceLine, ResponsiveContainer, XAxis, YAxis } from "recharts";

export type ChartMetric = {
  label: string;
  value: string;
  prefix?: string | undefined;
  suffix?: string | undefined;
  down?: boolean | undefined;
};

/** Parse a European formatted number string ("591.760,03") into a number. */
function parseValue(raw: string | undefined | null) {
  if (!raw) return 0;
  const text = String(raw);
  // Legacy exponential-corrupted entries ("1e+21") parse as garbage — treat
  // them as zero so the chart falls back to its clean zero state.
  if (/e/i.test(text)) return 0;
  const cleaned = text
    .replace(/\./g, "")
    .replace(",", ".")
    .replace(/[^\d.]/g, "");
  const n = Number.parseFloat(cleaned);
  return Number.isFinite(n) ? n : 0;
}

/** Round a peak up to a pleasant axis maximum divisible by 3. */
function niceMax(peak: number) {
  if (peak <= 0) return 100;
  const magnitude = Math.pow(10, Math.floor(Math.log10(peak)));
  const steps = [1, 1.5, 2, 2.5, 3, 4, 5, 7.5, 10];
  for (const s of steps) {
    const candidate = s * magnitude;
    if (candidate >= peak) return candidate;
  }
  return 10 * magnitude;
}

/** The same seeded, multi-frequency wave used by Pixel Perfect Clone. */
function seededRand(seed: number) {
  let state = seed | 0 || 1;
  return () => {
    state = (state * 16807) % 2147483647;
    return (state % 100000) / 100000;
  };
}

// One randomized value per time bucket — same structure as the admin Insights
// chart (24 hours, 7 days, 30 days, 12 months), so short ranges aren't wavy.
function seededSeries(seed: number, max: number, points: number) {
  const rand = seededRand(seed);
  const raw = Array.from({ length: points }, () => 0.15 + rand() * 0.85);
  const rawPeak = Math.max(...raw, 1e-6);
  return raw.map((value) => (value / rawPeak) * max * 0.92);
}

function copiedPointCount(range: ReturnType<typeof useDateRange>) {
  if (range === "today" || range === "yesterday") return 24;
  if (range === "7d") return 7;
  if (range === "30d") return 30;
  return 12;
}

function hash(str: string) {
  let h = 0;
  for (let i = 0; i < str.length; i++) h = (h * 31 + str.charCodeAt(i)) % 1000;
  return h / 100;
}

const trimZero = (s: string) => s.replace(/\.0$/, "");

function formatTick(value: number, metric: ChartMetric) {
  const prefix = metric.prefix ?? "";
  const suffix = metric.suffix ?? "";
  if (!Number.isFinite(value)) return `${prefix}0`;
  if (suffix === "%") return `${Math.round(value)}%`;
  if (value === 0) return `${prefix}0`;
  if (value >= 1e9) return `${prefix}${trimZero((value / 1e9).toFixed(1))}B`;
  if (value >= 1e6) return `${prefix}${trimZero((value / 1e6).toFixed(1))}M`;
  if (value >= 1000) return `${prefix}${trimZero((value / 1000).toFixed(1))}K`;
  return `${prefix}${Math.round(value)}`;
}

type EditingLine = "solid" | "dashed";

function editStorageKey(metric: string, range: string, line: EditingLine) {
  // v3 isolates clean edits from earlier malformed chart-editor data.
  return `bisha:chart-edit-v3:${range}:${metric}:${line}`;
}

/** Round a dragged axis maximum to a realistic, readable step. */
function niceAxisValue(value: number) {
  const safe = Math.max(1, value);
  const step = Math.pow(10, Math.floor(Math.log10(safe))) / 2;
  return Math.max(step, Math.round(safe / step) * step);
}

/** Format a number in European notation: 1.234.567,89 */
function formatEu(value: number, decimals: number) {
  // Clamp so toFixed never falls back to exponential strings ("1e+21") that
  // corrupt the stored metric value beyond repair.
  const safe = Number.isFinite(value) ? Math.min(Math.max(value, 0), 999_999_999) : 0;
  const fixed = safe.toFixed(decimals);
  const [intPart, decPart] = fixed.split(".");
  const grouped = (intPart ?? "0").replace(/\B(?=(\d{3})+(?!\d))/g, ".");
  return decimals > 0 ? `${grouped},${decPart}` : grouped;
}

/** Default metric values, restored on a double-tap of the axis strip. */
const DEFAULT_METRIC_VALUES: Record<string, string> = {
  "Total sales": "591.760,03",
  Orders: "46.344",
  "Conversion rate": "5,90",
  Sessions: "493.999",
};

const DEFAULT_METRIC_DELTAS: Record<string, string> = {
  "Total sales": "+395",
  Orders: "+426",
  "Conversion rate": "+696",
  Sessions: "+290",
};


export function MetricsChart({ metric, editMode = false, spike = 50, lineHeight = 75 }: { metric: ChartMetric; editMode?: boolean; spike?: number; lineHeight?: number }) {
  const range = useDateRange();
  const ticks = rangeTicks(range);
  const numeric = parseValue(metric.value);
  const isZero = numeric <= 0;
  // per-point peak implied by the (editable) total shown on the card
  const divisor = range === "today" || range === "yesterday" ? 17 : 22;
  const peak =
    metric.suffix === "%"
      ? Math.min(100, numeric * 16)
      : numeric / divisor;
  // The scale/shape refresh only when the shape token changes (randomize or a
  // manual edit). Push-notification orders bump the numbers but not the chart.
  const shapeToken = useChartShape();
  const comparisonVisible = showComparisonLine();
  // Freeze the max-to-value ratio per shape so push-notification order bumps
  // don't move the chart, while axis-strip drags (which rewrite the metric
  // value) rescale it proportionally — the curve never changes position.
  const frozenMax = useRef<Record<string, { max: number; numeric: number }>>({});
  const scaleKey = `${metric.label}:${range}:${shapeToken}`;
  let max = isZero ? 100 : niceMax(peak);
  const frozen = frozenMax.current[scaleKey];
  if (isZero) {
    delete frozenMax.current[scaleKey];
  } else if (frozen === undefined || frozen.numeric <= 0) {
    frozenMax.current[scaleKey] = { max, numeric };
  } else {
    max = (frozen.max * numeric) / frozen.numeric;
  }
  // The axis numbers must ALWAYS render: any non-finite or non-positive scale
  // (from corrupted legacy data) falls back to a fresh, valid maximum.
  if (!Number.isFinite(max) || max <= 0) {
    max = isZero || !Number.isFinite(peak) || peak <= 0 ? 100 : niceMax(peak);
    if (!Number.isFinite(max) || max <= 0) max = 100;
    if (isZero) delete frozenMax.current[scaleKey];
    else frozenMax.current[scaleKey] = { max, numeric };
  }
  const generatedMax = max;


  const data = useMemo(() => {
    const points = copiedPointCount(range);
    if (isZero) {
      return Array.from({ length: points }, (_, i) => ({
        hour: (i * 23) / (points - 1),
        current: 0,
        previous: 0,
      }));
    }
    // seed keyed by the shape token, not the raw value, so incoming orders never reshuffle
    const seed = Math.floor(hash(`${metric.label}:${range}:${shapeToken}`) * 100000) + 1;
    const current = seededSeries(seed, generatedMax, points);
    const previous = seededSeries(seed + 1234, generatedMax * 0.75, points);
    return current.map((value, i) => ({
      hour: (i * 23) / (points - 1),
      current: value,
      previous: previous[i],
    }));
  }, [metric.label, generatedMax, isZero, range, shapeToken]);

  const [editingLine, setEditingLine] = useState<EditingLine>("solid");
  const [editedSolid, setEditedSolid] = useState<number[] | null>(null);
  const [editedDashed, setEditedDashed] = useState<number[] | null>(null);
  const draggingIndex = useRef<number | null>(null);
  // Shuffle must redraw the lines even when they were dragged by hand, so a
  // changed shape token clears that metric/range's manual edits first.
  const lastShapeToken = useRef<string | null>(null);

  useEffect(() => {
    const shuffled = lastShapeToken.current !== null && lastShapeToken.current !== shapeToken;
    lastShapeToken.current = shapeToken;
    if (shuffled) {
      try {
        localStorage.removeItem(editStorageKey(metric.label, range, "solid"));
        localStorage.removeItem(editStorageKey(metric.label, range, "dashed"));
      } catch { /* ignore */ }
      setEditedSolid(null);
      setEditedDashed(null);
      setEditingLine("solid");
      return;
    }
    const read = (line: EditingLine) => {
      try {
        const raw = localStorage.getItem(editStorageKey(metric.label, range, line));
        if (!raw) return null;
        const parsed = JSON.parse(raw) as number[];
        return Array.isArray(parsed) && parsed.length === data.length ? parsed : null;
      } catch {
        return null;
      }
    };
    setEditedSolid(read("solid"));
    setEditedDashed(read("dashed"));
    setEditingLine("solid");
  }, [metric.label, range, data.length, shapeToken]);

  const chartData = useMemo(() => {
    const current = data.map((point, index) => Number(editedSolid?.[index] ?? point.current ?? 0));
    const previous = data.map((point, index) => Number(editedDashed?.[index] ?? point.previous ?? 0));
    const spikeAmount = Math.max(0, Math.min(100, spike)) / 100;
    const heightFactor = 0.2 + (Math.max(0, Math.min(100, lineHeight)) / 100) * 0.8;
    const smooth = (values: number[]) => values.map((value, index) => {
      let sum = 0;
      let weight = 0;
      for (let offset = -4; offset <= 4; offset += 1) {
        const source = Math.max(0, Math.min(values.length - 1, index + offset));
        const currentWeight = 5 - Math.abs(offset);
        sum += (values[source] ?? value) * currentWeight;
        weight += currentWeight;
      }
      return sum / Math.max(weight, 1);
    });
    const tune = (values: number[]) => {
      const softened = smooth(values);
      const average = values.reduce((sum, value) => sum + value, 0) / Math.max(values.length, 1);
      return values.map((value, index) => {
        const blended = (softened[index] ?? value) + (value - (softened[index] ?? value)) * spikeAmount;
        return Math.max(0, (average + (blended - average) * (0.45 + spikeAmount * 0.75)) * heightFactor);
      });
    };
    const tunedCurrent = tune(current);
    const tunedPrevious = tune(previous);
    return data.map((point, index) => ({
      ...point,
      current: tunedCurrent[index] ?? 0,
      previous: tunedPrevious[index] ?? 0,
    }));
  }, [data, editedSolid, editedDashed, spike, lineHeight]);

  const rawTicks = [0, max / 3, (max * 2) / 3, max];
  const yTicks = rawTicks.filter((t) => Number.isFinite(t) && t >= 0);
  if (yTicks.length < 2) yTicks.push(0, 100);

  // ---- long-press scrubbing ----
  const wrapRef = useRef<HTMLDivElement>(null);
  const holdTimer = useRef<number | null>(null);
  const [scrub, setScrub] = useState<number | null>(null); // index into data
  const [box, setBox] = useState({ w: 0, h: 160 });
  const [origin, setOrigin] = useState({ top: 0, left: 0 });

  useEffect(() => {
    const el = wrapRef.current;
    if (!el) return;
    const measure = () => setBox({ w: el.clientWidth, h: el.clientHeight });
    measure();
    window.addEventListener("resize", measure);
    return () => window.removeEventListener("resize", measure);
  }, []);

  const PAD_L = 8;
  const PAD_R = 16;
  const plotLeft = PAD_L + 42;
  const plotRight = Math.max(plotLeft + 1, box.w - PAD_R - 5);
  const plotTop = 5;
  const plotBottom = box.h - 30;

  const indexFromClientX = (clientX: number) => {
    const el = wrapRef.current;
    if (!el) return 0;
    const rect = el.getBoundingClientRect();
    const t = (clientX - rect.left - plotLeft) / (plotRight - plotLeft);
    const hour = Math.max(0, Math.min(1, t)) * 24;
    // Snap to the nearest plotted point using the same x positions as the line.
    let best = 0;
    chartData.forEach((item, index) => {
      if (Math.abs(Number(item.hour) - hour) < Math.abs(Number(chartData[best]?.hour) - hour)) best = index;
    });
    return best;
  };

  const clearHold = () => {
    if (holdTimer.current !== null) {
      window.clearTimeout(holdTimer.current);
      holdTimer.current = null;
    }
  };

  const captureOrigin = () => {
    const el = wrapRef.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    setOrigin({ top: rect.top, left: rect.left });
  };

  const onPointerDown = (e: React.PointerEvent) => {
    const x = e.clientX;
    clearHold();
    holdTimer.current = window.setTimeout(() => {
      holdTimer.current = null;
      captureOrigin();
      setScrub(indexFromClientX(x));
    }, 500);
  };

  const onPointerMove = (e: React.PointerEvent) => {
    if (scrub === null) return;
    e.preventDefault();
    setScrub(indexFromClientX(e.clientX));
  };

  const onPointerEnd = () => {
    clearHold();
    setScrub(null);
  };

  const point = scrub !== null ? chartData[scrub] : undefined;
  const scrubCurrent = point ? Number(point.current) : Number.NaN;
  const t = scrub !== null && chartData.length > 1 ? scrub / (chartData.length - 1) : 0;
  const labels = rangePointLabels(range, t);
  const xForHour = (hour: number) => plotLeft + (Math.max(0, Math.min(24, Number(hour) || 0)) / 24) * (plotRight - plotLeft);
  const cx = point ? xForHour(Number(point.hour)) : plotLeft + t * (plotRight - plotLeft);
  const yFor = (v: number) =>
    plotTop + (1 - Math.max(0, Math.min(max, v)) / max) * (plotBottom - plotTop);

  // Keep the tooltip card fully inside the viewport (assumes ~270px max width)
  const viewportW = typeof window !== "undefined" ? window.innerWidth : 393;
  const desiredScreenLeft = origin.left + cx;
  const clampedScreenLeft = Math.max(135, Math.min(viewportW - 135, desiredScreenLeft));
  const tooltipLeft = clampedScreenLeft - origin.left;

  const editable = editMode;
  const activeValues = chartData.map((item) =>
    editingLine === "solid" ? Number(item.current ?? 0) : Number(item.previous ?? 0),
  );
  const updateEditedPoint = (index: number, clientY: number) => {
    const el = wrapRef.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    const relative = Math.max(0, Math.min(1, (clientY - rect.top - plotTop) / (plotBottom - plotTop)));
    const value = max * (1 - relative);
    const setter = editingLine === "solid" ? setEditedSolid : setEditedDashed;
    setter((current) => {
      const fallback = data.map((item) =>
        editingLine === "solid" ? Number(item.current ?? 0) : Number(item.previous ?? 0),
      );
      const next = [...(current ?? fallback)];
      next[index] = value;
      localStorage.setItem(editStorageKey(metric.label, range, editingLine), JSON.stringify(next));
      return next;
    });
  };

  const startEditingPoint = (index: number, event: React.PointerEvent<HTMLDivElement>) => {
    event.preventDefault();
    event.stopPropagation();
    draggingIndex.current = index;
    event.currentTarget.setPointerCapture(event.pointerId);
  };

  const moveEditingPoint = (event: React.PointerEvent<HTMLDivElement>) => {
    if (!editable || draggingIndex.current === null) return;
    event.preventDefault();
    updateEditedPoint(draggingIndex.current, event.clientY);
  };

  const stopEditingPoint = () => {
    draggingIndex.current = null;
  };

  // ---- drag the Y axis to rewrite the metric numbers ----
  // Nothing on screen moves: the curve's plotted values scale together with the
  // axis maximum, so every dot keeps its exact position while the numbers on
  // the axis and on ALL metric cards (sales, orders, conversion, sessions)
  // update in real time.
  const ALL_METRIC_LABELS = Object.keys(DEFAULT_METRIC_VALUES);
  const readSavedMetrics = () => {
    try {
      return JSON.parse(localStorage.getItem(metricsKey(range)) ?? "{}") as Record<
        string,
        { value: string; delta: string }
      >;
    } catch {
      return {};
    }
  };
  const formatMetricValue = (label: string, value: number) =>
    label === "Total sales" || label === "Conversion rate"
      ? formatEu(value, 2)
      : formatEu(Math.round(value), 0);
  const axisDrag = useRef<{
    y: number;
    max: number;
    values: Record<string, number>;
    solid: number[];
    dashed: number[];
  } | null>(null);
  const startAxisDrag = (event: React.PointerEvent<HTMLDivElement>) => {
    event.preventDefault();
    event.stopPropagation();
    const saved = readSavedMetrics();
    const values: Record<string, number> = {};
    for (const label of ALL_METRIC_LABELS) {
      values[label] = parseValue(saved[label]?.value ?? DEFAULT_METRIC_VALUES[label]);
    }
    axisDrag.current = {
      y: event.clientY,
      max: generatedMax,
      values,
      solid: editedSolid ?? data.map((item) => Number(item.current ?? 0)),
      dashed: editedDashed ?? data.map((item) => Number(item.previous ?? 0)),
    };
    event.currentTarget.setPointerCapture(event.pointerId);
  };
  const moveAxisDrag = (event: React.PointerEvent<HTMLDivElement>) => {
    const start = axisDrag.current;
    if (!start || start.max <= 0) return;
    event.preventDefault();
    event.stopPropagation();
    // Dragging up lowers the scale, dragging down raises it. Clamp so values
    // always stay readable and never overflow into exponential notation.
    const factor = Math.exp((event.clientY - start.y) / 160);
    const nextMax = Math.min(Math.max(niceAxisValue(start.max * factor), 1), 1_000_000_000);
    const scale = nextMax / start.max;
    if (!Number.isFinite(scale) || scale <= 0) return;
    // Rewrite every metric by the same factor so the cards stay realistic.
    const saved = readSavedMetrics();
    const next: Record<string, { value: string; delta: string }> = { ...saved };
    for (const label of ALL_METRIC_LABELS) {
      next[label] = {
        value: formatMetricValue(label, (start.values[label] ?? 0) * scale),
        delta: saved[label]?.delta ?? DEFAULT_METRIC_DELTAS[label] ?? "+0",
      };
    }
    writeStore(metricsKey(range), JSON.stringify(next));
    // Scale the plotted points by the same factor so the line never moves.
    const solid = start.solid.map((value) => value * scale);
    const dashed = start.dashed.map((value) => value * scale);
    setEditedSolid(solid);
    setEditedDashed(dashed);
    localStorage.setItem(editStorageKey(metric.label, range, "solid"), JSON.stringify(solid));
    localStorage.setItem(editStorageKey(metric.label, range, "dashed"), JSON.stringify(dashed));
  };
  const endAxisDrag = (event: React.PointerEvent<HTMLDivElement>) => {
    if (!axisDrag.current) return;
    event.stopPropagation();
    axisDrag.current = null;
  };
  const resetAxis = () => {
    axisDrag.current = null;
    const saved = readSavedMetrics();
    const next: Record<string, { value: string; delta: string }> = { ...saved };
    for (const label of ALL_METRIC_LABELS) {
      next[label] = {
        value: DEFAULT_METRIC_VALUES[label] ?? "0",
        delta: saved[label]?.delta ?? DEFAULT_METRIC_DELTAS[label] ?? "+0",
      };
    }
    writeStore(metricsKey(range), JSON.stringify(next));
    setEditedSolid(null);
    setEditedDashed(null);
    localStorage.removeItem(editStorageKey(metric.label, range, "solid"));
    localStorage.removeItem(editStorageKey(metric.label, range, "dashed"));
  };



  return (
    <div
      ref={wrapRef}
      data-no-pull
      className="relative mt-2 h-40 select-none pr-4 pl-2"
      style={{
        touchAction: scrub !== null ? "none" : undefined,
        WebkitTouchCallout: "none",
        WebkitUserSelect: "none",
      }}
      onPointerDown={editable ? undefined : onPointerDown}
      onPointerMove={editable ? moveEditingPoint : onPointerMove}
      onPointerUp={editable ? stopEditingPoint : onPointerEnd}
      onPointerCancel={editable ? stopEditingPoint : onPointerEnd}
      onPointerLeave={editable ? stopEditingPoint : onPointerEnd}
      onContextMenu={(e) => e.preventDefault()}
    >
      <ResponsiveContainer width="100%" height="100%">
          <ComposedChart data={chartData} margin={{ top: 5, right: 5, bottom: 0, left: 0 }}>
          {yTicks.map((t) => (
            <ReferenceLine key={t} y={t} stroke="#3c3c3c" strokeOpacity={0.8} />
          ))}

          <XAxis
            dataKey="hour"
            type="number"
            domain={[0, 24]}
            ticks={[0, 10, 20]}
            tickFormatter={(v: number) => (v === 0 ? ticks[0] : v === 10 ? ticks[1] : ticks[2])}

            tickLine={false}
            axisLine={false}
            tick={{ fill: "#9ca3af", fontSize: 10 }}
          />
          <YAxis
            domain={[0, max]}
            ticks={yTicks}
            interval={0}
            tickFormatter={(v: number) => formatTick(v, metric)}
            tickLine={false}
            axisLine={false}
            width={42}
            tick={{ fill: "#9ca3af", fontSize: 10 }}
          />

          {!isZero && comparisonVisible && (
            <Line
              type="monotoneX"
              dataKey="previous"
              connectNulls={false}
              stroke="#5bc0de"
              strokeWidth={1.5}
              strokeDasharray="5 3"
              strokeOpacity={0.5}
              strokeLinecap="round"
              strokeLinejoin="round"
              dot={false}
              animationDuration={600}
              animationEasing="ease-out"
            />
          )}
          <Line
            type="monotoneX"
            dataKey="current"
            connectNulls={false}
            stroke="#5bc0de"
            strokeWidth={2}
            strokeLinecap="round"
            strokeLinejoin="round"
            dot={false}
            animationDuration={600}
            animationEasing="ease-out"
          />
        </ComposedChart>
      </ResponsiveContainer>

      {editable && (
        <div
          className="absolute z-30 rounded-md border border-dashed border-blue-400/70 bg-blue-500/5 active:bg-blue-500/15"
          style={{
            left: PAD_L,
            top: plotTop,
            width: 42,
            height: Math.max(0, plotBottom - plotTop),
            touchAction: "none",
          }}
          onPointerDown={startAxisDrag}
          onPointerMove={moveAxisDrag}
          onPointerUp={endAxisDrag}
          onPointerCancel={endAxisDrag}
          onDoubleClick={resetAxis}
        />
      )}



      {editable && (
        <div className="absolute inset-0 z-20 pointer-events-none">
          {activeValues.map((value, index) => {
            const left = xForHour(Number(chartData[index]?.hour));
            return (
              <div
                key={index}
                className={`absolute h-3 w-3 -translate-x-1/2 -translate-y-1/2 cursor-grab rounded-full border-2 border-white shadow-lg active:cursor-grabbing ${editingLine === "solid" ? "bg-blue-500" : "bg-orange-400"}`}
                style={{ left, top: yFor(value), pointerEvents: "auto", touchAction: "none" }}
                onPointerDown={(event) => startEditingPoint(index, event)}
              />
            );
          })}
          <div className="pointer-events-auto absolute top-1 right-3 flex items-center gap-1.5">
            <button
              type="button"
              onClick={() => setEditingLine("solid")}
              className={`rounded-full px-2 py-0.5 text-[10px] font-bold transition-colors ${editingLine === "solid" ? "bg-blue-500 text-white" : "bg-gray-200 text-gray-600"}`}
            >
              SOLID
            </button>
            <button
              type="button"
              onClick={() => setEditingLine("dashed")}
              className={`rounded-full px-2 py-0.5 text-[10px] font-bold transition-colors ${editingLine === "dashed" ? "bg-orange-400 text-white" : "bg-gray-200 text-gray-600"}`}
            >
              DASHED
            </button>
          </div>
        </div>
      )}

       {!editable && point && Number.isFinite(scrubCurrent) ? (
        <>
          <div
            className="pointer-events-none absolute z-20 w-px bg-white/45"
            style={{ left: cx, top: plotTop, height: plotBottom - plotTop }}
          />
          <div
            className="pointer-events-none absolute z-20 h-3 w-3 -translate-x-1/2 -translate-y-1/2 rounded-full bg-[#5bc0de]"
             style={{ left: cx, top: yFor(scrubCurrent) }}
          />
          {!isZero ? (
            <div
              className="pointer-events-none absolute z-20 h-3 w-3 -translate-x-1/2 -translate-y-1/2 rounded-full bg-[#5bc0de]/50"
              style={{ left: cx, top: yFor(point.previous ?? 0) }}
            />
          ) : null}
          <ChartScrubTooltip
            metric={metric}
             current={scrubCurrent}
            previous={point.previous ?? 0}
            currentLabel={labels[0]}
            previousLabel={labels[1]}
            left={origin.left + tooltipLeft}
            top={origin.top - 62}
          />
        </>
      ) : null}
    </div>
  );
}
