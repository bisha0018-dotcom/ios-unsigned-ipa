import { useAppTranslation } from "@/components/AppTranslation";
import { AppText } from "@/components/AppTranslation";
import { Shuffle } from "lucide-react";
import { X } from "lucide-react";
import { Button } from "@/components/ui/button";

interface ChartTuningOverlayProps {
  spike: number;
  lineHeight: number;
  onSpikeChange: (value: number) => void;
  onLineHeightChange: (value: number) => void;
  onShuffle: () => void;
  onClose: () => void;
  dark?: boolean;
}

function SliderRow({
  label,
  value,
  onChange,
  lowLabel,
  highLabel,
  dark,
}: {
  label: string;
  value: number;
  onChange: (value: number) => void;
  lowLabel: string;
  highLabel: string;
  dark: boolean;
}) {
  return (
    <label className="block">
      <span className={`mb-2 flex items-center justify-between text-[13px] font-medium ${dark ? "text-white" : "text-gray-900"}`}>
        <span><AppText>{label}</AppText></span>
        <span className={dark ? "tabular-nums text-gray-400" : "tabular-nums text-gray-500"}>{value}%</span>
      </span>
      <input
        type="range"
        min="0"
        max="100"
        step="1"
        value={value}
        onChange={(event) => onChange(Number(event.target.value))}
        className="h-1.5 w-full cursor-pointer accent-blue-500"
      />
      <span className={`mt-1 flex justify-between text-[10px] ${dark ? "text-gray-500" : "text-gray-400"}`}>
        <span>{lowLabel}</span>
        <span>{highLabel}</span>
      </span>
    </label>
  );
}

export function ChartTuningOverlay({
  spike,
  lineHeight,
  onSpikeChange,
  onLineHeightChange,
  onShuffle,
  onClose,
  dark = false,
}: ChartTuningOverlayProps) {
  const translateAttribute = useAppTranslation();
  return (
    <div className={`fixed inset-x-3 bottom-20 z-[70] mx-auto max-w-[406px] rounded-lg border p-4 shadow-2xl ${dark ? "border-gray-700 bg-gray-950" : "border-gray-200 bg-white"}`}>
      <div className="mb-4 flex items-center justify-between">
        <div>
          <p className={`text-[15px] font-semibold ${dark ? "text-white" : "text-gray-950"}`}><AppText>Edit chart</AppText></p>
          <p className={`text-[12px] ${dark ? "text-gray-400" : "text-gray-500"}`}><AppText>Adjust the shape of both lines</AppText></p>
        </div>
        <Button
          type="button"
          variant="ghost"
          size="icon"
          onClick={onClose}
          aria-label={translateAttribute("Close chart controls")}
          className={`h-8 w-8 rounded-full ${dark ? "bg-gray-900 text-gray-300 hover:bg-gray-800" : "bg-gray-100 text-gray-600 hover:bg-gray-200"}`}
        >
          <X className="h-4 w-4" />
        </Button>
      </div>
      <div className="space-y-4">
        <SliderRow label="Curve shape" value={spike} onChange={onSpikeChange} lowLabel="Smooth" highLabel="Spiky" dark={dark} />
        <SliderRow label="Line height" value={lineHeight} onChange={onLineHeightChange} lowLabel="Low" highLabel="High" dark={dark} />
        <Button
          type="button"
          onClick={onShuffle}
          className={`h-10 w-full rounded-lg text-[14px] font-medium ${dark ? "bg-blue-600 text-white hover:bg-blue-500" : "bg-gray-900 text-white hover:bg-gray-800"}`}
        >
          <Shuffle className="mr-2 h-4 w-4" />
          <AppText>Shuffle</AppText>
        </Button>
      </div>
    </div>
  );
}