import { readJSON, writeJSON } from "@/lib/app-store";
import { metricsKey } from "@/lib/date-range";

type Saved = Record<string, { value: string; delta: string }>;

/** "591.760,03" -> 591760.03 */
export function parseEuro(text: string): number {
  const clean = text.replace(/[^\d.,-]/g, "").replace(/\./g, "").replace(",", ".");
  const n = Number.parseFloat(clean);
  return Number.isFinite(n) ? n : 0;
}

/** 591760.03 -> "591.760,03" (or "46.345" when decimals = 0) */
export function formatEuro(value: number, decimals: number): string {
  const fixed = Math.abs(value).toFixed(decimals);
  const [int, dec] = fixed.split(".");
  const grouped = int!.replace(/\B(?=(\d{3})+(?!\d))/g, ".");
  const sign = value < 0 ? "-" : "";
  return dec ? `${sign}${grouped},${dec}` : `${sign}${grouped}`;
}

/**
 * Adds one order (with its amount) to the "Today" numbers: total sales grows by
 * the order amount and orders grows by one. Other ranges are untouched.
 */
export function applyOrderToToday(amountText: string, defaults: Saved) {
  const key = metricsKey("today");
  const saved = readJSON<Saved>(key, {});
  const base: Saved = { ...defaults, ...saved };

  const amount = parseEuro(amountText);

  const sales = base["Total sales"];
  if (sales) {
    base["Total sales"] = {
      ...sales,
      value: formatEuro(parseEuro(sales.value) + amount, 2),
    };
  }

  const orders = base["Orders"];
  if (orders) {
    base["Orders"] = {
      ...orders,
      value: formatEuro(Math.round(parseEuro(orders.value)) + 1, 0),
    };
  }

  writeJSON(key, base);
}
