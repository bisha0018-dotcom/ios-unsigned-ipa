const keys = ["Visitors right now", "Search locations", "Close search", "Globe view", "Map view", "Live View"];
const rows: Record<string, string[]> = {
  ar: ["الزوار الآن", "البحث عن مواقع", "إغلاق البحث", "عرض الكرة الأرضية", "عرض الخريطة", "العرض المباشر"],
  cs: ["Návštěvníci právě teď", "Hledat místa", "Zavřít hledání", "Zobrazení zeměkoule", "Zobrazení mapy", "Živý přehled"],
  da: ["Besøgende lige nu", "Søg efter steder", "Luk søgning", "Globusvisning", "Kortvisning", "Livevisning"],
  de: ["Besucher gerade jetzt", "Orte suchen", "Suche schließen", "Globusansicht", "Kartenansicht", "Live-Ansicht"],
  es: ["Visitantes ahora mismo", "Buscar ubicaciones", "Cerrar búsqueda", "Vista del globo", "Vista del mapa", "Vista en vivo"],
  fi: ["Vierailijat juuri nyt", "Etsi sijainteja", "Sulje haku", "Maapallonäkymä", "Karttanäkymä", "Reaaliaikainen näkymä"],
  fr: ["Visiteurs en ce moment", "Rechercher des lieux", "Fermer la recherche", "Vue du globe", "Vue de la carte", "Vue en direct"],
  he: ["מבקרים כרגע", "חיפוש מקומות", "סגירת החיפוש", "תצוגת כדור הארץ", "תצוגת מפה", "תצוגה בזמן אמת"],
  hi: ["अभी के विज़िटर", "स्थान खोजें", "खोज बंद करें", "ग्लोब दृश्य", "मानचित्र दृश्य", "लाइव दृश्य"],
  hu: ["Látogatók most", "Helyek keresése", "Keresés bezárása", "Földgömbnézet", "Térképnézet", "Élő nézet"],
  id: ["Pengunjung saat ini", "Cari lokasi", "Tutup pencarian", "Tampilan globe", "Tampilan peta", "Tampilan langsung"],
  it: ["Visitatori in questo momento", "Cerca luoghi", "Chiudi ricerca", "Vista del globo", "Vista della mappa", "Vista in tempo reale"],
  ja: ["現在の訪問者", "場所を検索", "検索を閉じる", "地球儀表示", "地図表示", "ライブビュー"],
  ko: ["현재 방문자", "위치 검색", "검색 닫기", "지구본 보기", "지도 보기", "라이브 뷰"],
  ms: ["Pelawat sekarang", "Cari lokasi", "Tutup carian", "Paparan glob", "Paparan peta", "Paparan langsung"],
  nb: ["Besøkende akkurat nå", "Søk etter steder", "Lukk søk", "Globusvisning", "Kartvisning", "Sanntidsvisning"],
  nl: ["Bezoekers op dit moment", "Locaties zoeken", "Zoeken sluiten", "Globeweergave", "Kaartweergave", "Liveweergave"],
  pl: ["Odwiedzający w tej chwili", "Szukaj lokalizacji", "Zamknij wyszukiwanie", "Widok globu", "Widok mapy", "Widok na żywo"],
  pt: ["Visitantes neste momento", "Pesquisar locais", "Fechar pesquisa", "Vista do globo", "Vista do mapa", "Vista em direto"],
  "pt-BR": ["Visitantes agora", "Pesquisar locais", "Fechar pesquisa", "Visualização do globo", "Visualização do mapa", "Visualização ao vivo"],
  ro: ["Vizitatori în acest moment", "Caută locații", "Închide căutarea", "Vizualizare glob", "Vizualizare hartă", "Vizualizare live"],
  sv: ["Besökare just nu", "Sök platser", "Stäng sökning", "Globvy", "Kartvy", "Livevy"],
  th: ["ผู้เยี่ยมชมขณะนี้", "ค้นหาสถานที่", "ปิดการค้นหา", "มุมมองลูกโลก", "มุมมองแผนที่", "มุมมองสด"],
  tr: ["Şu anki ziyaretçiler", "Konum ara", "Aramayı kapat", "Küre görünümü", "Harita görünümü", "Canlı görünüm"],
  vi: ["Khách truy cập hiện tại", "Tìm địa điểm", "Đóng tìm kiếm", "Chế độ quả địa cầu", "Chế độ bản đồ", "Chế độ trực tiếp"],
  "zh-CN": ["当前访客", "搜索地点", "关闭搜索", "地球视图", "地图视图", "实时视图"],
  "zh-TW": ["目前訪客", "搜尋地點", "關閉搜尋", "地球檢視", "地圖檢視", "即時檢視"],
};
const behaviorKeys = ["Customer behavior", "Active carts", "Checking out", "Purchased"];
const behaviorRows: Record<string, string[]> = {
  ar: ["سلوك العملاء", "سلات نشطة", "إتمام الشراء", "تم الشراء"],
  cs: ["Chování zákazníků", "Aktivní košíky", "Dokončování nákupu", "Zakoupeno"],
  da: ["Kundeadfærd", "Aktive kurve", "Ved kassen", "Købt"],
  de: ["Kundenverhalten", "Aktive Warenkörbe", "Im Checkout", "Gekauft"],
  es: ["Comportamiento del cliente", "Carritos activos", "Finalizando compra", "Comprado"],
  fi: ["Asiakaskäyttäytyminen", "Aktiiviset ostoskorit", "Kassalla", "Ostettu"],
  fr: ["Comportement des clients", "Paniers actifs", "Paiement en cours", "Acheté"],
  he: ["התנהגות לקוחות", "עגלות פעילות", "בתהליך תשלום", "נרכש"],
  hi: ["ग्राहक व्यवहार", "सक्रिय कार्ट", "चेकआउट में", "खरीदा गया"],
  hu: ["Vásárlói viselkedés", "Aktív kosarak", "Fizetés folyamatban", "Megvásárolva"],
  id: ["Perilaku pelanggan", "Keranjang aktif", "Sedang checkout", "Dibeli"],
  it: ["Comportamento dei clienti", "Carrelli attivi", "Checkout in corso", "Acquistato"],
  ja: ["顧客の行動", "有効なカート", "チェックアウト中", "購入済み"],
  ko: ["고객 행동", "활성 장바구니", "결제 진행 중", "구매 완료"],
  ms: ["Tingkah laku pelanggan", "Troli aktif", "Sedang daftar keluar", "Dibeli"],
  nb: ["Kundeatferd", "Aktive handlekurver", "I kassen", "Kjøpt"],
  nl: ["Klantgedrag", "Actieve winkelwagens", "Aan het afrekenen", "Gekocht"],
  pl: ["Zachowanie klientów", "Aktywne koszyki", "Finalizowanie zakupu", "Kupiono"],
  pt: ["Comportamento dos clientes", "Carrinhos ativos", "A finalizar compra", "Comprado"],
  "pt-BR": ["Comportamento dos clientes", "Carrinhos ativos", "Finalizando compra", "Comprado"],
  ro: ["Comportamentul clienților", "Coșuri active", "Finalizarea comenzii", "Cumpărat"],
  sv: ["Kundbeteende", "Aktiva varukorgar", "I kassan", "Köpt"],
  th: ["พฤติกรรมลูกค้า", "ตะกร้าที่ใช้งาน", "กำลังชำระเงิน", "ซื้อแล้ว"],
  tr: ["Müşteri davranışı", "Aktif sepetler", "Ödeme yapılıyor", "Satın alındı"],
  vi: ["Hành vi khách hàng", "Giỏ hàng đang hoạt động", "Đang thanh toán", "Đã mua"],
  "zh-CN": ["客户行为", "活跃购物车", "正在结账", "已购买"],
  "zh-TW": ["顧客行為", "使用中的購物車", "正在結帳", "已購買"],
};
const locationTitles: Record<string, string> = {
  ar: "الجلسات حسب الموقع", cs: "Relace podle místa", da: "Sessioner efter lokation", de: "Sitzungen nach Standort",
  es: "Sesiones por ubicación", fi: "Istunnot sijainnin mukaan", fr: "Sessions par emplacement", he: "ביקורים לפי מיקום",
  hi: "स्थान के अनुसार सत्र", hu: "Munkamenetek hely szerint", id: "Sesi berdasarkan lokasi", it: "Sessioni per località",
  ja: "ロケーション別セッション", ko: "위치별 세션", ms: "Sesi mengikut lokasi", nb: "Økter etter sted", nl: "Sessies per locatie",
  pl: "Sesje według lokalizacji", pt: "Sessões por localização", "pt-BR": "Sessões por localização", ro: "Sesiuni după locație",
  sv: "Sessioner efter plats", th: "เซสชันตามสถานที่", tr: "Konuma göre oturumlar", vi: "Phiên theo vị trí",
  "zh-CN": "按位置划分的会话", "zh-TW": "依位置劃分的工作階段",
};
const productRows: Record<string, [string, string]> = {
  ar: ["إجمالي المبيعات حسب المنتج", "السعر"], cs: ["Celkové prodeje podle produktu", "Cena"],
  da: ["Samlet salg efter produkt", "Pris"], de: ["Gesamtumsatz nach Produkt", "Preis"],
  es: ["Ventas totales por producto", "Precio"], fi: ["Kokonaismyynti tuotteittain", "Hinta"],
  fr: ["Ventes totales par produit", "Prix"], he: ["סך המכירות לפי מוצר", "מחיר"],
  hi: ["उत्पाद के अनुसार कुल बिक्री", "कीमत"], hu: ["Összes értékesítés termékenként", "Ár"],
  id: ["Total penjualan berdasarkan produk", "Harga"], it: ["Vendite totali per prodotto", "Prezzo"],
  ja: ["商品別の総売上", "価格"], ko: ["제품별 총 매출", "가격"],
  ms: ["Jumlah jualan mengikut produk", "Harga"], nb: ["Totalt salg etter produkt", "Pris"],
  nl: ["Totale verkopen per product", "Prijs"], pl: ["Łączna sprzedaż według produktu", "Cena"],
  pt: ["Vendas totais por produto", "Preço"], "pt-BR": ["Vendas totais por produto", "Preço"],
  ro: ["Vânzări totale pe produs", "Preț"], sv: ["Total försäljning per produkt", "Pris"],
  th: ["ยอดขายรวมตามสินค้า", "ราคา"], tr: ["Ürüne göre toplam satış", "Fiyat"],
  vi: ["Tổng doanh số theo sản phẩm", "Giá"], "zh-CN": ["按产品划分的总销售额", "价格"],
  "zh-TW": ["依產品劃分的總銷售額", "價格"],
};
const emptyTitles: Record<string, string> = {
  ar: "لا توجد بيانات لهذا النطاق الزمني", cs: "Pro toto období nejsou žádná data", da: "Ingen data for dette datointerval",
  de: "Keine Daten für diesen Zeitraum", es: "No hay datos para este intervalo de fechas", fi: "Ei tietoja tältä ajanjaksolta",
  fr: "Aucune donnée pour cette période", he: "אין נתונים לטווח תאריכים זה", hi: "इस तारीख सीमा के लिए कोई डेटा नहीं",
  hu: "Nincs adat ebben az időszakban", id: "Tidak ada data untuk rentang tanggal ini", it: "Nessun dato per questo intervallo di date",
  ja: "この期間のデータはありません", ko: "이 기간에 대한 데이터가 없습니다", ms: "Tiada data untuk julat tarikh ini",
  nb: "Ingen data for denne perioden", nl: "Geen gegevens voor dit datumbereik", pl: "Brak danych dla tego zakresu dat",
  pt: "Sem dados para este intervalo de datas", "pt-BR": "Sem dados para este intervalo de datas", ro: "Nu există date pentru acest interval",
  sv: "Inga data för det här datumintervallet", th: "ไม่มีข้อมูลสำหรับช่วงวันที่นี้", tr: "Bu tarih aralığı için veri yok",
  vi: "Không có dữ liệu cho khoảng ngày này", "zh-CN": "此日期范围内没有数据", "zh-TW": "此日期範圍內沒有資料",
};
const setupLabels: Record<string, [string, string]> = {
  ar: ["تخصيص العرض المباشر", "الإيرادات"], cs: ["Přizpůsobit živý přehled", "Tržby"], da: ["Tilpas livevisning", "Omsætning"],
  de: ["Live-Ansicht anpassen", "Umsatz"], es: ["Personalizar vista en vivo", "Ingresos"], fi: ["Mukauta reaaliaikaista näkymää", "Liikevaihto"],
  fr: ["Personnaliser la vue en direct", "Chiffre d’affaires"], he: ["התאמת התצוגה בזמן אמת", "הכנסות"], hi: ["लाइव दृश्य अनुकूलित करें", "राजस्व"],
  hu: ["Élő nézet testreszabása", "Bevétel"], id: ["Sesuaikan tampilan langsung", "Pendapatan"], it: ["Personalizza vista in tempo reale", "Ricavi"],
  ja: ["ライブビューをカスタマイズ", "売上高"], ko: ["라이브 뷰 맞춤 설정", "매출"], ms: ["Sesuaikan paparan langsung", "Hasil"],
  nb: ["Tilpass sanntidsvisning", "Omsetning"], nl: ["Liveweergave aanpassen", "Omzet"], pl: ["Dostosuj widok na żywo", "Przychody"],
  pt: ["Personalizar vista em direto", "Receita"], "pt-BR": ["Personalizar visualização ao vivo", "Receita"], ro: ["Personalizează vizualizarea live", "Venituri"],
  sv: ["Anpassa livevy", "Omsättning"], th: ["ปรับแต่งมุมมองสด", "รายได้"], tr: ["Canlı görünümü özelleştir", "Gelir"],
  vi: ["Tùy chỉnh chế độ trực tiếp", "Doanh thu"], "zh-CN": ["自定义实时视图", "收入"], "zh-TW": ["自訂即時檢視", "營收"],
};
export function translateLiveView(language: string, source: string) {
  if (source === "No data for this date range") return emptyTitles[language];
  if (source === "Customize Live View") return setupLabels[language]?.[0];
  if (source === "Revenue") return setupLabels[language]?.[1];
  if (source === "Total sales by product") return productRows[language]?.[0];
  if (source === "Price") return productRows[language]?.[1];
  if (source === "Sessions by location") return locationTitles[language];
  return rows[language]?.[keys.indexOf(source)] ?? behaviorRows[language]?.[behaviorKeys.indexOf(source)];
}