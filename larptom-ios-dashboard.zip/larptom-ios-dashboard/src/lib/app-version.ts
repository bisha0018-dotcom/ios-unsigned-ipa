import { readStore, writeStore } from "@/lib/app-store";

export type AppVersion = "new" | "old";
export const APP_VERSION_KEY = "app.version";

export function getAppVersion(): AppVersion {
  return readStore(APP_VERSION_KEY, "new") === "old" ? "old" : "new";
}

export function setAppVersion(version: AppVersion) {
  writeStore(APP_VERSION_KEY, version);
}
