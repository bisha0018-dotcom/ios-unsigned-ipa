import { useEffect, useState } from "react";
import { onStoreChange, readStore, writeStore } from "@/lib/app-store";

export const RANGE_KEY = "bisha:date-range";

export type RangeId = "today" | "yesterday" | "7d" | "30d";

export const RANGE_OPTIONS: { id: RangeId; label: string; pill: string }[] = [
  { id: "today", label: "Today", pill: "Today" },
  { id: "yesterday", label: "Yesterday", pill: "Yesterday" },
  { id: "7d", label: "Last 7 days", pill: "7 days" },
  { id: "30d", label: "Last 30 days", pill: "30 days" },
];

export function getRange(): RangeId {
  const v = readStore(RANGE_KEY, "today") as RangeId;
  return RANGE_OPTIONS.some((o) => o.id === v) ? v : "today";
}

export function setRange(id: RangeId) {
  writeStore(RANGE_KEY, id);
}

export function rangePill(id: RangeId) {
  return RANGE_OPTIONS.find((o) => o.id === id)?.pill ?? "Today";
}

/** Live-updating selected range. */
export function useDateRange(): RangeId {
  const [range, setRangeState] = useState<RangeId>("today");
  useEffect(() => {
    setRangeState(getRange());
    return onStoreChange(() => setRangeState(getRange()));
  }, []);
  return range;
}

const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

function dayLabel(daysAgo: number) {
  const d = new Date();
  d.setDate(d.getDate() - daysAgo);
  return `${MONTHS[d.getMonth()]} ${d.getDate()}`;
}

/** X-axis tick labels (start, middle, end) for the selected range. */
export function rangeTicks(id: RangeId): [string, string, string] {
  if (id === "7d") return [dayLabel(6), dayLabel(3), dayLabel(0)];
  if (id === "30d") return [dayLabel(29), dayLabel(14), dayLabel(0)];
  return ["12:00 AM", "10:00 AM", "8:00 PM"];
}

/** How jagged the chart should be for the range. */
export function rangeShape(id: RangeId) {
  // 30 days: same smooth base curve as today/yesterday, with a little more waviness
  if (id === "30d") return { points: 54, amplitude: 1.18, frequency: 1.48 };
  // 7 days: keep the same smooth curve as today/yesterday, just a touch more movement
  if (id === "7d") return { points: 44, amplitude: 1.12, frequency: 1.35 };
  return { points: 40, amplitude: 1, frequency: 1 };
}

/** localStorage key holding metric values for a given range. */
export function metricsKey(id: RangeId = getRange()) {
  return id === "today" ? "app.metrics" : `app.metrics:${id}`;
}

/** Global live-visitor count shared by every date range. */
export function liveKey(_id: RangeId = getRange()) {
  return "app.liveCount";
}

/** Initial live count used until the user saves their own. */
export function liveDefault(_id: RangeId) {
  return "1";
}

const MONTHS_FULL = MONTHS;

function fmtDate(d: Date, omitYear = false) {
  return omitYear
    ? `${MONTHS_FULL[d.getMonth()]} ${d.getDate()}`
    : `${MONTHS_FULL[d.getMonth()]} ${d.getDate()}, ${d.getFullYear()}`;
}

function fmtTime(hour: number) {
  const h = Math.round(hour);
  const suffix = h >= 12 && h < 24 ? "PM" : "AM";
  const base = h % 12 === 0 ? 12 : h % 12;
  return `${base}:00 ${suffix}`;
}

/**
 * Labels shown in the chart scrub tooltip for a normalized position (0..1):
 * the point on the current period and the matching point on the previous one.
 */
export function rangePointLabels(id: RangeId, t: number): [string, string] {
  const clamped = Math.max(0, Math.min(1, t));
  if (id === "7d" || id === "30d") {
    const span = id === "7d" ? 6 : 29;
    const daysAgo = Math.round(span - clamped * span);
    const cur = new Date();
    cur.setDate(cur.getDate() - daysAgo);
    const prev = new Date(cur);
    prev.setDate(prev.getDate() - (span + 2));
    return [fmtDate(cur), fmtDate(prev)];
  }
  const hour = clamped * 23;
  const base = new Date();
  if (id === "yesterday") base.setDate(base.getDate() - 1);
  const prev = new Date(base);
  prev.setDate(prev.getDate() - 1);
  return [
    `${fmtDate(base, true)}, ${fmtTime(hour)}`,
    `${fmtDate(prev, true)}, ${fmtTime(hour)}`,
  ];
}
