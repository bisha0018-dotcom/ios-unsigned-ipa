import { translateLiveView } from "./live-view-translations";

const dictionaries = import.meta.glob<Record<string, string>>("./locales/*.json", { eager: true, import: "default" });

export function translateUi(language: string, source: string): string {
  if (language === "en" || !source.trim()) return source;
  const dictionary = dictionaries[`./locales/${language}.json`];
  if (!dictionary) return source;
  const normalized = source.replace(/\s+/g, " ").trim();
  const translated = translateLiveView(language, normalized) ?? dictionary[normalized];
  if (translated) return source.replace(source.trim(), translated);
  // Complete dynamic sentences retain their values while translations may reorder them.
  for (const [template, value] of Object.entries(dictionary)) {
    if (!/\{\d+\}/.test(template)) continue;
    const slots: string[] = [];
    const pattern = template.split(/(\{\d+\})/).map((part) => {
      if (/^\{\d+\}$/.test(part)) { slots.push(part); return "(.+?)"; }
      return part.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    }).join("");
    const match = normalized.match(new RegExp(`^${pattern}$`));
    if (!match) continue;
    return value.replace(/\{\d+\}/g, (slot) => match[slots.indexOf(slot) + 1] ?? slot);
  }
  return source;
}

export function uiMessage(language: string, template: string, ...values: (string | number)[]) {
  return translateUi(language, template).replace(/\{(\d+)\}/g, (_, index: string) => String(values[Number(index)] ?? ""));
}

export function orderNotification(language: string, order: number, amount: string, count: number, storeName: string) {
  const category = new Intl.PluralRules(language).select(count);
  const forms: Record<string, Partial<Record<Intl.LDMLPluralRule, string>>> = {
    ar: { zero: "{0} عناصر", one: "عنصر واحد", two: "عنصران", few: "{0} عناصر", many: "{0} عنصرًا", other: "{0} عنصر" },
    pl: { one: "{0} produkt", few: "{0} produkty", many: "{0} produktów", other: "{0} produktu" },
    cs: { one: "{0} položka", few: "{0} položky", other: "{0} položek" },
    ro: { one: "{0} articol", few: "{0} articole", other: "{0} de articole" },
    he: { one: "פריט אחד", two: "שני פריטים", other: "{0} פריטים" },
  };
  const itemTemplate = forms[language]?.[category];
  const items = itemTemplate ? itemTemplate.replace("{0}", String(count)) : uiMessage(language, count === 1 ? "{0} item" : "{0} items", count);
  return {
    title: uiMessage(language, "Order #{0}", order),
    body: uiMessage(language, "{0}, {1} from Online Store • {2}", amount, items, storeName),
  };
}