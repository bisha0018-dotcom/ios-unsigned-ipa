/** Local store of the fake orders shown on the Orders page. */

export interface StoredOrder {
  id: string;
  orderNumber: number;
  customerName: string;
  amount: string;
  items: number;
  timestamp: number;
  status: "Archived";
}

const KEY = "stored-orders";

const RANDOM_NAMES = [
  "Manuel Torres Azogue", "Pedro Raposeiro", "Jordi Peyro",
  "Sofia Martinez", "Carlos Mendez", "Ana Rodriguez",
  "Luis Fernandez", "Maria Lopez", "Diego Sanchez",
  "Isabella Garcia", "Andres Herrera", "Camila Flores",
  "Ricardo Morales", "Valentina Cruz", "Felipe Vargas",
  "Elena Gutierrez", "Pablo Navarro", "Lucia Dominguez",
  "Fernando Ramos", "Carmen Jimenez", "Alejandro Vega",
  "Natalia Ortiz", "Sergio Castillo", "Patricia Reyes",
  "Gabriel Romero", "Daniela Ruiz", "Hugo Delgado",
  "Adriana Soto", "Miguel Espinoza", "Laura Peña",
  "Raul Medina", "Clara Aguilar", "Oscar Fuentes",
  "Monica Salazar", "Javier Guerrero", "Teresa Montoya",
  "Emilio Cabrera", "Rosa Velasco", "Ivan Pacheco",
  "Andrea Figueroa", "Rafael Ibarra", "Julia Contreras",
  "Marco Villanueva", "Pilar Cárdenas",
  "Santiago Rios", "Mariana Estrada", "Joaquin Lara",
  "Paulina Zavala", "Esteban Mora", "Lorena Campos",
];

export function randomCustomerName(): string {
  return RANDOM_NAMES[Math.floor(Math.random() * RANDOM_NAMES.length)]!;
}

export function getStoredOrders(): StoredOrder[] {
  if (typeof window === "undefined") return [];
  try {
    const stored = localStorage.getItem(KEY);
    if (stored) return JSON.parse(stored) as StoredOrder[];
  } catch {
    /* ignore */
  }
  return [];
}

export function clearStoredOrders() {
  if (typeof window === "undefined") return;
  localStorage.removeItem(KEY);
  window.dispatchEvent(new Event("orders-updated"));
}

export function saveOrder(order: StoredOrder) {
  if (typeof window === "undefined") return;
  const orders = getStoredOrders();
  orders.unshift(order);
  if (orders.length > 200) orders.length = 200;
  try {
    localStorage.setItem(KEY, JSON.stringify(orders));
  } catch {
    /* ignore */
  }
  window.dispatchEvent(new Event("orders-updated"));
}

/** Adds demo orders to the list (used by the "Create order" button for testing). */
export function seedDemoOrders(count = 10) {
  if (typeof window === "undefined") return;
  const existing = getStoredOrders();
  let nextNumber = (existing[0]?.orderNumber ?? 1000) + 1;
  const now = Date.now();
  const added: StoredOrder[] = [];
  for (let i = 0; i < count; i++) {
    const items = 1 + Math.floor(Math.random() * 3);
    const amount = (items * (15 + Math.random() * 60)).toFixed(2).replace(".", ",");
    added.push({
      id: `${now}-${i}-${Math.random().toString(36).slice(2, 8)}`,
      orderNumber: nextNumber++,
      customerName: randomCustomerName(),
      amount,
      items,
      timestamp: now - i * (5 + Math.floor(Math.random() * 40)) * 60000,
      status: "Archived",
    });
  }
  const orders = [...added.reverse(), ...existing];
  if (orders.length > 200) orders.length = 200;
  try {
    localStorage.setItem(KEY, JSON.stringify(orders));
  } catch {
    /* ignore */
  }
  window.dispatchEvent(new Event("orders-updated"));
}
