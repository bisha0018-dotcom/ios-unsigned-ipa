export const LICENSE_FILTERS = ["All", "Active", "Canceled", "Expired", "Revoked"] as const;
export type LicenseState = Exclude<(typeof LICENSE_FILTERS)[number], "All">;

/** Subscription cancellation is presentation-only; access still follows paid expiry. */
export function getLicenseState(
  row: { revoked: boolean; lifetime: boolean; expiresAt: string | null; subscriptionCanceled?: boolean },
  now: number,
): LicenseState {
  if (row.revoked) return "Revoked";
  if (!row.lifetime && row.expiresAt && new Date(row.expiresAt).getTime() <= now) return "Expired";
  if (!row.lifetime && row.subscriptionCanceled) return "Canceled";
  return "Active";
}