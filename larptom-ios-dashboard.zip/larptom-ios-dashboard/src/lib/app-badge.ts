import { readStore, writeStore } from "@/lib/app-store";

const BADGE_KEY = "push.badgeCount";

export function readBadgeCount(): number {
  const raw = readStore(BADGE_KEY, "0");
  return Math.max(0, Number(raw) || 0);
}

export function writeBadgeCount(next: number) {
  const count = Math.max(0, next);
  writeStore(BADGE_KEY, String(count));
}

export async function setAppBadge(count: number) {
  if (typeof navigator === "undefined" || !("setAppBadge" in navigator)) return;
  try {
    if (count > 0) await (navigator as Navigator & { setAppBadge(n?: number): Promise<void> }).setAppBadge(count);
    else await (navigator as Navigator & { clearAppBadge(): Promise<void> }).clearAppBadge();
  } catch {
    /* ignore */
  }
}

export function incrementBadge() {
  const next = readBadgeCount() + 1;
  writeBadgeCount(next);
  void setAppBadge(next);
  return next;
}

export function clearBadge() {
  writeBadgeCount(0);
  void setAppBadge(0);
}
