import { bumpChartShape, writeJSON, writeStore } from "@/lib/app-store";
import { getRange, metricsKey } from "@/lib/date-range";

const rand = (min: number, max: number) => min + Math.random() * (max - min);
const randInt = (min: number, max: number) => Math.round(rand(min, max));

/** European number formatting: 1.234,56 */
function fmt(n: number, decimals = 0) {
  const fixed = n.toFixed(decimals);
  const [int = "0", dec] = fixed.split(".");
  const grouped = int.replace(/\B(?=(\d{3})+(?!\d))/g, ".");
  return dec ? `${grouped},${dec}` : grouped;
}

function delta() {
  const sign = Math.random() < 0.72 ? "+" : "-";
  return `${sign}${randInt(2, 89)}`;
}

/**
 * Generate a realistic, internally consistent set of shop metrics
 * and push it into the store. Sales scale with the selected date range.
 */
export function randomizeMetrics() {
  const range = getRange();

  let minSales = 1200;
  let maxSales = 9800;
  if (range === "7d") {
    minSales = 16000;
    maxSales = 28000;
  } else if (range === "30d") {
    minSales = 46000;
    maxSales = 83000;
  }

  const sales = rand(minSales, maxSales);
  const aov = rand(28, 140);
  const orders = Math.max(1, Math.round(sales / aov));
  const conversion = rand(0.9, 4.2); // %
  const sessions = Math.max(1, Math.round((orders * 100) / conversion));

  writeJSON(metricsKey(), {
    "Total sales": { value: fmt(sales, 2), delta: delta() },
    Orders: { value: fmt(orders), delta: delta() },
    "Conversion rate": { value: fmt(conversion, 2), delta: delta() },
    Sessions: { value: fmt(sessions), delta: delta() },
  });
  // Drop manual bell edits for this range so the new random chart shows.
  try {
    const prefix = `bisha:chart-edit-v3:${range}:`;
    Object.keys(localStorage)
      .filter((key) => key.startsWith(prefix))
      .forEach((key) => localStorage.removeItem(key));
  } catch {
    /* ignore */
  }
  bumpChartShape();
}

/**
 * Owner preset: resets the header image + store name to the new-user Larptom look
 * and fills every range with a high-volume store (250k–500k sales today).
 */
export function applyBigStorePreset() {
  try {
    localStorage.removeItem("app.avatar");
    localStorage.removeItem("app.avatarSmall");
    Object.keys(localStorage)
      .filter((key) => key.startsWith("bisha:chart-edit-v3:"))
      .forEach((key) => localStorage.removeItem(key));
  } catch {
    /* ignore */
  }
  writeStore("bisha.headerName", "Larptom.com");

  const daily = rand(250000, 500000);
  const aov = rand(62, 118);
  const scale: Record<string, number> = { today: 1, yesterday: rand(0.85, 1.1), "7d": rand(6.2, 7.4), "30d": rand(26, 31) };
  for (const range of ["today", "yesterday", "7d", "30d"] as const) {
    const sales = daily * (scale[range] ?? 1);
    const orders = Math.round(sales / (aov * rand(0.95, 1.05)));
    const conversion = rand(2.4, 3.8);
    const sessions = Math.round((orders * 100) / conversion);
    writeJSON(metricsKey(range), {
      "Total sales": { value: fmt(sales, 2), delta: delta() },
      Orders: { value: fmt(orders), delta: delta() },
      "Conversion rate": { value: fmt(conversion, 2), delta: delta() },
      Sessions: { value: fmt(sessions), delta: delta() },
    });
  }

  const ordersToday = Math.round(daily / aov);
  writeStore("app.liveCount", String(randInt(Math.round(ordersToday * 0.05), Math.round(ordersToday * 0.09))));
  writeStore("bisha.activity.payouts", String(Math.round(daily * rand(0.82, 0.9))));
  writeStore("bisha.activity.fulfill", String(Math.round(ordersToday * rand(0.08, 0.15))));
  writeStore("bisha.activity.capture", String(Math.round(ordersToday * rand(0.01, 0.025))));
  writeStore("bisha.activity.returns", String(Math.round(ordersToday * rand(0.004, 0.009))));
  writeStore("bisha.activity.highrisk", String(Math.round(ordersToday * rand(0.002, 0.005))));
  writeStore("bisha.activity.chargebacks", String(Math.round(ordersToday * rand(0.0008, 0.002))));
  writeStore("bisha.activity.block", String(randInt(3, 12)));
  bumpChartShape();
}
