import { z } from "zod";

const demoSchema = z.object({
  points: z.array(z.object({ usd: z.number().nonnegative(), paidAt: z.string(), kind: z.enum(["initial", "renewal"]) })),
  paidOutUsd: z.number().nonnegative().default(0),
  payoutRequestedAt: z.string().nullable().default(null),
});

export function readAffiliateDemo(metadata: unknown) {
  if (!metadata || typeof metadata !== "object" || Array.isArray(metadata)) return null;
  const result = demoSchema.safeParse((metadata as Record<string, unknown>)["affiliate_demo"]);
  return result.success ? result.data : null;
}