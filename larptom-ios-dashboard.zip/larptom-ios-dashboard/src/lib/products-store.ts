/** Local store of the fake products shown on the Products page. */
import { z } from "zod";

export const productPriceSchema = z.number().finite().min(0).max(999999999.99);

export type ProductStatus = "Active" | "Draft" | "Archived";

export interface StoredProduct {
  id: string;
  title: string;
  stock: number;
  status: ProductStatus;
  image?: string;
  price?: number;
  timestamp: number;
}

const KEY = "stored-products";

export function getStoredProducts(): StoredProduct[] {
  if (typeof window === "undefined") return [];
  try {
    const stored = localStorage.getItem(KEY);
    if (stored) return JSON.parse(stored) as StoredProduct[];
  } catch {
    /* ignore */
  }
  return [];
}

function persist(products: StoredProduct[]) {
  try {
    localStorage.setItem(KEY, JSON.stringify(products));
  } catch {
    /* ignore */
  }
  window.dispatchEvent(new Event("products-updated"));
}

export function saveProduct(product: StoredProduct) {
  if (typeof window === "undefined") return;
  if (product.price !== undefined && !productPriceSchema.safeParse(product.price).success) return;
  const products = getStoredProducts();
  products.unshift(product);
  if (products.length > 200) products.length = 200;
  persist(products);
}

export function deleteProduct(id: string) {
  if (typeof window === "undefined") return;
  persist(getStoredProducts().filter((p) => p.id !== id));
}

export function clearStoredProducts() {
  if (typeof window === "undefined") return;
  localStorage.removeItem(KEY);
  window.dispatchEvent(new Event("products-updated"));
}
