export const INSTALL_ICON_COOKIE = "larptom_icon";
export function readInstallIconCookie() {
  const m = document.cookie.match(new RegExp(`(?:^|; )${INSTALL_ICON_COOKIE}=([^;]*)`));
  return m?.[1] ? decodeURIComponent(m[1]) : null;
}
export function writeInstallIconCookie(id: string) {
  document.cookie = `${INSTALL_ICON_COOKIE}=${encodeURIComponent(id)}; path=/; max-age=${60 * 60 * 24 * 400}; SameSite=Lax`;
}
