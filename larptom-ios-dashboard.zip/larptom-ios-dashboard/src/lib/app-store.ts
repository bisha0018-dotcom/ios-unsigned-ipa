/** Tiny localStorage store with change notifications so panels and widgets stay in sync. */
export const STORE_EVENT = "bisha:store";

export function readStore(key: string, fallback = ""): string {
  try {
    const v = localStorage.getItem(key);
    return v === null ? fallback : v;
  } catch {
    return fallback;
  }
}

export function writeStore(key: string, value: string) {
  try {
    localStorage.setItem(key, value);
  } catch {
    /* ignore */
  }
  window.dispatchEvent(new CustomEvent(STORE_EVENT, { detail: { key } }));
}

export function readJSON<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}

export function writeJSON(key: string, value: unknown) {
  writeStore(key, JSON.stringify(value));
}

/** Subscribe to store changes (returns an unsubscribe function). */
export function onStoreChange(handler: () => void) {
  window.addEventListener(STORE_EVENT, handler);
  return () => window.removeEventListener(STORE_EVENT, handler);
}

/**
 * Chart shape token. The chart re-rolls its shape/scale only when this changes,
 * so randomizing or editing metrics redraws it while incoming push-notification
 * orders leave the chart untouched.
 */
export const CHART_SHAPE_KEY = "bisha:chart-shape";

export function bumpChartShape() {
  writeStore(CHART_SHAPE_KEY, String(Date.now()));
}

export function readChartShape() {
  return readStore(CHART_SHAPE_KEY, "0");
}
