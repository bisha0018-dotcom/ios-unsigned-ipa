import kaChing from "@/assets/ka-ching.mp3.asset.json";
import { readStore } from "@/lib/app-store";

export const KACHING_KEY = "push.kaching";
export const isKaChingOn = () => readStore(KACHING_KEY, "1") === "1";

let ctx: AudioContext | null = null;
let buffer: AudioBuffer | null = null;
let loading: Promise<void> | null = null;

function ensureCtx() {
  if (typeof window === "undefined") return null;
  try {
    if (!ctx) {
      const C = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!C) return null;
      ctx = new C();
    }
    if (ctx.state === "suspended") ctx.resume().catch(() => {});
    return ctx;
  } catch { return null; }
}

function load() {
  if (buffer) return Promise.resolve();
  if (loading) return loading;
  const c = ensureCtx();
  if (!c) return Promise.resolve();
  loading = fetch(kaChing.url)
    .then((r) => r.arrayBuffer())
    .then((b) => new Promise<AudioBuffer>((res, rej) => c.decodeAudioData(b, res, rej)))
    .then((d) => { buffer = d; })
    .catch(() => { loading = null; });
  return loading;
}

// iOS only allows audio after a tap — unlock on the first one.
if (typeof window !== "undefined") {
  const unlock = () => { ensureCtx(); load(); };
  window.addEventListener("touchstart", unlock, { once: true, passive: true });
  window.addEventListener("click", unlock, { once: true });
}

export async function playKaChing() {
  if (!isKaChingOn()) return;
  const c = ensureCtx();
  if (!c) return;
  await load();
  if (!buffer) return;
  try {
    const src = c.createBufferSource();
    src.buffer = buffer;
    const g = c.createGain();
    g.gain.value = 0.8;
    src.connect(g).connect(c.destination);
    src.start(0);
  } catch { /* ignore */ }
}
