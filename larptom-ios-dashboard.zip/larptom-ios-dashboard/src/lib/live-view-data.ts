import { z } from "zod";
import { revenueFromPosition } from "@/lib/desktop-analytics-data";

export const LIVE_REGIONS = [{ id: "all", label: "All" }, { id: "us", label: "US" }, { id: "eu", label: "EU" }, { id: "asia", label: "Asia" }, { id: "africa", label: "Africa" }, { id: "south-america", label: "South America" }, { id: "oceania", label: "Oceania" }] as const;
export type LiveRegion = typeof LIVE_REGIONS[number]["id"];
export const liveSetupSchema = z.object({ revenue: z.number().finite().min(0).max(10000000), seed: z.number().int().min(1).max(1000000), region: z.enum(["all", "us", "eu", "asia", "africa", "south-america", "oceania"]).default("all") });
export const LIVE_DEFAULTS: z.infer<typeof liveSetupSchema> = { revenue: 0, seed: 1, region: "all" };
export const LIVE_SETUP_KEY = "larptom.live-view.setup.v1";
export const LIVE_MARKER_KEY = "larptom.live-view.marker.v1";
export const liveMarkerSchema = z.object({ lat: z.number().finite().min(-90).max(90), lon: z.number().finite().min(-180).max(180), name: z.string().min(1).max(200) });
// Geographic anchors for presentation-only visitor activity, not real traffic.
export const LIVE_CITY_CENTERS = [
  [-74.01, 40.71], [-118.24, 34.05], [-87.63, 41.88], [-122.42, 37.77], [-96.8, 32.78], [-80.19, 25.76], [-122.33, 47.61], [-71.06, 42.36],
  [-0.13, 51.51], [2.35, 48.86], [13.41, 52.52], [-3.7, 40.42], [12.5, 41.9], [4.9, 52.37], [18.07, 59.33], [21.01, 52.23], [14.42, 50.08], [16.37, 48.21],
  [139.69, 35.69], [121.47, 31.23], [116.41, 39.9], [126.98, 37.57], [77.21, 28.61], [72.88, 19.08], [100.5, 13.76], [103.82, 1.35], [106.85, -6.21], [121.0, 14.6], [55.27, 25.2], [28.98, 41.01],
  [31.24, 30.04], [3.38, 6.52], [36.82, -1.29], [28.05, -26.2], [18.42, -33.92], [-7.59, 33.57], [-0.2, 5.6], [38.76, 9.03],
  [-46.63, -23.55], [-43.17, -22.91], [-58.38, -34.6], [-70.67, -33.45], [-77.04, -12.05], [-74.07, 4.71], [-78.47, -0.18],
  [151.21, -33.87], [144.96, -37.81], [153.03, -27.47], [115.86, -31.95], [174.76, -36.85], [-79.38, 43.65], [-123.12, 49.28], [-99.13, 19.43],
] as const;
export function formatLiveNumber(value: number, money = false, language = "en-US") {
  const compact = value > 1000;
  // Compact values drop trailing zeros so whole thousands read "6K", not "6.00K".
  const formatted = new Intl.NumberFormat(language, { minimumFractionDigits: compact ? 0 : money && value !== 0 ? 2 : 0, maximumFractionDigits: compact || money ? 2 : 0 }).format(compact ? value / 1000 : value);
  return `${money ? "$" : ""}${formatted}${compact ? "K" : ""}`;
}
export function liveMetricSeries(value: number, seed: number) {
  return Array.from({ length: 24 }, (_, i) => value === 0 ? 0 : 0.15 + random(seed + i * 7) * 0.45 + Math.sin(i / 5) * 0.16);
}
export function liveRevenueFromPosition(position: number) {
  if (position <= 0) return 0;
  if (position >= 100) return 10000000;
  const base = position <= 10 ? position * 100 : revenueFromPosition((position - 10) / 90 * 100);
  const jitter = (random(Math.round(position * 1000)) - 0.5) * Math.min(base * 0.002, 999);
  return Math.min(10000000, Math.max(0.01, Math.round((base + jitter) * 100) / 100 + (base > 1 ? (1 + Math.floor(random(position * 77) * 98)) / 100 - 0.5 : 0)));
}
export function livePositionFromRevenue(revenue: number) {
  return revenue <= 1000 ? revenue / 100 : 10 + Math.log10(revenue / 1000) / 4 * 90;
}
function random(seed: number) {
  const n = Math.sin(seed * 12.9898 + 78.233) * 43758.5453;
  return n - Math.floor(n);
}
export function inLiveRegion(lon: number, lat: number, region: LiveRegion) {
  switch (region) {
    case "all": return true;
    case "us": return (lon >= -125 && lon <= -66 && lat >= 25 && lat <= 49) || (lon >= -170 && lon <= -130 && lat >= 52 && lat <= 72) || (lon >= -161 && lon <= -154 && lat >= 18 && lat <= 23);
    case "eu": return lon >= -25 && lon <= 45 && lat >= 35 && lat <= 72;
    case "africa": return lon >= -19 && lon <= 52 && lat >= -35 && lat < 35;
    case "asia": return lon >= 45 && lat >= 5 || lon >= 25 && lon < 45 && lat >= 5 && lat < 35 || lon >= 95 && lon <= 141 && lat >= -11;
    case "south-america": return lon >= -82 && lon <= -34 && lat >= -56 && lat <= 13;
    case "oceania": return (lon >= 110 || lon <= -155) && lat >= -48 && lat < -11;
  }
}
export function liveVisitorHexagons(cells: { lon: number; lat: number }[], visitors: number, seed: number, region: LiveRegion) {
  const cities = LIVE_CITY_CENTERS.filter(([lon, lat]) => inLiveRegion(lon, lat, region));
  const candidates = cells.flatMap((cell, index) => {
    if (!inLiveRegion(cell.lon, cell.lat, region)) return [];
    const proximity = cities.reduce((best, [lon, lat]) => {
      const dx = Math.min(Math.abs(cell.lon - lon), 360 - Math.abs(cell.lon - lon)) * Math.cos(lat * Math.PI / 180);
      const distance = dx * dx + (cell.lat - lat) ** 2;
      return Math.max(best, Math.exp(-distance / 5));
    }, 0);
    return [{ index, rank: -Math.log(Math.max(0.000001, random(seed + index * 31))) / (0.005 + proximity * 30) }];
  });
  candidates.sort((a, b) => a.rank - b.rank);
  const limit = Math.min(240, Math.max(3, Math.floor(candidates.length * 0.055)));
  return new Set(candidates.slice(0, Math.min(limit, Math.max(0, Math.floor(visitors)))).map(cell => cell.index));
}
export function liveVisitorStacks(cells: { lon: number; lat: number }[], visitors: number, seed: number, region: LiveRegion) {
  const active = [...liveVisitorHexagons(cells, visitors, seed, region)];
  const extra = distributeLiveTotal(Math.max(0, Math.floor(visitors) - active.length), active.length, seed + 73);
  return new Map(active.map((cell, i) => [cell, 1 + (extra[i] ?? 0)]));
}
export function liveVisitorIsRaised(index: number, seed: number) {
  // Only a small share of active cells become tall stacks; the rest stay flat.
  return (index + seed) % 10 === 0;
}
export function liveStackHeight(count: number, cell: number, seed: number) {
  const variation = 0.45 + random(seed + cell * 17) * 1.1;
  return Math.min(0.1, 0.008 + Math.log1p(count) * 0.018 * variation);
}
export function distributeLiveTotal(total: number, count: number, seed: number) {
  if (count <= 0) return [];
  const weights = Array.from({ length: count }, (_, i) => 0.2 + random(seed + i * 31));
  const sum = weights.reduce((a, b) => a + b, 0);
  let remaining = Math.round(total);
  return weights.map((weight, i) => {
    const value = i === count - 1 ? remaining : Math.floor(total * weight / sum);
    remaining -= value;
    return value;
  });
}
export function liveViewData(revenue: number, seed: number) {
  const valid = liveSetupSchema.safeParse({ revenue, seed });
  if (!valid.success || revenue === 0) return { totalSales: 0, visitors: 0, sessions: 0, orders: 0, carts: 0, checkingOut: 0, locationSessions: [0, 0, 0, 0, 0], trends: [0, 0, 0, 0, 0] };
  const orders = Math.max(1, Math.round(revenue / (45 + random(seed) * 70)));
  const sessions = Math.max(orders, Math.round(orders / (0.02 + random(seed + 1) * 0.035)));
  const checkingOut = Math.max(orders, Math.round(orders * (1.15 + random(seed + 2) * 0.7)));
  return {
    totalSales: revenue % 1 ? Math.round(revenue * 100) / 100 : revenue + (1 + Math.floor(random(seed + 91) * 99)) / 100, orders, sessions,
    visitors: Math.max(1, Math.round(sessions * (0.002 + random(seed + 3) * 0.009))),
    carts: Math.max(checkingOut, Math.round(checkingOut * (1.2 + random(seed + 4)))), checkingOut,
    locationSessions: distributeLiveTotal(sessions, 5, seed + 5),
    trends: Array.from({ length: 5 }, (_, i) => Math.round((random(seed + i * 7) - 0.25) * 2400) / 100),
  };
}
export type LiveViewData = ReturnType<typeof liveViewData>;