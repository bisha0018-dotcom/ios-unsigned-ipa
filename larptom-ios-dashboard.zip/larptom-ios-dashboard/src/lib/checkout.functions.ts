// Offline version: plans/prices kept, server actions return safe empty results.
export type CoinId = "BTC" | "LTC" | "SOL" | "ETH" | "USDT";
export const PLANS = {
  weekly: { name: "Weekly", priceUsd: 7.99, days: 7, blurb: "per 7 days" },
  monthly: { name: "Monthly", priceUsd: 19.99, days: 30, blurb: "per 30 days" },
  lifetime: { name: "Lifetime", priceUsd: 99, days: 36500, blurb: "one-time payment" },
} as const;
export type PlanId = keyof typeof PLANS;
export const LIFETIME_THRESHOLD_MS = 1000 * 60 * 60 * 24 * 365 * 5;
export const DISCOUNT_CODE = "LARPTOM";
export const DISCOUNT_PERCENT = 20;
export function priceWithDiscount(plan: PlanId, code?: string | null) {
  const base = PLANS[plan].priceUsd; const valid = code?.trim().toUpperCase() === DISCOUNT_CODE;
  return { valid, base, price: valid ? Number((base * 0.8).toFixed(2)) : base };
}
export type LicenseRow = any;
export type RevenueInsights = any;
const none = async (_o?: unknown): Promise<any> => null;
export const redeemLicense = async (_o?: unknown): Promise<any> => ({ ok: true, expiresAt: new Date(Date.now() + 36500 * 864e5).toISOString(), planName: "Lifetime", app: "shopify" });
export const isAdminKey = async (_o?: unknown): Promise<any> => ({ admin: false, isAdmin: false });
export const listLicenses = async (_o?: unknown): Promise<any> => [];
export const getRevenueInsights = none, createCryptoOrder = none, generateAdminLicense = none, setLicenseRevoked = none, deleteLicense = none;
