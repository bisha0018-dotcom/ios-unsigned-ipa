import blue192 from "@/assets/app-icons/dark-blue-192.png.asset.json";
import purple192 from "@/assets/app-icons/purple-192.png.asset.json";
import spring192 from "@/assets/app-icons/spring-192.png.asset.json";
import teal192 from "@/assets/app-icons/teal-192.png.asset.json";

export const INSTALL_ICON_KEY = "larptom.installIcon";

export const installIcons = [
  { id: "default", label: "Original", preview: "/icon-192.png", touchIcon: "/apple-touch-icon.png", manifest: "/manifest.webmanifest" },
  { id: "dark-blue", label: "Dark blue", preview: blue192.url, touchIcon: blue192.url, manifest: "/manifest-dark-blue.webmanifest" },
  { id: "teal", label: "Teal", preview: teal192.url, touchIcon: teal192.url, manifest: "/manifest-teal.webmanifest" },
  { id: "purple", label: "Purple", preview: purple192.url, touchIcon: purple192.url, manifest: "/manifest-purple.webmanifest" },
  { id: "spring", label: "Spring", preview: spring192.url, touchIcon: spring192.url, manifest: "/manifest-spring.webmanifest" },
] as const;

export type InstallIconId = (typeof installIcons)[number]["id"];

export function getInstallIcon(id: string | null) {
  return installIcons.find((icon) => icon.id === id) ?? installIcons[0];
}

export function applyInstallIcon(id: InstallIconId) {
  const icon = getInstallIcon(id);
  const manifest = document.querySelector<HTMLLinkElement>('link[rel="manifest"]');
  const touchIcon = document.querySelector<HTMLLinkElement>('link[rel="apple-touch-icon"]');
  if (manifest) manifest.href = icon.manifest;
  if (touchIcon) touchIcon.href = icon.touchIcon;
}