export const REFERENCE_TOTAL = 333333.33;
export const REFERENCE_SESSIONS = 56346;
export const AVERAGE_ORDER_VALUE = 227.57;

export function revenueFromPosition(position: number) {
  const raw = 1000 * 10000 ** (Math.max(0, Math.min(100, position)) / 100);
  const step = raw < 10000 ? 100 : raw < 100000 ? 1000 : raw < 1000000 ? 10000 : 100000;
  return Math.min(10000000, Math.max(1000, Math.round(raw / step) * step));
}

export function positionFromRevenue(revenue: number) {
  return Math.log10(Math.max(1000, revenue) / 1000) / 4 * 100;
}

function variation(seed: number) {
  const value = Math.sin(seed * 12.9898 + 78.233) * 43758.5453;
  return value - Math.floor(value);
}

export function shapeDesktopSeries(values: readonly number[], spikiness: number, seed: number) {
  if (!values.length) return [];
  const mean = values.reduce((sum, value) => sum + value, 0) / values.length;
  const spike = Math.max(0, Math.min(1, spikiness / 100));
  const phase = variation(seed) * Math.PI * 2;
  const frequency = 1 + variation(seed + 5) * 2;
  const generated = values.map((_, index) => {
    const t = index / Math.max(1, values.length - 1);
    const wave = Math.sin(t * Math.PI * 2 * frequency + phase) * 0.35
      + Math.cos(t * Math.PI * 4 + variation(seed + 9) * 6) * 0.16;
    const jagged = (variation(seed + index * 73) - 0.5) * 1.6;
    return Math.max(0.12, 1 + wave * (1 - spike * 0.35) + jagged * spike);
  });
  const generatedMean = generated.reduce((sum, value) => sum + value, 0) / generated.length;
  return generated.map(value => value / generatedMean * mean);
}

export function variedMoney(value: number) {
  const cents = Math.round(Math.abs(value) * 100);
  if (value === 0 || cents % 100 !== 0) return value;
  return Math.sign(value) * (cents + 1 + Math.floor(variation(cents) * 99)) / 100;
}

export function desktopAnalytics(monthlyRevenue: number, days: number, periodFactor = 1, seed = 99) {
  const totalSales = variedMoney(monthlyRevenue * days / 30 * periodFactor);
  const grossSales = totalSales * 1.05;
  const discounts = totalSales * 0.06615;
  const orders = Math.max(1, Math.round((grossSales - discounts) / AVERAGE_ORDER_VALUE));
  const averageOrderValue = (grossSales - discounts) / orders;
  const growth = Math.max(0, Math.min(1, positionFromRevenue(monthlyRevenue) / 100));
  const sessions = Math.max(orders, Math.round(orders / (0.026 + growth * 0.019)));
  const conversionRate = orders / sessions * 100;
  const funnelRates = [100, 12 + growth * 12, 7 + growth * 7, conversionRate];
  const returningRate = 8 + variation(monthlyRevenue + days * 17 + seed) * 16;
  return { totalSales, grossSales, discounts, orders, averageOrderValue, sessions, returningRate, conversionRate, funnelRates, fulfilled: Math.round(orders * 1275 / 1465), moneyScale: totalSales / REFERENCE_TOTAL, sessionScale: sessions / REFERENCE_SESSIONS };
}

export function formatDesktopMoney(value: number, compact = false) {
  return new Intl.NumberFormat("en-US", { style: "currency", currency: "USD", notation: compact ? "compact" : "standard", minimumFractionDigits: compact ? 0 : 2, maximumFractionDigits: compact ? 1 : 2 }).format(compact ? value : variedMoney(value));
}

export function normalizedSeries(values: readonly number[], total: number, buckets = 24) {
  const mean = values.reduce((sum, value) => sum + value, 0) / Math.max(1, values.length);
  return values.map((value) => value / Math.max(mean, 0.001) * total / buckets);
}

export function niceChartMaximum(values: readonly number[]) {
  const maximum = Math.max(1, ...values) * 1.12;
  const magnitude = 10 ** Math.floor(Math.log10(maximum));
  return Math.ceil(maximum / magnitude / 0.5) * magnitude * 0.5;
}