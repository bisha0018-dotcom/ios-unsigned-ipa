import { useEffect, useState } from "react";
import { onStoreChange, readStore, writeStore } from "@/lib/app-store";

export const CURRENCY_KEY = "bisha.currency";

export const CURRENCIES = [
  { symbol: "€", code: "EUR", label: "Euro" },
  { symbol: "$", code: "USD", label: "US Dollar" },
  { symbol: "£", code: "GBP", label: "British Pound" },
  { symbol: "CA$", code: "CAD", label: "Canadian Dollar" }, { symbol: "A$", code: "AUD", label: "Australian Dollar" },
  { symbol: "¥", code: "JPY", label: "Japanese Yen" }, { symbol: "CN¥", code: "CNY", label: "Chinese Yuan" },
  { symbol: "CHF", code: "CHF", label: "Swiss Franc" }, { symbol: "HK$", code: "HKD", label: "Hong Kong Dollar" },
  { symbol: "NZ$", code: "NZD", label: "New Zealand Dollar" }, { symbol: "kr", code: "SEK", label: "Swedish Krona" },
  { symbol: "₩", code: "KRW", label: "South Korean Won" }, { symbol: "S$", code: "SGD", label: "Singapore Dollar" },
  { symbol: "NOK", code: "NOK", label: "Norwegian Krone" }, { symbol: "MX$", code: "MXN", label: "Mexican Peso" },
  { symbol: "₹", code: "INR", label: "Indian Rupee" }, { symbol: "R$", code: "BRL", label: "Brazilian Real" },
  { symbol: "zł", code: "PLN", label: "Polish Zloty" }, { symbol: "DKK", code: "DKK", label: "Danish Krone" },
  { symbol: "Kč", code: "CZK", label: "Czech Koruna" }, { symbol: "₺", code: "TRY", label: "Turkish Lira" },
  { symbol: "฿", code: "THB", label: "Thai Baht" }, { symbol: "NT$", code: "TWD", label: "Taiwan Dollar" },
  { symbol: "د.إ", code: "AED", label: "UAE Dirham" }, { symbol: "﷼", code: "SAR", label: "Saudi Riyal" },
  { symbol: "₱", code: "PHP", label: "Philippine Peso" }, { symbol: "RM", code: "MYR", label: "Malaysian Ringgit" },
  { symbol: "Rp", code: "IDR", label: "Indonesian Rupiah" }, { symbol: "R", code: "ZAR", label: "South African Rand" },
  { symbol: "₪", code: "ILS", label: "Israeli Shekel" },
] as const;

const SYMBOLS = CURRENCIES.map((c) => c.symbol) as readonly string[];

export function readCurrency(): string {
  const stored = readStore(CURRENCY_KEY, "€");
  return CURRENCIES.find((currency) => currency.code === stored || currency.symbol === stored)?.symbol ?? "€";
}

export function readCurrencyCode(): string {
  const stored = readStore(CURRENCY_KEY, "EUR");
  return CURRENCIES.find((currency) => currency.code === stored || currency.symbol === stored)?.code ?? "EUR";
}

export function setCurrency(codeOrSymbol: string) {
  writeStore(CURRENCY_KEY, CURRENCIES.find((item) => item.code === codeOrSymbol || item.symbol === codeOrSymbol)?.code ?? "EUR");
}

/** Live currency symbol used by every money value in the app. */
export function useCurrency(): string {
  const [symbol, setSymbol] = useState("€");
  useEffect(() => {
    const sync = () => setSymbol(readCurrency());
    sync();
    return onStoreChange(sync);
  }, []);
  return symbol;
}

/** Swap a stored money prefix for the active currency symbol. */
export function withCurrency(prefix: string | undefined, symbol: string) {
  if (!prefix) return prefix;
  return SYMBOLS.includes(prefix) ? symbol : prefix;
}
