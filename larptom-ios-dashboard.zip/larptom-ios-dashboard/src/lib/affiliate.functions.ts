// Offline version: affiliate actions are no-ops in the standalone UI.
export type AdminAffiliate = any;
export type AffiliatePoint = { usd: number; paidAt: string; kind: string };
const none = async (_o?: unknown): Promise<any> => null;
export const getMyAffiliate = none, applyAffiliate = none, saveUsdcAddress = none, requestAffiliatePayout = none;
export const adminListAffiliates = async (_o?: unknown): Promise<any> => [];
export const adminApproveAffiliate = none, adminRejectAffiliate = none, adminDeleteAffiliate = none, adminMarkAffiliatePaid = none;
