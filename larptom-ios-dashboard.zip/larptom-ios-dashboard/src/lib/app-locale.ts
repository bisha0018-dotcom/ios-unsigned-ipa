import { useEffect, useState } from "react";
import { onStoreChange, readStore, writeStore } from "@/lib/app-store";
import { t as translatedText } from "@/lib/shopify-i18n";
import { translateUi } from "@/lib/ui-translation";

export const LANGUAGE_KEY = "bisha.language";

export const APP_LANGUAGES = [
  ["en", "English"], ["de", "Deutsch"], ["fr", "Français"], ["es", "Español"], ["it", "Italiano"],
  ["pt-BR", "Português (Brasil)"], ["pt", "Português"], ["nl", "Nederlands"], ["pl", "Polski"],
  ["ja", "日本語"], ["ko", "한국어"], ["zh-CN", "简体中文"], ["zh-TW", "繁體中文"], ["tr", "Türkçe"],
  ["th", "ไทย"], ["sv", "Svenska"], ["da", "Dansk"], ["fi", "Suomi"], ["nb", "Norsk"],
  ["cs", "Čeština"], ["ro", "Română"], ["hu", "Magyar"], ["id", "Bahasa Indonesia"],
  ["ms", "Bahasa Melayu"], ["vi", "Tiếng Việt"], ["hi", "हिन्दी"], ["ar", "العربية"], ["he", "עברית"],
] as const;

type AppText = "total_sales" | "orders" | "conversion_rate" | "sessions" | "today" | "yesterday" | "last_7_days" | "last_30_days" | "view_report";
const en = { total_sales: "Total sales", orders: "Orders", conversion_rate: "Conversion rate", sessions: "Sessions", today: "Today", yesterday: "Yesterday", last_7_days: "Last 7 days", last_30_days: "Last 30 days", view_report: "View report" };
const words: Record<string, Partial<Record<AppText, string>>> = {
  en,
  de: { total_sales: "Gesamtumsatz", orders: "Bestellungen", conversion_rate: "Conversion-Rate", sessions: "Sitzungen", today: "Heute", yesterday: "Gestern", last_7_days: "Letzte 7 Tage", last_30_days: "Letzte 30 Tage", view_report: "Bericht anzeigen" },
  fr: { total_sales: "Ventes totales", orders: "Commandes", conversion_rate: "Taux de conversion", sessions: "Sessions", today: "Aujourd'hui", yesterday: "Hier", last_7_days: "7 derniers jours", last_30_days: "30 derniers jours", view_report: "Voir le rapport" },
  es: { total_sales: "Ventas totales", orders: "Pedidos", conversion_rate: "Tasa de conversión", sessions: "Sesiones", today: "Hoy", yesterday: "Ayer", last_7_days: "Últimos 7 días", last_30_days: "Últimos 30 días", view_report: "Ver informe" },
  it: { total_sales: "Vendite totali", orders: "Ordini", conversion_rate: "Tasso di conversione", sessions: "Sessioni", today: "Oggi", yesterday: "Ieri", last_7_days: "Ultimi 7 giorni", last_30_days: "Ultimi 30 giorni", view_report: "Vedi rapporto" },
  pt: { total_sales: "Vendas totais", orders: "Encomendas", conversion_rate: "Taxa de conversão", sessions: "Sessões", today: "Hoje", yesterday: "Ontem", last_7_days: "Últimos 7 dias", last_30_days: "Últimos 30 dias", view_report: "Ver relatório" },
  "pt-BR": { total_sales: "Vendas totais", orders: "Pedidos", conversion_rate: "Taxa de conversão", sessions: "Sessões", today: "Hoje", yesterday: "Ontem", last_7_days: "Últimos 7 dias", last_30_days: "Últimos 30 dias", view_report: "Ver relatório" },
  nl: { total_sales: "Totale verkoop", orders: "Bestellingen", conversion_rate: "Conversieratio", sessions: "Sessies", today: "Vandaag", yesterday: "Gisteren", last_7_days: "Laatste 7 dagen", last_30_days: "Laatste 30 dagen", view_report: "Rapport bekijken" },
  sv: { total_sales: "Total försäljning", orders: "Beställningar", conversion_rate: "Konverteringsgrad", sessions: "Sessioner", today: "Idag", yesterday: "Igår", last_7_days: "Senaste 7 dagarna", last_30_days: "Senaste 30 dagarna", view_report: "Visa rapport" },
  tr: { total_sales: "Toplam satış", orders: "Siparişler", conversion_rate: "Dönüşüm oranı", sessions: "Oturumlar", today: "Bugün", yesterday: "Dün", last_7_days: "Son 7 gün", last_30_days: "Son 30 gün", view_report: "Raporu görüntüle" },
  ja: { total_sales: "総売上", orders: "注文", conversion_rate: "コンバージョン率", sessions: "セッション", today: "今日", yesterday: "昨日", last_7_days: "過去7日間", last_30_days: "過去30日間", view_report: "レポートを見る" },
  ko: { total_sales: "총 매출", orders: "주문", conversion_rate: "전환율", sessions: "세션", today: "오늘", yesterday: "어제", last_7_days: "지난 7일", last_30_days: "지난 30일", view_report: "보고서 보기" },
  "zh-CN": { total_sales: "总销售额", orders: "订单", conversion_rate: "转化率", sessions: "会话", today: "今天", yesterday: "昨天", last_7_days: "过去7天", last_30_days: "过去30天", view_report: "查看报告" },
  "zh-TW": { total_sales: "總銷售額", orders: "訂單", conversion_rate: "轉換率", sessions: "工作階段", today: "今天", yesterday: "昨天", last_7_days: "過去7天", last_30_days: "過去30天", view_report: "查看報告" },
  ar: { total_sales: "إجمالي المبيعات", orders: "الطلبات", conversion_rate: "معدل التحويل", sessions: "الجلسات", today: "اليوم", yesterday: "أمس", last_7_days: "آخر 7 أيام", last_30_days: "آخر 30 يومًا", view_report: "عرض التقرير" },
};

export function readLanguage() {
  const code = readStore(LANGUAGE_KEY, "en");
  return APP_LANGUAGES.some(([value]) => value === code) ? code : "en";
}
export function setLanguage(code: string) { writeStore(LANGUAGE_KEY, APP_LANGUAGES.some(([value]) => value === code) ? code : "en"); }
export function useLanguage() {
  const [language, setCurrent] = useState("en");
  useEffect(() => { const sync = () => setCurrent(readLanguage()); sync(); return onStoreChange(sync); }, []);
  return language;
}
export function appText(language: string, key: AppText) {
  if (key !== "view_report") return translatedText(language, key);
  return translateUi(language, en[key]);
}