// @ts-nocheck
import { useState, useEffect } from "react";

export function useLocalStorage<T>(key: string, initialValue: T): [T, React.Dispatch<React.SetStateAction<T>>] {
  const storageKey = key.startsWith("larptom:old:") ? key : `larptom:old:${key}`;
  const [value, setValue] = useState<T>(() => {
    try {
      const stored = localStorage.getItem(storageKey);
      return stored !== null ? JSON.parse(stored) : initialValue;
    } catch {
      return initialValue;
    }
  });

  useEffect(() => {
    try {
      const serialized = JSON.stringify(value);
      if (localStorage.getItem(storageKey) !== serialized) {
        localStorage.setItem(storageKey, serialized);
        window.dispatchEvent(new CustomEvent("local-storage-changed", { detail: { key: storageKey } }));
      }
    } catch {
      // ignore
    }
  }, [storageKey, value]);

  // Subscribe to external updates (other tabs + same-tab custom event)
  useEffect(() => {
    const sync = () => {
      try {
        const stored = localStorage.getItem(storageKey);
        if (stored !== null) {
          const parsed = JSON.parse(stored);
          setValue((prev) => (JSON.stringify(prev) === stored ? prev : parsed));
        }
      } catch {
        // ignore
      }
    };
    const onCustom = (e: Event) => {
      const detail = (e as CustomEvent).detail;
      if (!detail || detail.key === storageKey) sync();
    };
    window.addEventListener("storage", sync);
    window.addEventListener("local-storage-changed", onCustom);
    return () => {
      window.removeEventListener("storage", sync);
      window.removeEventListener("local-storage-changed", onCustom);
    };
  }, [storageKey]);

  return [value, setValue];
}
