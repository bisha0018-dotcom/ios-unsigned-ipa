// @ts-nocheck
import { useLocalStorage } from "@/old-mobile/hooks/use-local-storage";
import { getCurrencySymbol, formatCurrency, t } from "@/old-mobile/lib/shopify-i18n";

export function useShopifyLocale() {
  const [language] = useLocalStorage("larptom:old:shopify-language", "en");
  const [currency] = useLocalStorage("larptom:old:shopify-currency", "USD");

  const symbol = getCurrencySymbol(currency);

  return {
    language,
    currency,
    symbol,
    formatCurrency: (amount: number) => formatCurrency(amount, currency),
    t: (key: string) => t(language, key),
  };
}
