// @ts-nocheck
import { useCallback } from "react";
import { getCurrencySymbol, formatCurrency, t } from "@/old-mobile/lib/shopify-i18n";
import { ALL_RANGES, getRange, metricsKey, chartKey, chartCompKey } from "@/old-mobile/lib/dashboard-range";

function getLocale() {
  const lang = JSON.parse(localStorage.getItem("larptom:old:shopify-language") || '"en"');
  const cur = JSON.parse(localStorage.getItem("larptom:old:shopify-currency") || '"USD"');
  return { lang, cur };
}

export function useLiveMetrics() {
  const resetAll = useCallback(() => {
    const { lang, cur } = getLocale();
    const symbol = getCurrencySymbol(cur);
    const zero = ["JPY", "KRW", "IDR"].includes(cur) ? `${symbol}0` : `${symbol}0.00`;
    const ZERO_METRICS = [
      { label: t(lang, "total_sales"), value: zero, change: "0%" },
      { label: t(lang, "orders"), value: "0", change: "0%" },
      { label: t(lang, "conversion_rate"), value: "0.00%", change: "0%" },
      { label: t(lang, "sessions"), value: "0", change: "0%" },
    ];
    // Clear per-range metrics & chart data
    for (const r of ALL_RANGES) {
      localStorage.setItem(metricsKey(r), JSON.stringify(ZERO_METRICS));
      localStorage.removeItem(chartKey(r));
      localStorage.removeItem(chartCompKey(r));
    }
    // Legacy keys
    localStorage.setItem("larptom:old:dashboard-metrics", JSON.stringify(ZERO_METRICS));
    localStorage.removeItem("larptom:old:chart-keyframes");
    localStorage.removeItem("larptom:old:chart-comp-keyframes");
    localStorage.setItem("larptom:old:orders-fulfill-value", JSON.stringify("0"));
    localStorage.setItem("larptom:old:visitor-count", JSON.stringify(0));
    localStorage.setItem("larptom:old:active-metric", JSON.stringify({ label: t(lang, "total_sales"), value: zero }));
    window.dispatchEvent(new Event("storage"));
    window.dispatchEvent(new Event("metrics-reset"));
  }, []);

  return { resetAll };
}

/**
 * Called from sendOrderNotification to increment metrics for the currently-viewed range.
 */
export function incrementMetricsFromOrder(amount: number) {
  try {
    const { cur } = getLocale();
    const range = getRange();
    const key = metricsKey(range);
    const raw = localStorage.getItem(key) ?? localStorage.getItem("larptom:old:dashboard-metrics");
    const metrics = raw ? JSON.parse(raw) : null;
    if (!metrics || !Array.isArray(metrics)) return;

    const currentSales = parseFloat(metrics[0].value.replace(/[^0-9.-]/g, "")) || 0;
    const newSales = currentSales + amount;
    metrics[0].value = formatCurrency(newSales, cur);

    const currentOrders = parseInt(metrics[1].value.replace(/,/g, ""), 10) || 0;
    const newOrders = currentOrders + 1;
    metrics[1].value = newOrders.toLocaleString();

    const sessions = parseInt(metrics[3].value.replace(/,/g, ""), 10) || 0;
    if (sessions > 0) {
      metrics[2].value = `${((newOrders / sessions) * 100).toFixed(2)}%`;
    }

    localStorage.setItem(key, JSON.stringify(metrics));

    const fulfillRaw = localStorage.getItem("larptom:old:orders-fulfill-value");
    const currentFulfill = fulfillRaw ? parseInt(JSON.parse(fulfillRaw), 10) || 0 : 0;
    const newFulfill = currentFulfill + 1;
    localStorage.setItem("larptom:old:orders-fulfill-value", JSON.stringify(newFulfill >= 50 ? "50+" : String(newFulfill)));

    // Chart keyframes are intentionally left intact so the chart shape stays as-is
    // when an order notification fires. Only the report button regenerates the chart.

    window.dispatchEvent(new Event("storage"));
    window.dispatchEvent(new Event("metrics-updated"));
  } catch {}
}

