// @ts-nocheck
import { useEffect, useRef } from "react";
import { incrementMetricsFromOrder } from "@/old-mobile/hooks/use-live-metrics";
import { getCurrencySymbol } from "@/old-mobile/lib/shopify-i18n";
import { orderNotification } from "@/lib/ui-translation";

export interface StoredOrder {
  id: string;
  orderNumber: number;
  customerName: string;
  amount: string;
  items: number;
  timestamp: number; // Date.now()
  status: "Archived";
}

const SPEED_INTERVALS: Record<string, number> = {
  Noob: 1000,
  Beginner: 500,
  Pro: 250,
  Entrepreneur: 100,
};

const RANDOM_NAMES = [
  "Manuel Torres Azogue", "Pedro Raposeiro", "Jordi Peyro",
  "Sofia Martinez", "Carlos Mendez", "Ana Rodriguez",
  "Luis Fernandez", "Maria Lopez", "Diego Sanchez",
  "Isabella Garcia", "Andres Herrera", "Camila Flores",
  "Ricardo Morales", "Valentina Cruz", "Felipe Vargas",
  "Elena Gutierrez", "Pablo Navarro", "Lucia Dominguez",
  "Fernando Ramos", "Carmen Jimenez", "Alejandro Vega",
  "Natalia Ortiz", "Sergio Castillo", "Patricia Reyes",
  "Gabriel Romero", "Daniela Ruiz", "Hugo Delgado",
  "Adriana Soto", "Miguel Espinoza", "Laura Peña",
  "Raul Medina", "Clara Aguilar", "Oscar Fuentes",
  "Monica Salazar", "Javier Guerrero", "Teresa Montoya",
  "Emilio Cabrera", "Rosa Velasco", "Ivan Pacheco",
  "Andrea Figueroa", "Rafael Ibarra", "Julia Contreras",
  "Marco Villanueva", "Pilar Cárdenas",
  "Tomás Aguirre", "Silvia Bravo", "Roberto Gallegos",
  "Irene Paredes", "Héctor Maldonado", "Beatriz Serrano",
  "Santiago Rios", "Mariana Estrada", "Joaquin Lara",
  "Paulina Zavala", "Esteban Mora", "Lorena Campos",
  "Ignacio Pereira", "Renata Solís", "Cristian Duarte",
  "Catalina Vásquez", "Mateo Sandoval", "Alicia Ponce",
  "Rodrigo Bernal", "Verónica León", "Mauricio Trejo",
  "Diana Rojas", "Sebastián Acosta", "Fernanda Montes",
  "Alberto Rangel", "Gabriela Nava", "Enrique Padilla",
  "Paola Cervantes", "Arturo Miranda", "Ximena Becerra",
  "César Valdez", "Fabiola Orozco", "Leonardo Palacios",
  "Karla Esquivel", "Nicolás Coronado", "Alejandra Tovar",
  "Ramiro Bustamante", "Susana Carrillo", "Eduardo Barrón",
  "Mónica Camacho", "Damián Escalante", "Rocío Ávila",
  "Víctor Granados", "Marisol Tejeda", "Francisco Lugo",
  "Angélica Bautista", "Gonzalo Sepúlveda", "Liliana Paredes",
  "Iván Quintero", "Elisa Carvajal", "Rubén Cisneros",
  "Margarita Ochoa", "Alfredo Méndoza", "Norma Villegas",
];

function getStoreName(): string {
  try {
    const stored = localStorage.getItem("larptom:old:header-store-name");
    if (stored) return JSON.parse(stored);
  } catch {}
  return "My Store";
}

function getOrderNumber(): number {
  try {
    const stored = localStorage.getItem("larptom:old:notif-order-start");
    if (stored) return parseInt(JSON.parse(stored), 10) || 1000;
  } catch {}
  return 1000;
}

function incrementOrderNumber() {
  const current = getOrderNumber();
  localStorage.setItem("larptom:old:notif-order-start", JSON.stringify(String(current + 1)));
  window.dispatchEvent(new Event("storage"));
}

function isAutoEnabled(): boolean {
  try {
    return JSON.parse(localStorage.getItem("larptom:old:notif-auto") || "false");
  } catch { return false; }
}

function isPushEnabled(): boolean {
  try {
    return JSON.parse(localStorage.getItem("larptom:old:notif-push") || "false");
  } catch { return false; }
}

function getSpeed(): string {
  try {
    return JSON.parse(localStorage.getItem("larptom:old:notif-speed") || '"Beginner"');
  } catch { return "Beginner"; }
}

export function getStoredOrders(): StoredOrder[] {
  try {
    const stored = localStorage.getItem("larptom:old:stored-orders");
    if (stored) return JSON.parse(stored);
  } catch {}
  return [];
}

export function clearStoredOrders() {
  localStorage.removeItem("larptom:old:stored-orders");
  window.dispatchEvent(new Event("orders-updated"));
}

function saveOrder(order: StoredOrder) {
  const orders = getStoredOrders();
  orders.unshift(order);
  // Keep max 200 orders
  if (orders.length > 200) orders.length = 200;
  localStorage.setItem("larptom:old:stored-orders", JSON.stringify(orders));
  window.dispatchEvent(new Event("orders-updated"));
}

// iOS (16.4+) only delivers notifications through a service worker registration.
// The Notification constructor is unavailable inside installed PWAs there.
let swRegPromise: Promise<ServiceWorkerRegistration | null> | null = null;

export function ensureNotificationWorker(): Promise<ServiceWorkerRegistration | null> {
  if (!("serviceWorker" in navigator)) return Promise.resolve(null);
  if (!swRegPromise) {
    swRegPromise = navigator.serviceWorker
      .register("/notif-sw.js", { scope: "/" })
      .then((reg) => navigator.serviceWorker.ready.then(() => reg))
      .catch(() => null);
  }
  return swRegPromise;
}

export function requestNotificationPermission(): Promise<boolean> {
  if (!("Notification" in window)) return Promise.resolve(false);
  if (Notification.permission === "granted") return ensureNotificationWorker().then(() => true);
  if (Notification.permission === "denied") return Promise.resolve(false);
  return Notification.requestPermission().then(async (p) => {
    if (p !== "granted") return false;
    await ensureNotificationWorker();
    return true;
  });
}

async function showNotification(title: string, options: NotificationOptions) {
  const reg = await ensureNotificationWorker();
  if (reg) {
    try {
      await reg.showNotification(title, options);
      return;
    } catch {
      // fall through
    }
  }
  try {
    new Notification(title, options);
  } catch {
    // notifications unsupported in this context
  }
}


function isKaChingEnabled(): boolean {
  try {
    return JSON.parse(localStorage.getItem("larptom:old:notif-kaching") || "true");
  } catch { return true; }
}

let audioCtx: AudioContext | null = null;
let kaChingBuffer: AudioBuffer | null = null;
let kaChingLoading: Promise<void> | null = null;

function ensureAudioCtx(): AudioContext | null {
  try {
    if (!audioCtx) {
      const Ctx = (window.AudioContext || (window as any).webkitAudioContext);
      if (!Ctx) return null;
      audioCtx = new Ctx();
    }
    if (audioCtx.state === "suspended") audioCtx.resume().catch(() => {});
    return audioCtx;
  } catch { return null; }
}

function loadKaChing(): Promise<void> {
  if (kaChingBuffer) return Promise.resolve();
  if (kaChingLoading) return kaChingLoading;
  const ctx = ensureAudioCtx();
  if (!ctx) return Promise.resolve();
  kaChingLoading = fetch("/sounds/ka-ching.mp3")
    .then((r) => r.arrayBuffer())
    .then((buf) => new Promise<AudioBuffer>((resolve, reject) => {
      ctx.decodeAudioData(buf, resolve, reject);
    }))
    .then((decoded) => { kaChingBuffer = decoded; })
    .catch(() => {});
  return kaChingLoading;
}

// Prime on first user interaction (required by iOS) to unlock audio
if (typeof window !== "undefined") {
  const unlock = () => {
    ensureAudioCtx();
    loadKaChing();
    window.removeEventListener("touchstart", unlock);
    window.removeEventListener("click", unlock);
  };
  window.addEventListener("touchstart", unlock, { once: true });
  window.addEventListener("click", unlock, { once: true });
}

function playKaChing() {
  try {
    const ctx = ensureAudioCtx();
    if (!ctx) return;
    if (!kaChingBuffer) { loadKaChing(); return; }
    const src = ctx.createBufferSource();
    src.buffer = kaChingBuffer;
    const gain = ctx.createGain();
    gain.gain.value = 0.7;
    src.connect(gain).connect(ctx.destination);
    src.start(0);
  } catch {}
}

export function sendOrderNotification() {
  if (!("Notification" in window) || Notification.permission !== "granted") return;

  const storeName = getStoreName();
  const orderNum = getOrderNumber();

  let amount: string;
  let items: number;

  try {
    const fixedAmount = JSON.parse(localStorage.getItem("larptom:old:notif-fixed-amount") || "false");
    const fixedItem = JSON.parse(localStorage.getItem("larptom:old:notif-fixed-item") || "false");
    const amountValuesRaw = JSON.parse(localStorage.getItem("larptom:old:notif-amount-values") || "null");
    const legacyAmount = JSON.parse(localStorage.getItem("larptom:old:notif-amount-value") || '"49.99"');
    const itemVal = JSON.parse(localStorage.getItem("larptom:old:notif-item-count") || '"1"');

    let pickedFixed = legacyAmount;
    if (Array.isArray(amountValuesRaw)) {
      const active = amountValuesRaw.filter((v: string) => v && parseFloat(v) > 0);
      if (active.length > 0) pickedFixed = active[Math.floor(Math.random() * active.length)];
    }

    amount = fixedAmount ? pickedFixed : (Math.random() * 200 + 9.99).toFixed(2);
    items = fixedItem ? parseInt(itemVal, 10) || 1 : Math.floor(Math.random() * 5) + 1;
  } catch {
    amount = (Math.random() * 200 + 9.99).toFixed(2);
    items = Math.floor(Math.random() * 5) + 1;
  }

  const customerName = RANDOM_NAMES[Math.floor(Math.random() * RANDOM_NAMES.length)];

  // Save order to localStorage
  saveOrder({
    id: crypto.randomUUID(),
    orderNumber: orderNum,
    customerName,
    amount,
    items,
    timestamp: Date.now(),
    status: "Archived",
  });

  // Get selected currency symbol
  let currencyCode = "USD";
  try {
    currencyCode = JSON.parse(localStorage.getItem("larptom:old:shopify-currency") || '"USD"');
  } catch {}
  const symbol = getCurrencySymbol(currencyCode);

  let language = "en";
  try { language = JSON.parse(localStorage.getItem("larptom:old:shopify-language") || '"en"'); } catch {}
  const notification = orderNotification(language, orderNum, `${symbol}${amount}`, items, storeName);
  void showNotification(notification.title, {
    body: notification.body,
    icon: "/icon-192.png",
    badge: "/icon-192.png",
    tag: `order-${orderNum}`,
  });


  if (isKaChingEnabled()) {
    playKaChing();
  }

  incrementOrderNumber();

  // Update live metrics
  incrementMetricsFromOrder(parseFloat(amount));
}

function getNextInterval(): number {
  const speed = getSpeed();
  if (speed === "Beginner") {
    // Random between 0.5s and 2.5s
    return 500 + Math.random() * 2000;
  }
  return SPEED_INTERVALS[speed] || 3000;
}

export function useAutoNotifications() {
  const timeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const runningRef = useRef(false);

  useEffect(() => {
    if ("Notification" in window && Notification.permission === "granted") {
      void ensureNotificationWorker();
    }

    const stopLoop = () => {
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
        timeoutRef.current = null;
      }
      runningRef.current = false;
    };

    const scheduleNext = () => {
      timeoutRef.current = setTimeout(() => {
        if (!isAutoEnabled() || !isPushEnabled()) {
          stopLoop();
          return;
        }
        sendOrderNotification();
        scheduleNext();
      }, getNextInterval());
    };

    const startLoop = () => {
      stopLoop();
      if (!isAutoEnabled() || !isPushEnabled()) return;
      runningRef.current = true;
      sendOrderNotification();
      scheduleNext();
    };

    // Poll for setting changes every second
    const poller = setInterval(() => {
      const shouldRun = isAutoEnabled() && isPushEnabled();
      if (shouldRun && !runningRef.current) {
        startLoop();
      } else if (!shouldRun && runningRef.current) {
        stopLoop();
      }
    }, 1000);

    startLoop();

    return () => {
      clearInterval(poller);
      stopLoop();
    };
  }, []);
}
