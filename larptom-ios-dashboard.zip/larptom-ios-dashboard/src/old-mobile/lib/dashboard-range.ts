// @ts-nocheck
export type DashboardRange = "today" | "yesterday" | "last_7_days" | "last_30_days";

export const ALL_RANGES: DashboardRange[] = ["today", "yesterday", "last_7_days", "last_30_days"];
export const RANGE_KEY = "larptom:old:dashboard-range";

export function getRange(): DashboardRange {
  try {
    const v = JSON.parse(localStorage.getItem(RANGE_KEY) || '"today"');
    return ALL_RANGES.includes(v) ? v : "today";
  } catch {
    return "today";
  }
}

export function setRange(r: DashboardRange) {
  localStorage.setItem(RANGE_KEY, JSON.stringify(r));
  window.dispatchEvent(new CustomEvent("range-changed", { detail: r }));
}

export const metricsKey = (r: DashboardRange) => `larptom:old:dashboard-metrics-${r}`;
export const chartKey = (r: DashboardRange) => `larptom:old:chart-keyframes-${r}`;
export const chartCompKey = (r: DashboardRange) => `larptom:old:chart-comp-keyframes-${r}`;

export function useRangeListener(cb: (r: DashboardRange) => void) {
  // helper not used; subscriptions are inline in components
  void cb;
}
