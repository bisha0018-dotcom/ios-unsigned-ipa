// @ts-nocheck
import { Bell } from "lucide-react";
import EditableLogo from "./EditableLogo";
import { useState } from "react";
import { useLocalStorage } from "@/old-mobile/hooks/use-local-storage";

interface HeaderProps {
  chartEditMode?: boolean;
  onBellClick?: () => void;
}

const Header = ({ chartEditMode = false, onBellClick }: HeaderProps) => {
  const [notificationCount] = useState(1);
  const [storeName] = useLocalStorage<string>("larptom:old:header-store-name", "Change the name and logo");

  return (
    <div className="sticky top-0 z-20 bg-black">
      <div
        className="px-4 py-3 flex items-center justify-between"
        style={{ paddingTop: "max(env(safe-area-inset-top, 0px), 0.75rem)" }}
      >
        {/* Left side - Logo + Text */}
        <div className="flex items-center gap-2 flex-1 min-w-0">
          <EditableLogo initialText="AB" shape="rounded" size="sm" storageKey="header-logo" />
          <span className="text-white text-sm font-medium truncate">{storeName}</span>
        </div>

        {/* Right side - Bell + Logo */}
        <div className="flex items-center gap-2 ml-3">
          <button className="relative" onClick={onBellClick}>
            <Bell className="w-5 h-5 text-white" />
            {!chartEditMode && notificationCount > 0 && (
              <span className="absolute -top-1.5 -right-1.5 w-4 h-4 bg-notification rounded-full flex items-center justify-center">
                <span className="text-[10px] text-white font-bold">{notificationCount}</span>
              </span>
            )}
            {chartEditMode && (
              <span className="absolute -top-1.5 -right-1.5 w-4 h-4 bg-blue-500 rounded-full flex items-center justify-center">
                <span className="text-[10px] text-white font-bold">✎</span>
              </span>
            )}
          </button>
          <EditableLogo initialText="AB" shape="circle" size="sm" storageKey="header-avatar" />
        </div>
      </div>
    </div>
  );
};

export default Header;
