// @ts-nocheck
import { AppText } from "@/components/AppTranslation";
import { useState, useCallback, useEffect } from "react";
import useEmblaCarousel from "embla-carousel-react";
import { ArrowUpRight } from "lucide-react";

import { useShopifyLocale } from "@/old-mobile/hooks/use-shopify-locale";
import { getCurrencySymbol, formatCurrency, t } from "@/old-mobile/lib/shopify-i18n";
import { DashboardRange, getRange, metricsKey, chartKey, chartCompKey } from "@/old-mobile/lib/dashboard-range";

interface Metric {
  label: string;
  value: string;
  change: string;
}

function getZeroMetrics(lang: string, currencyCode: string): Metric[] {
  const symbol = getCurrencySymbol(currencyCode);
  const zero = ["JPY", "KRW", "IDR"].includes(currencyCode) ? `${symbol}0` : `${symbol}0.00`;
  return [
    { label: t(lang, "total_sales"), value: zero, change: "0%" },
    { label: t(lang, "orders"), value: "0", change: "0%" },
    { label: t(lang, "conversion_rate"), value: "0.00%", change: "0%" },
    { label: t(lang, "sessions"), value: "0", change: "0%" },
  ];
}

function randomizeMetrics(lang: string, currencyCode: string, range: DashboardRange): Metric[] {
  // Sales bounds per range
  const salesBounds: Record<DashboardRange, [number, number]> = {
    today: [2000, 15000],
    yesterday: [2000, 15000],
    last_7_days: [30000, 50000],
    last_30_days: [80000, 140000],
  };
  const [minSales, maxSales] = salesBounds[range];
  const sales = Math.random() * (maxSales - minSales) + minSales;

  // Average order value keeps orders WAY lower than sales (orders ≈ sales / AOV)
  const avgOrderValue = Math.random() * 120 + 60; // $60–$180 per order
  const orders = Math.max(1, Math.floor(sales / avgOrderValue));

  // Conversion rate 1–6% → sessions = orders / convRate
  const convRate = Math.random() * 5 + 1;
  const sessions = Math.max(orders + 10, Math.floor(orders / (convRate / 100)));

  return [
    { label: t(lang, "total_sales"), value: formatCurrency(sales, currencyCode), change: `${Math.floor(Math.random() * 900 + 10)}%` },
    { label: t(lang, "orders"), value: orders.toLocaleString(), change: `${Math.floor(Math.random() * 500 + 10)}%` },
    { label: t(lang, "conversion_rate"), value: `${convRate.toFixed(2)}%`, change: `${Math.floor(Math.random() * 900 + 10)}%` },
    { label: t(lang, "sessions"), value: sessions.toLocaleString(), change: `${Math.floor(Math.random() * 900 + 10)}%` },
  ];
}

const MetricsScroller = ({ onReportRef, onActiveMetricChange, onBackgroundClick }: { onReportRef?: (fn: () => void) => void; onActiveMetricChange?: (metric: Metric) => void; onBackgroundClick?: () => void }) => {
  const { language, currency, symbol } = useShopifyLocale();
  const [range, setRangeState] = useState<DashboardRange>(() => getRange());

  // Load metrics for the active range (per-range storage). Migrate legacy single key on first use.
  const loadMetricsFor = useCallback((r: DashboardRange): Metric[] => {
    try {
      const raw = localStorage.getItem(metricsKey(r));
      if (raw) return JSON.parse(raw);
      if (r === "today") {
        const legacy = localStorage.getItem("larptom:old:dashboard-metrics");
        if (legacy) return JSON.parse(legacy);
      }
    } catch {}
    return getZeroMetrics(language, currency);
  }, [language, currency]);

  const [metrics, setMetrics] = useState<Metric[]>(() => loadMetricsFor(getRange()));
  const [activeIndex, setActiveIndex] = useState(0);

  // Re-label metrics when language or currency changes
  useEffect(() => {
    setMetrics(prev => {
      const labels = [t(language, "total_sales"), t(language, "orders"), t(language, "conversion_rate"), t(language, "sessions")];
      return prev.map((m, i) => {
        let value = m.value;
        // Re-format currency value for total sales
        if (i === 0) {
          const numericVal = parseFloat(m.value.replace(/[^0-9.-]/g, "")) || 0;
          value = formatCurrency(numericVal, currency);
        }
        return { ...m, label: labels[i] || m.label, value };
      });
    });
  }, [language, currency]);

  const [emblaRef, emblaApi] = useEmblaCarousel({
    align: "start",
    containScroll: false,
    slidesToScroll: 1,
    loop: true,
  });

  const onSelect = useCallback(() => {
    if (!emblaApi) return;
    const idx = emblaApi.selectedScrollSnap();
    setActiveIndex(idx);
    onActiveMetricChange?.(metrics[idx]);
  }, [emblaApi, metrics, onActiveMetricChange]);

  useEffect(() => {
    if (!emblaApi) return;
    emblaApi.on("select", onSelect);
    emblaApi.on("reInit", onSelect);
    onSelect();
    onActiveMetricChange?.(metrics[0]);
    return () => {
      emblaApi.off("select", onSelect);
      emblaApi.off("reInit", onSelect);
    };
  }, [emblaApi, onSelect]);

  // Persist metrics to per-range key whenever metrics change
  useEffect(() => {
    try { localStorage.setItem(metricsKey(range), JSON.stringify(metrics)); } catch {}
  }, [metrics, range]);

  // React to range changes: load the metrics stored for that range
  useEffect(() => {
    const onRangeChange = () => {
      const r = getRange();
      setRangeState(r);
      const loaded = loadMetricsFor(r);
      setMetrics(loaded);
      const idx = emblaApi?.selectedScrollSnap() ?? 0;
      onActiveMetricChange?.(loaded[idx] ?? loaded[0]);
    };
    window.addEventListener("range-changed", onRangeChange);
    return () => window.removeEventListener("range-changed", onRangeChange);
  }, [emblaApi, onActiveMetricChange, loadMetricsFor]);

  useEffect(() => {
    const handler = () => {
      try {
        const raw = localStorage.getItem(metricsKey(range));
        if (raw) {
          const parsed = JSON.parse(raw);
          setMetrics(parsed);
          if (emblaApi) {
            const idx = emblaApi.selectedScrollSnap();
            onActiveMetricChange?.(parsed[idx]);
          }
        }
      } catch {}
    };
    window.addEventListener("metrics-updated", handler);
    window.addEventListener("metrics-reset", handler);
    return () => {
      window.removeEventListener("metrics-updated", handler);
      window.removeEventListener("metrics-reset", handler);
    };
  }, [setMetrics, emblaApi, onActiveMetricChange, range]);

  useEffect(() => {
    onReportRef?.(() => {
      const newMetrics = randomizeMetrics(language, currency, range);
      const currentActive = activeIndex;

      setMetrics(newMetrics);
      localStorage.setItem(metricsKey(range), JSON.stringify(newMetrics));
      localStorage.setItem("larptom:old:active-metric", JSON.stringify(newMetrics[currentActive]));
      onActiveMetricChange?.(newMetrics[currentActive]);

      const ordersVal = parseInt(newMetrics[1].value.replace(/,/g, ""), 10) || 0;
      const fulfillCount = Math.min(Math.floor(Math.random() * Math.max(ordersVal * 0.3, 1)) + 1, 50);
      localStorage.setItem("larptom:old:orders-fulfill-value", JSON.stringify(fulfillCount >= 50 ? "50+" : String(fulfillCount)));

      const sessions = parseInt(newMetrics[3].value.replace(/,/g, ""), 10) || 0;
      const visitors = Math.floor(sessions * (Math.random() * 0.02 + 0.005));
      localStorage.setItem("larptom:old:visitor-count", JSON.stringify(Math.max(1, visitors)));

      // Clear chart keyframes for this range so SalesChart regenerates a fresh varied shape
      localStorage.removeItem(chartKey(range));
      localStorage.removeItem(chartCompKey(range));

      window.dispatchEvent(new Event("storage"));
      window.dispatchEvent(new Event("metrics-updated"));
      window.dispatchEvent(new Event("chart-randomized"));
    });
  }, [onReportRef, activeIndex, onActiveMetricChange, language, currency, range]);

  // Read "show change %" toggle (default true)
  const [showChange, setShowChange] = useState<boolean>(() => {
    try {
      const raw = localStorage.getItem("larptom:old:show-change-pct");
      return raw === null ? true : JSON.parse(raw);
    } catch { return true; }
  });
  useEffect(() => {
    const sync = () => {
      try {
        const raw = localStorage.getItem("larptom:old:show-change-pct");
        setShowChange(raw === null ? true : JSON.parse(raw));
      } catch {}
    };
    window.addEventListener("storage", sync);
    window.addEventListener("metrics-updated", sync);
    return () => {
      window.removeEventListener("storage", sync);
      window.removeEventListener("metrics-updated", sync);
    };
  }, []);

  return (
    <div className="bg-white px-0 pt-2 pb-4" onClick={() => onBackgroundClick?.()}>
      <div className="relative overflow-hidden w-full" ref={emblaRef}>
        <div className="flex">
          {metrics.map((metric, index) => {
            const isActive = index === activeIndex;
            return (
              <div
                key={index}
                className="min-w-0 shrink-0 grow-0 basis-1/3 flex items-center pl-4"
              >
                <div
                  className="transition-all duration-300 ease-in-out py-1 w-full"
                  style={{ opacity: isActive ? 1 : 0.4 }}
                >
                  <div
                    className="text-xs mb-0 transition-all duration-300"
                    style={{
                      fontWeight: isActive ? 600 : 400,
                      color: isActive ? "#1a1a1a" : "#9ca3af",
                    }}
                  >
                    <AppText>{metric.label}</AppText>
                  </div>
                  <div
                    className="flex items-center text-base mt-1 mb-0 transition-all duration-300"
                    style={{
                      fontWeight: isActive ? 700 : 600,
                      color: isActive ? "#1a1a1a" : "#9ca3af",
                    }}
                  >
                    <span>{metric.value}</span>
                  </div>
                  {showChange && metric.change !== "0%" && (
                    <div className="flex items-center gap-1 -mt-0.5 text-green-700">
                      <ArrowUpRight className="w-5 h-5" />
                      <span className="text-green-700 text-sm font-semibold">{metric.change}</span>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default MetricsScroller;
