// @ts-nocheck
import { AppText } from "@/components/AppTranslation";
import { useState, useRef, useEffect } from "react";
import { createPortal } from "react-dom";
import { MoreHorizontal, ArrowUp, ArrowDown } from "lucide-react";

interface SectionMenuProps {
  canMoveUp: boolean;
  canMoveDown: boolean;
  onMoveUp: () => void;
  onMoveDown: () => void;
}

const SectionMenu = ({ canMoveUp, canMoveDown, onMoveUp, onMoveDown }: SectionMenuProps) => {
  const [open, setOpen] = useState(false);
  const btnRef = useRef<HTMLButtonElement>(null);
  const menuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return;
    const handler = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node) &&
          btnRef.current && !btnRef.current.contains(e.target as Node)) {
        setOpen(false);
      }
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, [open]);

  const [pos, setPos] = useState({ top: 0, right: 0 });

  useEffect(() => {
    if (open && btnRef.current) {
      const rect = btnRef.current.getBoundingClientRect();
      setPos({ top: rect.bottom + 4, right: window.innerWidth - rect.right });
    }
  }, [open]);

  return (
    <>
      <button
        ref={btnRef}
        onClick={() => setOpen(!open)}
        className="text-gray-400 text-sm font-bold ml-4 hover:text-gray-600 transition-colors"
      >
        <MoreHorizontal className="w-5 h-5" />
      </button>
      {open && createPortal(
        <div
          ref={menuRef}
          className="fixed z-[9999] bg-white rounded-xl shadow-lg border border-gray-200 py-1 min-w-[160px] animate-scale-in"
          style={{ top: pos.top, right: pos.right }}
        >
          {canMoveUp && (
            <button
              onClick={() => { onMoveUp(); setOpen(false); }}
              className="flex items-center gap-3 w-full px-4 py-2.5 text-sm text-gray-700 hover:bg-gray-50 transition-colors"
            >
              <ArrowUp className="w-4 h-4" /><AppText>
              Move up
            </AppText></button>
          )}
          {canMoveDown && (
            <button
              onClick={() => { onMoveDown(); setOpen(false); }}
              className="flex items-center gap-3 w-full px-4 py-2.5 text-sm text-gray-700 hover:bg-gray-50 transition-colors"
            >
              <ArrowDown className="w-4 h-4" /><AppText>
              Move down
            </AppText></button>
          )}
        </div>,
        document.body
      )}
    </>
  );
};

export default SectionMenu;
