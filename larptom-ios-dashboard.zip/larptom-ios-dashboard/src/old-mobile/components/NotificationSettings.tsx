// @ts-nocheck
import { AppText } from "@/components/AppTranslation";
import { useState } from "react";
import { Bell, X, Send, Hash, Volume2 } from "lucide-react";
import { useLocalStorage } from "@/old-mobile/hooks/use-local-storage";
import { requestNotificationPermission, sendOrderNotification } from "@/old-mobile/hooks/use-notifications";

interface NotificationSettingsProps {
  open: boolean;
  onClose: () => void;
}

const speeds = ["Noob", "Beginner", "Pro", "Entrepreneur"] as const;

const Toggle = ({ checked, onChange }: { checked: boolean; onChange: (v: boolean) => void }) => (
  <button
    onClick={() => onChange(!checked)}
    className={`relative w-12 h-7 rounded-full transition-colors ${checked ? "bg-blue-500" : "bg-gray-300"}`}
  >
    <div className={`absolute top-0.5 w-6 h-6 bg-white rounded-full shadow transition-transform ${checked ? "translate-x-5" : "translate-x-0.5"}`} />
  </button>
);

const NotificationSettings = ({ open, onClose }: NotificationSettingsProps) => {
  const [pushEnabled, setPushEnabled] = useLocalStorage("larptom:old:notif-push", false);
  const [autoEnabled, setAutoEnabled] = useLocalStorage("larptom:old:notif-auto", false);
  const [speed, setSpeed] = useLocalStorage("larptom:old:notif-speed", "Beginner");
  const [fixedAmount, setFixedAmount] = useLocalStorage("larptom:old:notif-fixed-amount", false);
  const [amountValues, setAmountValues] = useLocalStorage<string[]>("larptom:old:notif-amount-values", ["49.99", "", "", ""]);
  const [amountDrafts, setAmountDrafts] = useState<string[]>(() => {
    const base = amountValues.slice(0, 4);
    while (base.length < 4) base.push("");
    return base;
  });
  const [fixedItemCount, setFixedItemCount] = useLocalStorage("larptom:old:notif-fixed-item", false);
  const [itemCount, setItemCount] = useLocalStorage("larptom:old:notif-item-count", "1");
  const [itemDraft, setItemDraft] = useState(itemCount);
  const [kaChingEnabled, setKaChingEnabled] = useLocalStorage("larptom:old:notif-kaching", true);
  const [orderStart, setOrderStart] = useLocalStorage("larptom:old:notif-order-start", "1000");
  const [orderDraft, setOrderDraft] = useState(orderStart);

  if (!open) return null;

  const handleTogglePush = async (val: boolean) => {
    if (val) {
      const granted = await requestNotificationPermission();
      setPushEnabled(granted);
    } else {
      setPushEnabled(false);
      setAutoEnabled(false);
    }
  };

  const handleToggleAuto = async (val: boolean) => {
    if (val && !pushEnabled) {
      const granted = await requestNotificationPermission();
      setPushEnabled(granted);
      if (!granted) return;
    }
    setAutoEnabled(val);
  };

  const handleSendNotification = async () => {
    if (!pushEnabled) {
      const granted = await requestNotificationPermission();
      setPushEnabled(granted);
      if (!granted) return;
    }
    sendOrderNotification();
  };

  const handleSetOrder = () => {
    setOrderStart(orderDraft);
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-end justify-center">
      <div className="absolute inset-0 bg-black/40" onClick={onClose} />
      <div className="relative bg-white rounded-t-2xl w-full max-w-md max-h-[85vh] overflow-y-auto shadow-xl animate-in slide-in-from-bottom">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-gray-100">
          <div className="flex items-center gap-2">
            <Bell className="w-5 h-5 text-gray-700" />
            <h2 className="text-lg font-bold text-gray-900"><AppText>Notification Settings</AppText></h2>
          </div>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-4 space-y-6">
          {/* Push Notifications */}
          <div className="flex items-center justify-between">
            <span className="text-sm font-semibold text-gray-900"><AppText>Push Notifications for Sales</AppText></span>
            <Toggle checked={pushEnabled} onChange={handleTogglePush} />
          </div>

          {/* Send Notification Button */}
          <button
            onClick={handleSendNotification}
            className="w-full flex items-center justify-center gap-2 bg-gradient-to-r from-red-400 to-pink-400 text-white font-semibold py-3 rounded-xl shadow hover:opacity-90 transition-opacity"
          >
            <Send className="w-4 h-4" /><AppText>
            Send Notification
          </AppText></button>

          {/* Auto Notifications */}
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-semibold text-gray-900"><AppText>Auto Notifications</AppText></p>
              <p className="text-xs text-gray-500"><AppText>
                Send notifications automatically every{" "}
                {speed === "Noob" ? "1s" : speed === "Beginner" ? "0.5–2.5s" : speed === "Pro" ? "0.25s" : "0.1s"}
              </AppText></p>
            </div>
            <Toggle checked={autoEnabled} onChange={handleToggleAuto} />
          </div>

          {/* Ka-Ching Sound */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Volume2 className="w-4 h-4 text-gray-500" />
              <div>
                <p className="text-sm font-semibold text-gray-900"><AppText>Ka-Ching Sound</AppText></p>
                <p className="text-xs text-gray-500"><AppText>Play sound with notifications</AppText></p>
              </div>
            </div>
            <Toggle checked={kaChingEnabled} onChange={setKaChingEnabled} />
          </div>

          {/* Notification Speed */}
          <div>
            <p className="text-sm font-semibold text-gray-900 mb-2"><AppText>Notification Speed</AppText></p>
            <div className="flex gap-1">
              {speeds.map((s) => (
                <button
                  key={s}
                  onClick={() => setSpeed(s)}
                  className={`flex-1 py-2 text-xs font-medium rounded-lg border transition-colors ${
                    speed === s
                      ? "bg-gray-200 border-gray-300 text-gray-900"
                      : "bg-white border-gray-200 text-gray-500 hover:bg-gray-50"
                  }`}
                >
                  {s}
                </button>
              ))}
            </div>
          </div>

          {/* Fixed Order Amount */}
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-semibold text-gray-900"><AppText>Fixed Order Amount</AppText></p>
              <p className="text-xs text-gray-500"><AppText>Use a fixed amount for all notifications</AppText></p>
            </div>
            <Toggle checked={fixedAmount} onChange={setFixedAmount} />
          </div>

          {fixedAmount && (
            <div>
              <p className="text-xs font-medium text-gray-700 mb-1"><AppText>Order Amounts</AppText></p>
              <p className="text-[11px] text-gray-500 mb-2"><AppText>Add up to 4 amounts. Empty or 0 are ignored. Notifications pick randomly from the list.</AppText></p>
              <div className="grid grid-cols-2 gap-2 mb-2">
                {amountDrafts.map((val, i) => (
                  <input
                    key={i}
                    type="text"
                    placeholder={i === 0 ? "49.99" : "…"}
                    value={val}
                    onChange={(e) => {
                      const next = [...amountDrafts];
                      next[i] = e.target.value;
                      setAmountDrafts(next);
                    }}
                    className="w-full border border-gray-200 rounded-lg px-2 py-1.5 text-xs text-gray-900 outline-none focus:border-gray-400 text-center"
                  />
                ))}
              </div>
              <button
                onClick={() => setAmountValues([...amountDrafts])}
                className="w-full border border-gray-200 rounded-lg py-2.5 text-sm font-medium text-gray-600 hover:bg-gray-50 transition-colors mb-2"
              ><AppText>
                Set Amounts
              </AppText></button>
              <p className="text-xs text-gray-500">
                {(() => {
                  const active = amountValues.filter((v) => v && parseFloat(v) > 0);
                  return active.length > 0
                    ? `Notifications will randomly show: ${active.map((v) => `$${v}`).join(", ")}`
                    : "No active amounts — notifications will use a random amount.";
                })()}
              </p>
            </div>
          )}

          {/* Fixed Item Count */}
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-semibold text-gray-900"><AppText>Fixed Item Count</AppText></p>
              <p className="text-xs text-gray-500"><AppText>Use a fixed number of items for all notifications</AppText></p>
            </div>
            <Toggle checked={fixedItemCount} onChange={setFixedItemCount} />
          </div>

          {fixedItemCount && (
            <div>
              <p className="text-xs font-medium text-gray-700 mb-1"><AppText>Number of Items</AppText></p>
              <input
                type="text"
                value={itemDraft}
                onChange={(e) => setItemDraft(e.target.value)}
                onBlur={() => setItemCount(itemDraft)}
                className="w-full border border-gray-200 rounded-lg px-3 py-2.5 text-sm text-gray-900 outline-none focus:border-gray-400"
              />
            </div>
          )}

          {/* Divider */}
          <div className="h-px bg-gray-200" />

          {/* Order Number Settings */}
          <div>
            <div className="flex items-center gap-2 mb-3">
              <Hash className="w-4 h-4 text-gray-700" />
              <h3 className="text-sm font-bold text-gray-900"><AppText>Order Number Settings</AppText></h3>
            </div>
            <p className="text-xs font-medium text-gray-700 mb-1"><AppText>Start Order Number</AppText></p>
            <input
              type="text"
              value={orderDraft}
              onChange={(e) => setOrderDraft(e.target.value)}
              className="w-full border border-gray-200 rounded-lg px-3 py-2.5 text-sm text-gray-900 outline-none focus:border-gray-400 mb-2"
            />
            <button
              onClick={handleSetOrder}
              className="w-full border border-gray-200 rounded-lg py-2.5 text-sm font-medium text-gray-600 hover:bg-gray-50 transition-colors mb-2"
            ><AppText>
              Set Order Start Number
            </AppText></button>
            <p className="text-xs text-gray-500"><AppText>Next order will be #{orderStart}</AppText></p>
          </div>

          <div className="h-4" />
        </div>
      </div>
    </div>
  );
};

export default NotificationSettings;
