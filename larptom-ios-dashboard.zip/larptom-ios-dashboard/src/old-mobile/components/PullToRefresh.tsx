// @ts-nocheck
import { useState, useRef, useCallback, useEffect } from "react";

interface PullToRefreshProps {
  children: React.ReactNode;
  beforeSpinner?: React.ReactNode;
  onRefresh?: () => void;
  spinnerBg?: string;
  refreshDuration?: number;
  disabled?: boolean;
}

const TOTAL_BARS = 8;
const THRESHOLD = 70;

const PullToRefresh = ({ children, beforeSpinner, onRefresh, spinnerBg = "bg-white", refreshDuration = 1200, disabled = false }: PullToRefreshProps) => {
  const [pullDistance, setPullDistance] = useState(0);
  const [refreshing, setRefreshing] = useState(false);
  const [zoomingOut, setZoomingOut] = useState(false);
  const startYRef = useRef(0);
  const pullingRef = useRef(false);
  const containerRef = useRef<HTMLDivElement>(null);

  const handleTouchStart = useCallback((e: React.TouchEvent) => {
    if (disabled) return;
    if (containerRef.current && containerRef.current.scrollTop <= 0 && !refreshing) {
      startYRef.current = e.touches[0].clientY;
      pullingRef.current = true;
    }
  }, [refreshing, disabled]);

  const handleTouchMove = useCallback((e: React.TouchEvent) => {
    if (!pullingRef.current) return;
    const diff = e.touches[0].clientY - startYRef.current;
    if (diff > 0) {
      e.preventDefault();
      // Rubber-band feel, no cap — user can pull as far as they want
      setPullDistance(diff * 0.5);
    }
  }, []);

  const handleTouchEnd = useCallback(() => {
    if (!pullingRef.current) return;
    pullingRef.current = false;
    if (pullDistance >= THRESHOLD) {
      setRefreshing(true);
      setZoomingOut(false);
      setPullDistance(50);
      onRefresh?.();
      setTimeout(() => {
        setZoomingOut(true);
        setTimeout(() => {
          setRefreshing(false);
          setZoomingOut(false);
          setPullDistance(0);
        }, 300);
      }, refreshDuration);
    } else {
      setPullDistance(0);
    }
  }, [pullDistance, onRefresh, refreshDuration]);

  // Mouse support for desktop
  const mouseDownRef = useRef(false);

  const handleMouseDown = useCallback((e: React.MouseEvent) => {
    if (disabled) return;
    if (containerRef.current && containerRef.current.scrollTop <= 0 && !refreshing) {
      startYRef.current = e.clientY;
      mouseDownRef.current = true;
    }
  }, [refreshing, disabled]);

  const handleMouseMove = useCallback((e: React.MouseEvent) => {
    if (!mouseDownRef.current) return;
    const diff = e.clientY - startYRef.current;
    if (diff > 0) {
      setPullDistance(diff * 0.5);
    }
  }, []);

  const handleMouseUp = useCallback(() => {
    if (!mouseDownRef.current) return;
    mouseDownRef.current = false;
    if (pullDistance >= THRESHOLD) {
      setRefreshing(true);
      setZoomingOut(false);
      setPullDistance(50);
      onRefresh?.();
      setTimeout(() => {
        setZoomingOut(true);
        setTimeout(() => {
          setRefreshing(false);
          setZoomingOut(false);
          setPullDistance(0);
        }, 300);
      }, refreshDuration);
    } else {
      setPullDistance(0);
    }
  }, [pullDistance, onRefresh, refreshDuration]);

  useEffect(() => {
    const up = () => {
      if (mouseDownRef.current) {
        mouseDownRef.current = false;
        setPullDistance(0);
      }
    };
    window.addEventListener("mouseup", up);
    return () => window.removeEventListener("mouseup", up);
  }, []);

  // How many bars to show based on pull progress
  const progress = Math.min(pullDistance / THRESHOLD, 1);
  const visibleBars = refreshing ? TOTAL_BARS : Math.floor(progress * TOTAL_BARS);

  return (
    <div
      ref={containerRef}
      className="relative overflow-y-auto overflow-x-hidden h-full scrollbar-hide"
      style={{ overscrollBehavior: "contain", WebkitOverflowScrolling: "touch", scrollbarWidth: "none", msOverflowStyle: "none" }}
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
      onMouseDown={handleMouseDown}
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
    >
      {beforeSpinner}
      {/* Spinner */}
      <div
        className={`flex items-center justify-center ${spinnerBg}`}
        style={{
          height: pullDistance > 0 || refreshing ? Math.max(pullDistance, refreshing ? 50 : 0) : 0,
          transition: !pullingRef.current && !mouseDownRef.current ? "height 0.3s ease" : "none",
          overflow: "hidden",
        }}
      >
        <div
          style={{
            transform: zoomingOut ? "scale(0)" : `scale(${refreshing ? 1 : 0.3 + progress * 0.7})`,
            opacity: zoomingOut ? 0 : refreshing ? 1 : Math.min(0.4 + progress * 0.6, 1),
            transition: pullingRef.current || mouseDownRef.current ? "none" : "transform 0.3s ease, opacity 0.3s ease",
          }}
        >
          <SpinnerIcon
            visibleBars={visibleBars}
            spinning={refreshing}
          />
        </div>
      </div>

      {children}
    </div>
  );
};

const SpinnerIcon = ({ visibleBars, spinning }: { visibleBars: number; spinning: boolean }) => {
  return (
    <svg
      width="32"
      height="32"
      viewBox="0 0 24 24"
      className={spinning ? "animate-spin" : ""}
      style={{ animationDuration: "0.8s" }}
    >
      {Array.from({ length: TOTAL_BARS }).map((_, i) => {
        const angle = (i * 360) / TOTAL_BARS;
        const opacity = i < visibleBars ? 0.2 + (i / TOTAL_BARS) * 0.8 : 0.05;
        return (
          <rect
            key={i}
            x="10.75"
            y="1.5"
            width="2.5"
            height="6"
            rx="1.25"
            fill="#9ca3af"
            opacity={opacity}
            transform={`rotate(${angle} 12 12)`}
          />
        );
      })}
    </svg>
  );
};

export default PullToRefresh;
