// @ts-nocheck
import { useAppTranslation } from "@/components/AppTranslation";
import { AppText } from "@/components/AppTranslation";
import { ReactNode } from "react";
import { MoreHorizontal } from "lucide-react";
import widgetImg from "@/assets/old-mobile/widget-preview.png";

const ShopifyWidget = ({ menuSlot }: { menuSlot?: ReactNode }) => {
  const translateAttribute = useAppTranslation();
  return (
    <div className="px-3 pb-4 py-0">
      <div>
        <div className="flex items-start justify-between mb-1">
          <h2 className="text-left text-[15px] text-gray-700 font-bold leading-tight m-0 p-0"><AppText>
            Instant store performance insights at your fingertips
          </AppText></h2>
          {menuSlot || (
            <button className="text-gray-400 text-sm font-bold ml-4 hover:text-gray-600 transition-colors">
              <MoreHorizontal className="w-5 h-5" />
            </button>
          )}
        </div>

        <div className="flex items-start gap-0 mb-4">
          <div className="text-left text-[15px] text-gray-700 font-normal flex-1 min-w-0">
            Track store performance easily with at-a-glance insights directly from the home and lock screen of your mobile device or macOS Sonoma desktop.
          </div>
          <div className="flex-shrink-0 -mt-1 ml-auto">
            <img src={widgetImg} alt={translateAttribute("Widget Preview")} className="w-[88px] h-[88px] object-contain" />
          </div>
        </div>

        <div className="text-center">
          <button className="bg-white border border-gray-300 rounded-lg px-6 py-3 text-gray-700 font-bold text-sm shadow-sm hover:bg-gray-50 transition-colors w-full max-w-xs mx-auto"><AppText>
            Add Shopify widget
          </AppText></button>
        </div>

        <div className="h-[7px] mx-[-1rem] my-6" style={{ backgroundColor: "rgb(239, 239, 239)" }} />
      </div>
    </div>
  );
};

export default ShopifyWidget;
