// @ts-nocheck
import { useAppTranslation } from "@/components/AppTranslation";
import { AppText } from "@/components/AppTranslation";
import { ReactNode } from "react";
import { MoreHorizontal } from "lucide-react";
import shopifyPlusImg from "@/assets/old-mobile/shopify-plus-offer.png";

const ShopifyPlusOffer = ({ menuSlot }: { menuSlot?: ReactNode }) => {
  const translateAttribute = useAppTranslation();
  return (
    <div className="px-3 pb-4">
      <div>
        <div className="flex items-start justify-between mb-1">
          <h2 className="text-left text-[15px] text-gray-700 font-bold leading-tight m-0 p-0"><AppText>
            Offer: Try the Plus plan at your current monthly platform fee
          </AppText></h2>
          {menuSlot || (
            <button className="text-gray-400 text-sm font-bold ml-4 hover:text-gray-600 transition-colors">
              <MoreHorizontal className="w-5 h-5" />
            </button>
          )}
        </div>

        <div className="flex items-start gap-3 mb-4">
          <div className="text-left text-[15px] text-gray-700 font-normal flex-1 min-w-0">
            Get access to two months of Plus-exclusive features like B2B, Audiences, and priority support at your current monthly platform fee.
          </div>
          <div className="flex-shrink-0 self-start">
            <img src={shopifyPlusImg} alt={translateAttribute("Shopify Plus Offer")} className="w-32 h-auto rounded-lg block" />
          </div>
        </div>

        <div className="text-center mb-4">
          <button
            className="bg-white border border-gray-300 rounded-lg px-6 py-3 text-gray-700 font-bold text-sm shadow-sm hover:bg-gray-50 transition-colors w-full max-w-xs mx-auto"
          ><AppText>
            Start 2-month trial
          </AppText></button>
        </div>

        <div className="h-[7px] mx-[-1rem] my-6" style={{ backgroundColor: "rgb(239, 239, 239)" }} />
      </div>
    </div>
  );
};

export default ShopifyPlusOffer;
