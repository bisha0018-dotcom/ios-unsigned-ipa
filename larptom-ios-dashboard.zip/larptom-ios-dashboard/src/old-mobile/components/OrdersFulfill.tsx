// @ts-nocheck
import { AppText } from "@/components/AppTranslation";
import { useEffect } from "react";
import ordersIcon from "@/assets/old-mobile/icon-orders-fulfill.png";
import captureIcon from "@/assets/icon-payments-capture.png.asset.json";
import returnsIcon from "@/assets/icon-return-requests.png.asset.json";
import highRiskIcon from "@/assets/icon-high-risk.png.asset.json";
import chargebacksIcon from "@/assets/icon-chargebacks.png.asset.json";
import blockIcon from "@/assets/icon-orders-block.png.asset.json";
import { useLocalStorage } from "@/old-mobile/hooks/use-local-storage";
import { useShopifyLocale } from "@/old-mobile/hooks/use-shopify-locale";

const OrdersFulfill = () => {
  const { t } = useShopifyLocale();
  const [fulfill, setFulfill] = useLocalStorage("larptom:old:orders-fulfill-value", "50+");
  const [capture] = useLocalStorage("larptom:old:activity-capture", "8");
  const [returns] = useLocalStorage("larptom:old:activity-returns", "2");
  const [highRisk] = useLocalStorage("larptom:old:activity-highrisk", "3");
  const [chargebacks] = useLocalStorage("larptom:old:activity-chargebacks", "5");
  const [block] = useLocalStorage("larptom:old:activity-block", "1");

  useEffect(() => {
    const handler = () => {
      try {
        const raw = localStorage.getItem("larptom:old:orders-fulfill-value");
        if (raw) setFulfill(JSON.parse(raw));
      } catch {}
    };
    window.addEventListener("metrics-updated", handler);
    window.addEventListener("metrics-reset", handler);
    return () => {
      window.removeEventListener("metrics-updated", handler);
      window.removeEventListener("metrics-reset", handler);
    };
  }, [setFulfill]);

  const cards = [
    { id: "fulfill", value: fulfill, label: t("orders_to_fulfill"), icon: ordersIcon, alt: "Orders" },
    { id: "capture", value: capture, label: "Capture payments", icon: captureIcon.url, alt: "Payments" },
    { id: "returns", value: returns, label: "Return requests", icon: returnsIcon.url, alt: "Returns" },
    { id: "highrisk", value: highRisk, label: "High risk orders", icon: highRiskIcon.url, alt: "High risk" },
    { id: "chargebacks", value: chargebacks, label: "Chargebacks", icon: chargebacksIcon.url, alt: "Chargebacks" },
    { id: "block", value: block, label: "Orders with block...", icon: blockIcon.url, alt: "Orders blocked" },
  ].filter((card) => (parseInt(String(card.value).replace(/\+/g, ""), 10) || 0) > 0);

  if (cards.length === 0) return null;

  return (
    <div className="grid grid-cols-3 gap-2 bg-white px-3">
      {cards.map((card) => (
        <div key={card.id} className="min-w-0 rounded-xl bg-gray-100 px-2 py-2">
          <div className="flex flex-col">
            <div className="flex items-center justify-between gap-1">
              <span className="text-[16px] font-bold text-gray-700">{card.value}</span>
              <img src={card.icon} alt={card.alt} className="h-[18px] w-[18px] shrink-0 object-contain" />
            </div>
            <span className="mt-0.5 truncate text-[10px] text-gray-400"><AppText>{card.label}</AppText></span>
          </div>
        </div>
      ))}
    </div>
  );
};

export default OrdersFulfill;

