// @ts-nocheck
import { useAppTranslation } from "@/components/AppTranslation";
import { useState } from "react";
import { Menu, Search } from "lucide-react";

import homeIcon from "@/assets/old-mobile/home-icon.png";
import homeIconActive from "@/assets/old-mobile/home-icon-active.png";
import clipsIcon from "@/assets/old-mobile/clips-icon.png";
import clipsIconActive from "@/assets/old-mobile/clips-icon-active.png";
import tagIcon from "@/assets/old-mobile/tag-icon.png";
import profileIcon from "@/assets/old-mobile/profile-icon.png";
import QuickEditOverlay from "./QuickEditOverlay";

interface BottomNavProps {
  showOrders: boolean;
  onShowOrdersChange: (show: boolean) => void;
}

const BottomNav = ({ showOrders, onShowOrdersChange }: BottomNavProps) => {
  const translateAttribute = useAppTranslation();
  const [active, setActive] = useState(showOrders ? 1 : 0);
  const [showQuickEdit, setShowQuickEdit] = useState(false);

  const handleNavClick = (id: number) => {
    if (id === 0 || id === 1) {
      setActive(id);
      onShowOrdersChange(id === 1);
    }
  };

  return <>
    <div className="pointer-events-none fixed bottom-4 left-1/2 z-50 w-full max-w-[430px] -translate-x-1/2 overflow-visible">
      <div className="pointer-events-auto relative z-20 flex items-center justify-between gap-1 px-1 pb-2 pt-1">
        <div className="ml-4 rounded-full border border-gray-200 bg-white p-1.5 shadow-md">
          <button onClick={() => setShowQuickEdit(true)} aria-label={translateAttribute("Edit content")} className="relative flex h-10 w-10 items-center justify-center rounded-full text-gray-600"><Search className="h-[22px] w-[22px]" /></button>
        </div>
        <div className="max-w-56 flex-1 rounded-full border border-gray-200 bg-white shadow-md">
          <div className="flex items-center justify-around px-0 py-1.5">
            {[
              { id: 0, label: "Home", icon: <img src={active === 0 ? homeIcon : homeIconActive} alt={translateAttribute("Home")} className="h-[22px] w-[22px]" /> },
              { id: 1, label: "Orders", icon: <img src={active === 1 ? clipsIconActive : clipsIcon} alt={translateAttribute("Orders")} className="h-[22px] w-[22px]" /> },
              { id: 2, label: "Products", icon: <img src={tagIcon} alt={translateAttribute("Products")} className="h-[22px] w-[22px]" /> },
              { id: 3, label: "Menu", icon: <Menu className="h-[22px] w-[22px]" /> },
            ].map((item) => <button key={item.id} aria-label={item.label} onClick={() => handleNavClick(item.id)} className={`relative flex h-10 w-10 items-center justify-center rounded-full text-gray-600 transition-all ${active === item.id ? "bg-[#efefef] shadow-[0_0_0_3px_#efefef]" : ""}`}>{item.icon}</button>)}
          </div>
        </div>
        <div className="mr-4 rounded-full border border-gray-200 bg-white p-1.5 shadow-md">
          <button onClick={() => setShowQuickEdit(true)} aria-label={translateAttribute("Profile")} className="relative flex h-10 w-10 items-center justify-center rounded-full"><img src={profileIcon} alt={translateAttribute("Profile")} className="h-6 w-6 rounded-full object-cover" /></button>
        </div>
      </div>
    </div>
    <QuickEditOverlay open={showQuickEdit} onClose={() => setShowQuickEdit(false)} />
  </>;
};

export default BottomNav;
