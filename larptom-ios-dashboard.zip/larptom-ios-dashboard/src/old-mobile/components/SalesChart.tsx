// @ts-nocheck
import { useMemo, useRef, useState, useCallback, useEffect } from "react";
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  ResponsiveContainer,
  CartesianGrid,
} from "recharts";
import { useShopifyLocale } from "@/old-mobile/hooks/use-shopify-locale";
import { DashboardRange, getRange, chartKey, chartCompKey } from "@/old-mobile/lib/dashboard-range";

interface SalesChartProps {
  metricValue: string;
  metricLabel: string;
  editMode?: boolean;
  spike?: number;
  lineHeight?: number;
}

function parseNumericValue(value: string): number {
  const cleaned = value.replace(/[$,%]/g, "").replace(/,/g, "");
  const num = parseFloat(cleaned);
  return isNaN(num) ? 0 : num;
}

// ---------- Range-aware axis + point count ----------
function pointCountFor(range: DashboardRange): number {
  switch (range) {
    case "today":
      return 49; // same as yesterday: 24h in half-hour steps
    case "yesterday":
      return 49; // 24h in half-hour steps
    case "last_7_days":
      return 7 * 6 + 1; // 4h resolution → 43 points
    case "last_30_days":
      return 30 * 2 + 1; // 12h resolution → 61 points
  }
}

function axisLabels(range: DashboardRange): string[] {
  const now = new Date();
  if (range === "today" || range === "yesterday") {
    return ["12:00 AM", "12:00 PM", "11:59 PM"];
  }
  const days: string[] = [];
  const span = range === "last_7_days" ? 7 : 30;
  const stride = range === "last_7_days" ? 1 : 5;
  for (let d = span - 1; d >= 0; d -= stride) {
    const dt = new Date(now);
    dt.setDate(now.getDate() - d);
    days.push(range === "last_7_days"
      ? dt.toLocaleDateString("en-US", { weekday: "short" })
      : dt.toLocaleDateString("en-US", { month: "short", day: "numeric" }));
  }
  return days;
}

function pointLabel(range: DashboardRange, i: number, total: number): string {
  const now = new Date();
  if (range === "today") {
    const half = i / 2;
    const h = Math.floor(half);
    const min = i % 2 === 0 ? "00" : "30";
    return `${hourBase(h)}:${min} ${h < 12 ? "AM" : "PM"}`;
  }
  if (range === "yesterday") {
    const half = i / 2;
    const h = Math.floor(half);
    const min = i % 2 === 0 ? "00" : "30";
    return `${hourBase(h)}:${min} ${h < 12 ? "AM" : "PM"}`;
  }
  if (range === "last_7_days") {
    const dayIdx = Math.floor((i / (total - 1)) * 6); // 0..6
    const dt = new Date(now);
    dt.setDate(now.getDate() - (6 - dayIdx));
    return dt.toLocaleDateString("en-US", { weekday: "short" });
  }
  // last_30_days
  const dayIdx = Math.floor((i / (total - 1)) * 29);
  const dt = new Date(now);
  dt.setDate(now.getDate() - (29 - dayIdx));
  return dt.toLocaleDateString("en-US", { month: "short", day: "numeric" });
}

function hourLabel(h: number): string {
  if (h === 0) return "12:00 AM";
  if (h === 12) return "12:00 PM";
  return h < 12 ? `${h}:00 AM` : `${h - 12}:00 PM`;
}
function hourBase(h: number): number {
  if (h === 0) return 12;
  if (h > 12) return h - 12;
  return h;
}

// ---------- Wave generation: deterministic per range + base ----------
function seededRand(seed: number) {
  let s = seed | 0 || 1;
  return () => {
    s = (s * 16807) % 2147483647;
    return (s % 100000) / 100000;
  };
}

function rangeSeed(range: DashboardRange, base: number): number {
  const tag = { today: 1, yesterday: 2, last_7_days: 3, last_30_days: 4 }[range];
  return Math.floor(base * 7 + 1) * 131 + tag * 99991;
}

function generateWave(range: DashboardRange, baseValue: number, count: number, seedOffset = 0): number[] {
  const rand = seededRand(rangeSeed(range, baseValue) + seedOffset);
  const fA = 2 + rand() * 5;
  const fB = 4 + rand() * 8;
  const fC = 8 + rand() * 16;
  const pA = rand() * Math.PI * 2;
  const pB = rand() * Math.PI * 2;
  const pC = rand() * Math.PI * 2;
  const raw: number[] = [];
  for (let i = 0; i < count; i++) {
    const t = count <= 1 ? 0 : i / (count - 1);
    const wave =
      0.45 +
      0.25 * Math.sin(t * Math.PI * fA + pA) +
      0.18 * Math.sin(t * Math.PI * fB + pB) +
      0.12 * Math.sin(t * Math.PI * fC + pC) +
      (rand() - 0.5) * 0.35;
    raw.push(Math.max(0.02, wave));
  }
  // Normalize so the sum of points == baseValue (so the chart values add up to total)
  const sum = raw.reduce((a, b) => a + b, 0) || 1;
  const scale = baseValue / sum;
  return raw.map(v => v * scale);
}

// ---------- Y-axis formatting ----------
function formatYAxis(v: number): string {
  if (v >= 1000) return `${(v / 1000).toFixed(v % 1000 === 0 ? 0 : 1)}K`;
  return v.toFixed(0);
}
function niceTicks(peak: number): number[] {
  if (!peak || peak <= 0) return [0, 50, 100];
  const rough = peak / 4;
  const pow = Math.pow(10, Math.floor(Math.log10(rough)));
  const norm = rough / pow;
  let step: number;
  if (norm <= 1) step = 1 * pow;
  else if (norm <= 2) step = 2 * pow;
  else if (norm <= 5) step = 5 * pow;
  else step = 10 * pow;
  const top = Math.ceil(peak / step) * step;
  const ticks: number[] = [];
  for (let v = 0; v <= top + 1e-9; v += step) ticks.push(Math.round(v));
  return ticks;
}

const CHART_HEIGHT = 160;
const CHART_PADDING_TOP = 10;
const CHART_PADDING_BOTTOM = 30;
const Y_AXIS_WIDTH = 45;

const SalesChart = ({ metricValue, metricLabel, editMode = false, spike = 50, lineHeight = 100 }: SalesChartProps) => {
  const { symbol, t } = useShopifyLocale();
  const numericBase = useMemo(() => parseNumericValue(metricValue), [metricValue]);
  const containerRef = useRef<HTMLDivElement>(null);

  // Active range
  const [range, setRangeState] = useState<DashboardRange>(() => getRange());
  useEffect(() => {
    const sync = () => setRangeState(getRange());
    window.addEventListener("range-changed", sync);
    window.addEventListener("storage", sync);
    return () => {
      window.removeEventListener("range-changed", sync);
      window.removeEventListener("storage", sync);
    };
  }, []);

  const totalPoints = useMemo(() => pointCountFor(range), [range]);

  // Load or generate per-range keyframes. Editing in edit mode updates them.
  const loadOrGenerate = useCallback((kind: "value" | "comp") => {
    const key = kind === "value" ? chartKey(range) : chartCompKey(range);
    try {
      const raw = localStorage.getItem(key);
      if (raw) {
        const parsed: number[] = JSON.parse(raw);
        if (Array.isArray(parsed) && parsed.length === totalPoints) return parsed;
      }
    } catch {}
    if (numericBase <= 0) return new Array(totalPoints).fill(0);
    const base = kind === "value" ? numericBase : numericBase * 0.75;
    const generated = generateWave(range, base, totalPoints, kind === "value" ? 0 : 1234);
    try { localStorage.setItem(key, JSON.stringify(generated)); } catch {}
    return generated;
  }, [range, totalPoints, numericBase]);

  const [valueKf, setValueKf] = useState<number[]>(() => loadOrGenerate("value"));
  const [compKf, setCompKf] = useState<number[]>(() => loadOrGenerate("comp"));

  // Rebuild when range or base value changes
  useEffect(() => {
    setValueKf(loadOrGenerate("value"));
    setCompKf(loadOrGenerate("comp"));
  }, [loadOrGenerate]);

  // Reveal animation state: cover chart on reset, sweep away on update
  const [revealPhase, setRevealPhase] = useState<"idle" | "covered" | "revealing">("idle");

  // Reset / update from external events
  useEffect(() => {
    const handleReset = () => {
      setValueKf(new Array(totalPoints).fill(0));
      setCompKf(new Array(totalPoints).fill(0));
      setRevealPhase("covered");
    };
    const handleUpdate = () => {
      // Notification-driven updates: keep the chart shape as-is, no reload or animation
      // (chart only changes via the Report button, which dispatches `chart-randomized`).
    };
    const handleRandomized = () => {
      if (!editMode) {
        setValueKf(loadOrGenerate("value"));
        setCompKf(loadOrGenerate("comp"));
      }
      requestAnimationFrame(() => {
        setRevealPhase("revealing");
        setTimeout(() => setRevealPhase("idle"), 950);
      });
    };
    const handleChartRefresh = () => {
      setRevealPhase("covered");
      requestAnimationFrame(() => {
        requestAnimationFrame(() => {
          setRevealPhase("revealing");
          setTimeout(() => setRevealPhase("idle"), 950);
        });
      });
    };
    window.addEventListener("metrics-reset", handleReset);
    window.addEventListener("metrics-updated", handleUpdate);
    window.addEventListener("chart-randomized", handleRandomized);
    window.addEventListener("chart-refresh", handleChartRefresh);
    return () => {
      window.removeEventListener("metrics-reset", handleReset);
      window.removeEventListener("metrics-updated", handleUpdate);
      window.removeEventListener("chart-randomized", handleRandomized);
      window.removeEventListener("chart-refresh", handleChartRefresh);
    };
  }, [loadOrGenerate, totalPoints, editMode]);

  // Persist edits when leaving edit mode
  const prevEditMode = useRef(editMode);
  useEffect(() => {
    if (prevEditMode.current && !editMode) {
      try {
        localStorage.setItem(chartKey(range), JSON.stringify(valueKf));
        localStorage.setItem(chartCompKey(range), JSON.stringify(compKf));
      } catch {}
      setEditingLine("solid");
    }
    prevEditMode.current = editMode;
  }, [editMode, valueKf, compKf, range]);

  const [editingLine, setEditingLine] = useState<"solid" | "dashed">("solid");

  const data = useMemo(() => {
    const spikeAmount = Math.max(0, Math.min(100, spike)) / 100;
    const heightFactor = 0.2 + (Math.max(0, Math.min(100, lineHeight)) / 100) * 0.8;
    const valueAverage = valueKf.reduce((sum, value) => sum + value, 0) / Math.max(valueKf.length, 1);
    const comparisonAverage = compKf.reduce((sum, value) => sum + value, 0) / Math.max(compKf.length, 1);
    const smooth = (values: number[]) => values.map((value, index) => {
      let sum = 0;
      let weight = 0;
      for (let offset = -4; offset <= 4; offset += 1) {
        const source = Math.max(0, Math.min(values.length - 1, index + offset));
        const currentWeight = 5 - Math.abs(offset);
        sum += (values[source] ?? value) * currentWeight;
        weight += currentWeight;
      }
      return sum / Math.max(weight, 1);
    });
    const smoothValues = smooth(valueKf);
    const smoothComparison = smooth(compKf);
    const tune = (value: number, softened: number, average: number) => {
      const blended = softened + (value - softened) * spikeAmount;
      return Math.max(0, (average + (blended - average) * (0.45 + spikeAmount * 0.75)) * heightFactor);
    };
    return Array.from({ length: totalPoints }).map((_, i) => ({
      time: pointLabel(range, i, totalPoints),
      value: tune(valueKf[i] ?? 0, smoothValues[i] ?? 0, valueAverage),
      comparison: tune(compKf[i] ?? 0, smoothComparison[i] ?? 0, comparisonAverage),
      idx: i,
    }));
  }, [valueKf, compKf, totalPoints, range, spike, lineHeight]);

  const maxValue = useMemo(() => {
    const allVals = data.flatMap(d => [d.value, d.comparison]);
    return Math.max(...allVals, 1);
  }, [data]);

  const xTicks = useMemo(() => axisLabels(range), [range]);
  const prefix = metricLabel === t("total_sales") ? symbol : "";
  const suffix = metricLabel === t("conversion_rate") ? "%" : "";

  // ---------- Drag-to-edit keyframes ----------
  const draggingIdx = useRef<number | null>(null);
  const getValueFromY = useCallback((clientY: number): number => {
    if (!containerRef.current) return 0;
    const rect = containerRef.current.getBoundingClientRect();
    const chartTop = rect.top + CHART_PADDING_TOP;
    const chartBottom = rect.top + CHART_HEIGHT - CHART_PADDING_BOTTOM;
    const chartH = chartBottom - chartTop;
    const relY = Math.max(0, Math.min(1, (clientY - chartTop) / chartH));
    return maxValue * 1.1 * (1 - relY);
  }, [maxValue]);

  const handlePointerDown = useCallback((idx: number, e: React.PointerEvent) => {
    e.preventDefault();
    e.stopPropagation();
    draggingIdx.current = idx;
    (e.target as HTMLElement).setPointerCapture(e.pointerId);
  }, []);

  const handlePointerMove = useCallback((e: React.PointerEvent) => {
    if (draggingIdx.current === null) return;
    e.preventDefault();
    const newVal = Math.max(0, getValueFromY(e.clientY));
    const setter = editingLine === "solid" ? setValueKf : setCompKf;
    setter(prev => {
      const next = [...prev];
      next[draggingIdx.current!] = newVal;
      return next;
    });
  }, [getValueFromY, editingLine]);


  const handlePointerUp = useCallback(() => {
    draggingIdx.current = null;
  }, []);

  const dotPositions = useMemo(() => {
    if (!editMode) return [];
    const kf = editingLine === "solid" ? valueKf : compKf;
    return kf.slice(0, totalPoints).map((val, i) => {
      const x = totalPoints <= 1 ? 0.5 : i / (totalPoints - 1);
      const chartH = CHART_HEIGHT - CHART_PADDING_TOP - CHART_PADDING_BOTTOM;
      const yMax = maxValue * 1.1;
      const y = CHART_PADDING_TOP + chartH * (1 - val / yMax);
      return { x, y, value: val, index: i };
    });
  }, [editMode, editingLine, valueKf, compKf, totalPoints, maxValue]);

  return (
    <div
      ref={containerRef}
      className="pl-1 pr-2 mt-2 pb-4 relative select-none"
      onPointerMove={editMode ? handlePointerMove : undefined}
      onPointerUp={editMode ? handlePointerUp : undefined}
    >
      {/* Bottom layer: grid + axes (always visible) */}
      <div className="relative z-0">
        <ResponsiveContainer width="100%" height={CHART_HEIGHT}>
          <AreaChart data={data}>
            <CartesianGrid horizontal vertical={false} stroke="#f0f0f0" />
            <XAxis
              dataKey="time"
              axisLine={false}
              tickLine={false}
              tick={{ fontSize: 10, fill: "#9ca3af" }}
              ticks={xTicks}
              interval={0}
            />
            <YAxis
              axisLine={false}
              tickLine={false}
              tick={{ fontSize: 10, fill: "#9ca3af" }}
              tickFormatter={(v) => `${prefix}${formatYAxis(v)}${suffix}`}
              width={Y_AXIS_WIDTH}
              domain={[0, niceTicks(maxValue)[niceTicks(maxValue).length - 1]]}
              ticks={niceTicks(maxValue)}
            />
          </AreaChart>
        </ResponsiveContainer>
      </div>

      {/* Top layer: lines only — clipPath on wrapper reveals left→right without covering grid */}
      <div
        className="absolute inset-0 z-10 pointer-events-none"
        style={{
          clipPath:
            revealPhase === "covered" ? "inset(0 100% 0 0)" : "inset(0 0 0 0)",
          WebkitClipPath:
            revealPhase === "covered" ? "inset(0 100% 0 0)" : "inset(0 0 0 0)",
          transition:
            revealPhase === "revealing"
              ? "clip-path 900ms ease-out, -webkit-clip-path 900ms ease-out"
              : "none",
        }}
      >
        <ResponsiveContainer width="100%" height={CHART_HEIGHT}>
          <AreaChart
            data={data}
            margin={{ top: 5, right: 5, bottom: 35, left: 5 + Y_AXIS_WIDTH }}
          >
            <YAxis
              hide
              width={0}
              domain={[0, niceTicks(maxValue)[niceTicks(maxValue).length - 1]]}
              ticks={niceTicks(maxValue)}
            />
            <XAxis dataKey="time" hide height={0} ticks={xTicks} interval={0} />
            <Area type="monotone" dataKey="value" stroke="#5bc0de" strokeWidth={2} fill="none" isAnimationActive={false} />
            <Area type="monotone" dataKey="comparison" stroke="#5bc0de" strokeWidth={1.5} fill="none" strokeDasharray="5 3" strokeOpacity={0.5} isAnimationActive={false} />
          </AreaChart>
        </ResponsiveContainer>
      </div>


      {editMode && (
        <div className="absolute inset-0" style={{ pointerEvents: "none" }}>
          {dotPositions.map((dot) => {
            const leftPx = Y_AXIS_WIDTH + dot.x * (containerRef.current ? containerRef.current.clientWidth - Y_AXIS_WIDTH - 8 : 300);
            const isSolid = editingLine === "solid";
            return (
              <div
                key={dot.index}
                className={`absolute w-3 h-3 -ml-1.5 -mt-1.5 rounded-full border-2 border-white shadow-lg cursor-grab active:cursor-grabbing ${
                  isSolid ? "bg-blue-500" : "bg-orange-400"
                }`}
                style={{
                  left: `${leftPx}px`,
                  top: `${dot.y}px`,
                  pointerEvents: "auto",
                  touchAction: "none",
                }}
                onPointerDown={(e) => handlePointerDown(dot.index, e)}
              />
            );
          })}
        </div>
      )}

      {editMode && (
        <div className="absolute top-1 right-3 flex items-center gap-1.5">
          <button
            onClick={() => setEditingLine("solid")}
            className={`text-[10px] font-bold px-2 py-0.5 rounded-full transition-colors ${
              editingLine === "solid" ? "bg-blue-500 text-white" : "bg-gray-200 text-gray-600"
            }`}
          >
            SOLID
          </button>
          <button
            onClick={() => setEditingLine("dashed")}
            className={`text-[10px] font-bold px-2 py-0.5 rounded-full transition-colors ${
              editingLine === "dashed" ? "bg-orange-400 text-white" : "bg-gray-200 text-gray-600"
            }`}
          >
            DASHED
          </button>
        </div>
      )}
    </div>
  );
};

export default SalesChart;
