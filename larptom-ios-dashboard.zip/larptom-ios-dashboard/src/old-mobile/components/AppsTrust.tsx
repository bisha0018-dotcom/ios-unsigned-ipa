// @ts-nocheck
import { useAppTranslation } from "@/components/AppTranslation";
import { ReactNode, useState } from "react";
import { MoreHorizontal } from "lucide-react";
import mountainImg from "@/assets/old-mobile/apps-trust-mountain.png";
import ShopifyLocaleSheet from "./ShopifyLocaleSheet";
import { useLocalStorage } from "@/old-mobile/hooks/use-local-storage";
import { useShopifyLocale } from "@/old-mobile/hooks/use-shopify-locale";

const AppsTrust = ({ menuSlot }: { menuSlot?: ReactNode }) => {
  const translateAttribute = useAppTranslation();
  const [showLocale, setShowLocale] = useState(false);
  const [shopifyLang, setShopifyLang] = useLocalStorage("larptom:old:shopify-language", "en");
  const [shopifyCurrency, setShopifyCurrency] = useLocalStorage("larptom:old:shopify-currency", "USD");
  const { t } = useShopifyLocale();

  return (
    <div className="px-3 pb-4 py-[10px]">
      <div>
        <div className="flex items-start justify-between mb-1">
          <h2 className="text-left text-[15px] text-gray-700 font-bold leading-tight m-0 p-0">
            {t("apps_trust_title")}
          </h2>
          {menuSlot || (
            <button className="text-gray-400 text-sm font-bold ml-4 hover:text-gray-600 transition-colors">
              <MoreHorizontal className="w-5 h-5" />
            </button>
          )}
        </div>

        <div className="flex items-start mb-4 gap-0 pr-0">
          <div className="text-left text-[15px] text-gray-700 font-normal flex-1 min-w-0 my-0">
            {t("apps_trust_desc")}
          </div>
          <div className="flex-shrink-0 self-start ml-0 pl-0">
            <img src={mountainImg} alt={translateAttribute("Apps you can trust")} className="w-36 h-auto rounded-lg block" />
          </div>
        </div>

        <div className="text-center mb-4">
          <button
            onClick={() => setShowLocale(true)}
            className="bg-white border border-gray-300 rounded-lg px-6 py-3 text-gray-700 font-bold text-sm shadow-sm hover:bg-gray-50 transition-colors w-full max-w-xs mx-auto"
          >
            {t("view_recommended_picks")}
          </button>
        </div>
      </div>
      <ShopifyLocaleSheet
        open={showLocale}
        onClose={() => setShowLocale(false)}
        language={shopifyLang}
        currency={shopifyCurrency}
        onLanguageChange={setShopifyLang}
        onCurrencyChange={setShopifyCurrency}
      />
    </div>
  );
};

export default AppsTrust;
