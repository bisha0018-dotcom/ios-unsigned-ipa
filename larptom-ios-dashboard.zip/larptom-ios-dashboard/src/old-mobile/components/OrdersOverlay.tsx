// @ts-nocheck
import { useAppTranslation, useAppLanguage } from "@/components/AppTranslation";
import { AppText } from "@/components/AppTranslation";
import { useState, useEffect, useMemo, useCallback } from "react";
import { ChevronDown, MoreHorizontal, PlusCircle, Search, ListFilter, ArrowDownUp } from "lucide-react";
import ordersIllustration from "@/assets/old-mobile/orders-illustration.png";
import { getStoredOrders, clearStoredOrders, type StoredOrder } from "@/old-mobile/hooks/use-notifications";
import PullToRefresh from "@/old-mobile/components/PullToRefresh";

interface OrdersOverlayProps {
  onClose: () => void;
}

const TABS = ["All", "Unfulfilled", "Unpaid", "Open", "Archived"] as const;

function formatTime(ts: number, language: string): string {
  return new Date(ts).toLocaleTimeString(language, { hour: "numeric", minute: "2-digit" });
}

function groupOrdersByDay(orders: StoredOrder[], language: string): { label: string; orders: StoredOrder[] }[] {
  const now = new Date();
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
  const dayNames = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];

  const groups: Record<string, StoredOrder[]> = {};
  const groupOrder: string[] = [];

  for (const order of orders) {
    const d = new Date(order.timestamp);
    const dayStart = new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime();
    const diffDays = Math.floor((today - dayStart) / 86400000);

    let label: string;
    if (diffDays === 0) label = "Today";
    else if (diffDays === 1) label = "Yesterday";
    else if (diffDays < 7) label = d.toLocaleDateString(language, { weekday: "long" });
    else label = d.toLocaleDateString(language, { month: "short", day: "numeric" });

    if (!groups[label]) {
      groups[label] = [];
      groupOrder.push(label);
    }
    groups[label].push(order);
  }

  return groupOrder.map((label) => ({ label, orders: groups[label] }));
}

const OrdersOverlay = ({ onClose }: OrdersOverlayProps) => {
  const translateAttribute = useAppTranslation();
  const language = useAppLanguage();
  const [orders, setOrders] = useState<StoredOrder[]>(getStoredOrders());
  const [activeTab, setActiveTab] = useState<string>("All");
  const [searchQuery, setSearchQuery] = useState("");

  const handleClearOrders = useCallback(() => {
    clearStoredOrders();
  }, []);

  const handleRefresh = useCallback(() => {
    // Cosmetic only
  }, []);

  useEffect(() => {
    const handleUpdate = () => setOrders(getStoredOrders());
    window.addEventListener("orders-updated", handleUpdate);
    window.addEventListener("storage", handleUpdate);
    return () => {
      window.removeEventListener("orders-updated", handleUpdate);
      window.removeEventListener("storage", handleUpdate);
    };
  }, []);

  const filteredOrders = useMemo(() => {
    let filtered = orders;
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      filtered = filtered.filter(
        (o) =>
          `#${o.orderNumber}`.includes(q) ||
          o.customerName.toLowerCase().includes(q)
      );
    }
    return filtered;
  }, [orders, searchQuery]);

  const grouped = useMemo(() => groupOrdersByDay(filteredOrders, language), [filteredOrders, language]);
  const hasOrders = orders.length > 0;

  return (
    <div className="flex min-h-0 flex-1 flex-col overflow-hidden bg-black">
      {/* Header - fixed */}
      <div
        className="flex-shrink-0 bg-black text-white pwa-safe-top"
        style={{ paddingTop: "env(safe-area-inset-top, 0px)" }}
      >
        <div className="flex items-center justify-between px-4 py-3">
          <div className="flex items-center gap-1">
            <span className="text-lg font-semibold"><AppText>Orders</AppText></span>
            <ChevronDown className="h-4 w-4" />
          </div>
          <div className="flex items-center gap-4">
            <PlusCircle className="h-5 w-5 cursor-pointer" onClick={handleClearOrders} />
            <MoreHorizontal className="h-5 w-5" />
          </div>
        </div>
      </div>

      {/* White content area with curve */}
      <div className="flex-1 min-h-0 bg-white rounded-t-3xl overflow-hidden">
        {hasOrders ? (
          <PullToRefresh
            onRefresh={handleRefresh}
            beforeSpinner={
              <>
                {/* Search bar */}
                <div className="flex items-center gap-2 px-4 pt-2 pb-2 bg-white">
                  <div className="flex flex-1 items-center gap-2 rounded-full bg-gray-100 px-3 py-2">
                    <Search className="h-4 w-4 text-gray-400" />
                    <input
                      type="text"
                      placeholder={translateAttribute("Filter orders")}
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="flex-1 bg-transparent text-sm text-gray-900 outline-none placeholder:text-gray-400"
                    />
                  </div>
                  <div className="relative flex h-9 w-9 items-center justify-center rounded-full bg-gray-100">
                    <ArrowDownUp className="h-4 w-4 text-gray-600" />
                    <div className="absolute right-1 top-1 h-2 w-2 rounded-full bg-gray-500" />
                  </div>
                  <div className="flex h-9 w-9 items-center justify-center rounded-full bg-gray-100">
                    <ListFilter className="h-4 w-4 text-gray-600" />
                  </div>
                </div>
                {/* Tabs */}
                <div className="flex gap-0 px-4 py-1 bg-white">
                  {TABS.map((tab) => (
                    <button
                      key={tab}
                      onClick={() => setActiveTab(tab)}
                      className={`rounded-full px-3 py-1.5 text-[13px] font-medium transition-colors ${
                        activeTab === tab
                          ? "bg-gray-200 text-black"
                          : "text-gray-500"
                      }`}
                    >
                      <AppText>{tab}</AppText>
                    </button>
                  ))}
                </div>
              </>
            }
          >
            <div className="pb-24">
              {grouped.map((group) => (
                <div key={group.label}>
                  <div className="bg-gray-100 px-4 py-1">
                    <span className="text-xs font-medium text-gray-500"><AppText>{group.label}</AppText></span>
                  </div>
                  {group.orders.map((order) => (
                    <div
                      key={order.id}
                      className="border-b border-gray-100 px-4 py-3"
                    >
                      <div className="flex items-start justify-between">
                        <span className="text-sm font-semibold text-gray-500">
                          #{order.orderNumber}
                        </span>
                        <span className="text-sm text-gray-400">
                          ${parseFloat(order.amount).toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ",")}
                        </span>
                      </div>
                      <p className="mt-0.5 text-xs text-gray-500"><AppText>
                        {order.customerName} • {order.items} {order.items === 1 ? "item" : "items"} • {formatTime(order.timestamp, language)}
                      </AppText></p>
                      <div className="mt-1.5 flex items-center gap-2">
                        <span className="rounded-full bg-gray-100 px-2.5 py-0.5 text-[11px] font-medium text-gray-600"><AppText>
                          Archived
                        </AppText></span>
                      </div>
                      <p className="mt-1 text-xs text-gray-400"><AppText>Shipping not required</AppText></p>
                    </div>
                  ))}
                </div>
              ))}
            </div>
          </PullToRefresh>
        ) : (
          <div className="flex h-full flex-col items-center justify-center px-6 pb-24">
            <img
              src={ordersIllustration}
              alt={translateAttribute("Manage orders")}
              className="mb-6 h-28 w-28"
            />
            <h2 className="mb-2 text-xl font-semibold text-black"><AppText>Manage your orders</AppText></h2>
            <p className="mb-8 text-center text-sm text-gray-500"><AppText>
              You'll get notified when you receive your first order.
            </AppText></p>
            <button className="mb-3 w-full rounded-lg bg-[#303030] py-3 text-[15px] font-medium text-white/90"><AppText>
              Create order
            </AppText></button>
            <a href="#" className="text-sm font-medium text-blue-600"><AppText>
              Learn how to make your first sale
            </AppText></a>
          </div>
        )}
      </div>
    </div>
  );
};

export default OrdersOverlay;
