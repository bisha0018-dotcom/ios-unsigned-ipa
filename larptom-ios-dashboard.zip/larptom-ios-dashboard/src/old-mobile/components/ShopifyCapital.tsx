// @ts-nocheck
import { AppText } from "@/components/AppTranslation";
import { useState, useRef, useEffect, ReactNode } from "react";
import { Check, MoreHorizontal } from "lucide-react";
import { useLocalStorage } from "@/old-mobile/hooks/use-local-storage";
import NotificationSettings from "./NotificationSettings";

const ShopifyCapital = ({ menuSlot }: { menuSlot?: ReactNode }) => {
  const [amount, setAmount] = useLocalStorage("larptom:old:capital-amount", "2,000");
  const [showSettings, setShowSettings] = useState(false);
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState(amount);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (editing && inputRef.current) {
      inputRef.current.focus();
      inputRef.current.select();
    }
  }, [editing]);

  const save = () => {
    setEditing(false);
    setAmount(draft);
  };

  return (
    <div className="mt-6 px-3 text-gray-600 pb-4">
      <div>
        <div className="flex items-start justify-between mb-1">
          <h2 className="text-left text-[15px] text-gray-700 font-bold leading-tight m-0 p-0"><AppText>
            You're eligible to apply for funding through Shopify Capital
          </AppText></h2>
          {menuSlot || (
            <button className="text-gray-400 text-sm font-bold ml-4 hover:text-gray-600 transition-colors">
              <MoreHorizontal className="w-5 h-5" />
            </button>
          )}
        </div>

        <div className="mb-4">
          <div className="text-left text-base text-gray-700 font-normal mb-1"><AppText>Apply for up to:</AppText></div>
          <div className="text-xl font-bold text-gray-900 cursor-pointer hover:opacity-70" onClick={() => { setDraft(amount); setEditing(true); }}>
            {editing ? (
              <span className="flex items-center">
                $<input
                  ref={inputRef}
                  value={draft}
                  onChange={(e) => setDraft(e.target.value)}
                  onBlur={save}
                  onKeyDown={(e) => e.key === "Enter" && save()}
                  className="bg-transparent border-b border-gray-400 outline-none w-24 text-xl font-bold text-gray-900"
                />
              </span>
            ) : (
              <span>${amount}</span>
            )}
          </div>
        </div>

        <div className="relative mb-4 h-4">
          <svg className="absolute left-0 top-1/2 -translate-y-1/2 w-full h-4" viewBox="0 0 400 16" preserveAspectRatio="none">
            <path d="M0 4 L18 4 L22 16 L34 4 L400 4" fill="none" stroke="#e5e7eb" strokeWidth="1" vectorEffect="non-scaling-stroke" />
          </svg>
        </div>

        <h3 className="text-left text-sm text-gray-700 font-bold leading-tight mb-4"><AppText>
          Get fast funding and repay with a percentage of your daily sales
        </AppText></h3>

        <div className="space-y-2 mb-6">
          <div className="flex items-start gap-2">
            <Check className="w-[18px] h-[18px] text-gray-500 mt-0.5 flex-shrink-0" strokeWidth={3} />
            <span className="text-[13px] text-gray-600"><AppText>Apply with zero impact on your credit score</AppText></span>
          </div>
          <div className="flex items-start gap-2">
            <Check className="w-[18px] h-[18px] text-gray-500 mt-0.5 flex-shrink-0" strokeWidth={3} />
            <span className="text-[13px] text-gray-600"><AppText>Receive funds in as quick as two business days if approved</AppText></span>
          </div>
          <div className="flex items-start gap-2">
            <Check className="w-[18px] h-[18px] text-gray-500 mt-0.5 flex-shrink-0" strokeWidth={3} />
            <span className="text-[13px] text-gray-600"><AppText>One fixed fee, with no compounding interest</AppText></span>
          </div>
        </div>

        <div className="text-center mb-4">
          <button
            onClick={() => setShowSettings(true)}
            className="bg-white border border-gray-300 rounded-lg px-6 py-3 text-gray-700 font-bold text-sm shadow-sm hover:bg-gray-50 transition-colors w-full max-w-xs mx-auto"
          ><AppText>
            Review your offers
          </AppText></button>
        </div>

        <NotificationSettings open={showSettings} onClose={() => setShowSettings(false)} />

        <div className="h-[7px] mx-[-1rem] my-6" style={{ backgroundColor: "rgb(239, 239, 239)" }} />
      </div>
    </div>
  );
};

export default ShopifyCapital;
