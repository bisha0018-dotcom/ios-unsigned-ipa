// @ts-nocheck
import { useAppTranslation } from "@/components/AppTranslation";
import { useLocalStorage } from "@/old-mobile/hooks/use-local-storage";

interface EditableLogoProps {
  initialText: string;
  className?: string;
  shape?: "rounded" | "circle";
  size?: "sm" | "md";
  /** localStorage namespace, e.g. "header-logo" -> header-logo-text / -color / -image */
  storageKey?: string;
}

const EditableLogo = ({
  initialText,
  className = "",
  shape = "rounded",
  size = "md",
  storageKey = "header-logo",
}: EditableLogoProps) => {
  const translateAttribute = useAppTranslation();
  const [logoText] = useLocalStorage<string>(`${storageKey}-text`, initialText);
  const [logoColor] = useLocalStorage<string>(`${storageKey}-color`, "");
  const [logoImage] = useLocalStorage<string>(`${storageKey}-image`, "");

  const sizeClass = size === "sm" ? "w-8 h-8" : "w-10 h-10";
  const shapeClass = shape === "circle" ? "rounded-full" : "rounded-lg";
  const textSize = size === "sm" ? "text-xs" : "text-sm";

  return (
    <div
      className={`${sizeClass} ${shapeClass} ${
        logoColor ? "" : "bg-primary"
      } flex items-center justify-center overflow-hidden flex-shrink-0 ${className}`}
      style={logoColor ? { backgroundColor: logoColor } : undefined}
    >
      {logoImage ? (
        <img src={logoImage} alt={translateAttribute("Logo")} className="w-full h-full object-cover" />
      ) : (
        <span className={`text-primary-foreground ${textSize} font-bold`}>{logoText}</span>
      )}
    </div>
  );
};

export default EditableLogo;
