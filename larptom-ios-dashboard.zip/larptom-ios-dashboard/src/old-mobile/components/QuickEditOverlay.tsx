// @ts-nocheck
import { useAppTranslation } from "@/components/AppTranslation";
import { AppText } from "@/components/AppTranslation";
import { useEffect, useState, type ReactNode } from "react";
import { createPortal } from "react-dom";
import { ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { formatCurrency, getCurrencySymbol, t } from "@/old-mobile/lib/shopify-i18n";
import { getRange, metricsKey } from "@/old-mobile/lib/dashboard-range";
import { getAppVersion, setAppVersion, type AppVersion } from "@/lib/app-version";

interface Props {
  open: boolean;
  onClose: () => void;
}

type MetricsShape = { label: string; value: string; change: string }[];

const formatNumberWithCommas = (raw: string): string => {
  if (raw === "" || raw == null) return "";
  const cleaned = raw.replace(/[^0-9.-]/g, "");
  if (cleaned === "" || cleaned === "-" || cleaned === ".") return cleaned;
  const negative = cleaned.startsWith("-");
  const numStr = cleaned.replace(/-/g, "");
  const [intPart, ...rest] = numStr.split(".");
  const decimals = rest.length ? "." + rest.join("").slice(0, 2) : "";
  const intNum = intPart ? parseInt(intPart, 10) : 0;
  const formattedInt = isNaN(intNum) ? "0" : intNum.toLocaleString("en-US");
  return (negative ? "-" : "") + formattedInt + decimals;
};

const stripCommas = (s: string) => s.replace(/,/g, "");

const readJSON = <T,>(key: string, fallback: T): T => {
  try {
    const storageKey = key.startsWith("larptom:old:") ? key : `larptom:old:${key}`;
    const raw = localStorage.getItem(storageKey);
    return raw !== null ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
};

const writeJSON = (key: string, value: unknown) => {
  const storageKey = key.startsWith("larptom:old:") ? key : `larptom:old:${key}`;
  localStorage.setItem(storageKey, JSON.stringify(value));
  window.dispatchEvent(new CustomEvent("local-storage-changed", { detail: { key: storageKey } }));
};

const QuickEditOverlay = ({ open, onClose }: Props) => {
  const translateAttribute = useAppTranslation();
  const [storeName, setStoreName] = useState("");
  const [logoText, setLogoText] = useState("AB");
  const [logoColor, setLogoColor] = useState("");
  const [logoImage, setLogoImage] = useState("");
  const [totalSales, setTotalSales] = useState("");
  const [orders, setOrders] = useState("");
  const [conversion, setConversion] = useState("");
  const [sessions, setSessions] = useState("");
  const [fulfill, setFulfill] = useState("");
  const [capture, setCapture] = useState("");
  const [returns, setReturns] = useState("");
  const [highRisk, setHighRisk] = useState("");
  const [chargebacks, setChargebacks] = useState("");
  const [block, setBlock] = useState("");
  const [visitors, setVisitors] = useState("");
  const [showChange, setShowChange] = useState(true);
  const [appVersion, setVersionState] = useState<AppVersion>("old");

  const currency = readJSON<string>("shopify-currency", "USD");
  const language = readJSON<string>("shopify-language", "en");
  const symbol = getCurrencySymbol(currency);

  const [currentRange, setCurrentRange] = useState(() => getRange());

  useEffect(() => {
    if (!open) return;
    const range = getRange();
    setCurrentRange(range);
    setStoreName(readJSON<string>("header-store-name", "Change the name and logo"));
    setLogoText(readJSON<string>("header-logo-text", "AB"));
    setLogoColor(readJSON<string>("header-logo-color", ""));
    setLogoImage(readJSON<string>("header-logo-image", ""));
    const metrics = readJSON<MetricsShape>(metricsKey(range), readJSON<MetricsShape>("dashboard-metrics", []));
    const salesRaw = metrics[0]?.value ?? "";
    const ordersRaw = metrics[1]?.value ?? "0";
    const convRaw = metrics[2]?.value ?? "0%";
    const sessionsRaw = metrics[3]?.value ?? "0";
    setTotalSales(formatNumberWithCommas(salesRaw.replace(/[^0-9.-]/g, "")));
    setOrders(formatNumberWithCommas(stripCommas(ordersRaw)));
    setConversion(convRaw.replace("%", ""));
    setSessions(formatNumberWithCommas(stripCommas(sessionsRaw)));
    const fulfillVal = String(readJSON<string | number>("orders-fulfill-value", "50+"));
    setFulfill(fulfillVal);
    setCapture(String(readJSON<string | number>("activity-capture", "8")));
    setReturns(String(readJSON<string | number>("activity-returns", "2")));
    setHighRisk(String(readJSON<string | number>("activity-highrisk", "3")));
    setChargebacks(String(readJSON<string | number>("activity-chargebacks", "5")));
    setBlock(String(readJSON<string | number>("activity-block", "1")));
    setVisitors(String(readJSON<number>("visitor-count", 0)));
    const sc = localStorage.getItem("larptom:old:show-change-pct");
    setShowChange(sc === null ? true : JSON.parse(sc));
    setVersionState(getAppVersion());
  }, [open]);

  if (!open) return null;

  const save = () => {
    writeJSON("header-store-name", storeName);
    writeJSON("header-logo-text", logoText);
    writeJSON("header-logo-color", logoColor);
    writeJSON("header-logo-image", logoImage);
    writeJSON("header-avatar-text", logoText);
    writeJSON("header-avatar-color", logoColor);
    writeJSON("header-avatar-image", logoImage);

    const metrics = readJSON<MetricsShape>(metricsKey(currentRange), []);
    const salesNum = parseFloat(stripCommas(totalSales)) || 0;
    const ordersNum = parseInt(stripCommas(orders), 10) || 0;
    const convNum = parseFloat(conversion) || 0;
    const sessionsNum = parseInt(stripCommas(sessions), 10) || 0;

    const labels = [
      t(language, "total_sales"),
      t(language, "orders"),
      t(language, "conversion_rate"),
      t(language, "sessions"),
    ];
    const updated: MetricsShape = [
      { label: labels[0], value: formatCurrency(salesNum, currency), change: metrics[0]?.change ?? "0%" },
      { label: labels[1], value: ordersNum.toLocaleString("en-US"), change: metrics[1]?.change ?? "0%" },
      { label: labels[2], value: `${convNum.toFixed(2)}%`, change: metrics[2]?.change ?? "0%" },
      { label: labels[3], value: sessionsNum.toLocaleString("en-US"), change: metrics[3]?.change ?? "0%" },
    ];
    writeJSON(metricsKey(currentRange), updated);
    // Also mirror to legacy key when editing currently-viewed range so other consumers stay in sync
    if (currentRange === getRange()) {
      writeJSON("dashboard-metrics", updated);
    }

    const activeMetric = readJSON<{ label: string }>("active-metric", { label: updated[0].label } as any);
    const idx = updated.findIndex((m) => m.label === activeMetric?.label);
    writeJSON("active-metric", updated[Math.max(0, idx)]);

    const fulfillTrim = fulfill.trim();
    writeJSON("orders-fulfill-value", fulfillTrim === "" ? "0" : fulfillTrim);
    writeJSON("activity-capture", capture.trim() === "" ? "0" : capture.trim());
    writeJSON("activity-returns", returns.trim() === "" ? "0" : returns.trim());
    writeJSON("activity-highrisk", highRisk.trim() === "" ? "0" : highRisk.trim());
    writeJSON("activity-chargebacks", chargebacks.trim() === "" ? "0" : chargebacks.trim());
    writeJSON("activity-block", block.trim() === "" ? "0" : block.trim());

    const visitorsNum = parseInt(stripCommas(visitors), 10) || 0;
    writeJSON("visitor-count", visitorsNum);

    writeJSON("show-change-pct", showChange);

    window.dispatchEvent(new Event("storage"));
    window.dispatchEvent(new Event("metrics-updated"));
    onClose();
  };

  const inputCls = "h-10 w-full min-w-0 bg-transparent text-right text-[15px] font-semibold text-foreground outline-none placeholder:text-muted-foreground";

  return createPortal(
    <div className="dark fixed inset-0 z-[9999] mx-auto flex w-full max-w-[430px] flex-col bg-editor-background text-foreground">
      <header className="flex h-14 shrink-0 items-center px-2">
        <Button type="button" variant="ghost" size="icon" onClick={onClose} aria-label={translateAttribute("Close editor")}><ArrowLeft /></Button>
        <h2 className="flex-1 text-center text-[17px] font-semibold"><AppText>Edit content</AppText></h2>
        <Button type="button" variant="ghost" onClick={save} className="font-semibold"><AppText>Done</AppText></Button>
      </header>

      <main className="hide-scrollbar min-h-0 flex-1 overflow-y-auto pb-[max(24px,env(safe-area-inset-bottom))]">
        <div className="space-y-6 px-4 py-3">
          <Group title={translateAttribute("App version")}>
            <div className="grid grid-cols-2 gap-1 p-1.5">
              {(["new", "old"] as const).map((version) => <Button key={version} type="button" variant={appVersion === version ? "default" : "ghost"} onClick={() => { setVersionState(version); setAppVersion(version); }} className="h-10 capitalize">{version}</Button>)}
            </div>
          </Group>

          <Group title={translateAttribute("Profile")}>
            <Row label="Name"><input aria-label={translateAttribute("Name")} className={inputCls} value={storeName} onChange={(e) => setStoreName(e.target.value)} placeholder={translateAttribute("My Store")} /></Row>
            <Row label="Logo text"><input aria-label={translateAttribute("Logo text")} className={inputCls} value={logoText} maxLength={3} onChange={(e) => setLogoText(e.target.value)} placeholder={translateAttribute("AB")} /></Row>
            <div className="flex min-h-[64px] items-center gap-3 px-4">
              <div className="flex size-10 shrink-0 items-center justify-center overflow-hidden rounded-lg bg-primary" style={logoColor ? { backgroundColor: logoColor } : undefined}>
                {logoImage ? <img src={logoImage} alt={translateAttribute("Logo preview")} className="size-full object-cover" /> : <span className="text-xs font-bold text-primary-foreground">{logoText}</span>}
              </div>
              <label className="flex h-10 flex-1 cursor-pointer items-center justify-center rounded-md bg-editor-sunken px-3 text-sm font-semibold text-foreground"><AppText>
                Upload image
                </AppText><input type="file" accept="image/*" className="hidden" onChange={(e) => { const file = e.target.files?.[0]; if (!file) return; const reader = new FileReader(); reader.onload = (event) => setLogoImage((event.target?.result as string) || ""); reader.readAsDataURL(file); }} />
              </label>
              <input aria-label={translateAttribute("Logo color")} type="color" value={logoColor || "#00a67e"} onChange={(e) => setLogoColor(e.target.value)} className="size-10 shrink-0 cursor-pointer rounded-md border border-border bg-editor-sunken p-1" />
            </div>
            {logoImage && <div className="px-4 pb-3"><Button type="button" variant="ghost" onClick={() => setLogoImage("")} className="w-full text-destructive"><AppText>Remove image</AppText></Button></div>}
          </Group>

          <Group title={`Numbers · ${t(language, currentRange)}`}>
            <Row label="Live visitors"><input aria-label={translateAttribute("Live visitors")} className={inputCls} inputMode="numeric" value={visitors} onChange={(e) => setVisitors(formatNumberWithCommas(e.target.value))} placeholder="0" /></Row>
            <Row label={`Total sales (${symbol})`}><input aria-label={translateAttribute("Total sales")} className={inputCls} inputMode="decimal" value={totalSales} onChange={(e) => setTotalSales(formatNumberWithCommas(e.target.value))} placeholder="0" /></Row>
            <Row label="Orders"><input aria-label={translateAttribute("Orders")} className={inputCls} inputMode="numeric" value={orders} onChange={(e) => setOrders(formatNumberWithCommas(e.target.value))} placeholder="0" /></Row>
            <Row label="Conversion rate (%)"><input aria-label={translateAttribute("Conversion rate")} className={inputCls} inputMode="decimal" value={conversion} onChange={(e) => setConversion(e.target.value.replace(/[^0-9.]/g, ""))} placeholder="0.00" /></Row>
            <Row label="Sessions"><input aria-label={translateAttribute("Sessions")} className={inputCls} inputMode="numeric" value={sessions} onChange={(e) => setSessions(formatNumberWithCommas(e.target.value))} placeholder="0" /></Row>
          </Group>

          <Group title={translateAttribute("Activity")}>
            <Row label="Orders to fulfill"><input aria-label={translateAttribute("Orders to fulfill")} className={inputCls} value={fulfill} onChange={(e) => setFulfill(e.target.value)} placeholder={translateAttribute("0 or 50+")} /></Row>
            <Row label="Capture payments"><input aria-label={translateAttribute("Capture payments")} className={inputCls} value={capture} onChange={(e) => setCapture(e.target.value)} placeholder="0" /></Row>
            <Row label="Return requests"><input aria-label={translateAttribute("Return requests")} className={inputCls} value={returns} onChange={(e) => setReturns(e.target.value)} placeholder="0" /></Row>
            <Row label="High risk orders"><input aria-label={translateAttribute("High risk orders")} className={inputCls} value={highRisk} onChange={(e) => setHighRisk(e.target.value)} placeholder="0" /></Row>
            <Row label="Chargebacks"><input aria-label={translateAttribute("Chargebacks")} className={inputCls} value={chargebacks} onChange={(e) => setChargebacks(e.target.value)} placeholder="0" /></Row>
            <Row label="Orders with block"><input aria-label={translateAttribute("Orders with block")} className={inputCls} value={block} onChange={(e) => setBlock(e.target.value)} placeholder="0" /></Row>
            <div className="flex min-h-[52px] items-center justify-between gap-3 px-4">
              <span className="text-[15px] text-foreground"><AppText>Show growth %</AppText></span>
              <Button type="button" role="switch" aria-checked={showChange} variant="ghost" size="sm" onClick={() => setShowChange((value) => !value)} className={`relative h-6 w-11 rounded-full p-0 ${showChange ? "bg-primary hover:bg-primary" : "bg-editor-raised hover:bg-editor-raised"}`}>
                <span className={`absolute top-0.5 size-5 rounded-full bg-primary-foreground transition-transform ${showChange ? "translate-x-[22px]" : "translate-x-0.5"}`} />
              </Button>
            </div>
          </Group>
        </div>
      </main>
    </div>,
    document.body
  );
};

const Row = ({ label, children }: { label: string; children: ReactNode }) => <label className="flex min-h-[52px] items-center gap-3 px-4"><span className="shrink-0 text-[15px] text-foreground"><AppText>{label}</AppText></span><div className="ml-auto min-w-0 flex-1">{children}</div></label>;

const Group = ({ title, children }: { title: string; children: ReactNode }) => <section><h3 className="mb-2 px-4 text-[13px] font-medium text-muted-foreground"><AppText>{title}</AppText></h3><div className="divide-y divide-border overflow-hidden rounded-2xl bg-editor-surface">{children}</div></section>;

export default QuickEditOverlay;
