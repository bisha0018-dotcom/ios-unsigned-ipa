// @ts-nocheck
import { AppText } from "@/components/AppTranslation";
import { useAppTranslation } from "@/components/AppTranslation";
import { useState, useRef, useEffect } from "react";
import { ChevronDown } from "lucide-react";
import reportIcon from "@/assets/old-mobile/report-icon.png";
import { useShopifyLocale } from "@/old-mobile/hooks/use-shopify-locale";
import { ALL_RANGES, DashboardRange, getRange, setRange } from "@/old-mobile/lib/dashboard-range";

interface StatsBarProps {
  onReport?: () => void;
  visitorCount?: number;
  onVisitorCountChange?: (count: number) => void;
}

const StatsBar = ({ onReport, visitorCount = 0, onVisitorCountChange }: StatsBarProps) => {
  const translateAttribute = useAppTranslation();
  const { t } = useShopifyLocale();
  const TIME_OPTIONS: { key: DashboardRange; label: string }[] = ALL_RANGES.map(k => ({ key: k, label: t(k) }));

  const hasVisitors = visitorCount > 0;
  const [selectedKey, setSelectedKey] = useState<DashboardRange>(() => getRange());
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const sync = () => setSelectedKey(getRange());
    window.addEventListener("range-changed", sync);
    window.addEventListener("storage", sync);
    return () => {
      window.removeEventListener("range-changed", sync);
      window.removeEventListener("storage", sync);
    };
  }, []);

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setDropdownOpen(false);
      }
    };
    if (dropdownOpen) document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, [dropdownOpen]);



  const visitorLabel = hasVisitors
    ? `${visitorCount} ${visitorCount > 1 ? t("visitors") : t("visitor")}`
    : t("live_view");

  return (
    <div className="relative">
      <div className="relative bg-white px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="relative" ref={dropdownRef}>
            <button
              onClick={() => setDropdownOpen((p) => !p)}
              className="flex items-center gap-1 bg-gray-100 rounded-md px-3 py-1.5 text-sm font-medium text-gray-900 border-none"
            >
              {TIME_OPTIONS.find(o => o.key === selectedKey)?.label ?? t("today")}
              <ChevronDown className="w-4 h-4 text-gray-500" />
            </button>
            {dropdownOpen && (
              <div className="absolute left-0 top-full mt-1 bg-white rounded-md border border-gray-200 shadow-lg z-50 min-w-[140px] py-1">
                {TIME_OPTIONS.map((option) => (
                  <button
                    key={option.key}
                    onClick={() => {
                      setSelectedKey(option.key);
                      setRange(option.key);
                      setDropdownOpen(false);
                    }}
                    className="w-full text-left px-3 py-1.5 text-sm text-gray-900 hover:bg-gray-100 transition-colors"
                  >
                    <AppText>{option.label}</AppText>
                  </button>
                ))}
              </div>
            )}
          </div>
          <div className="flex items-center gap-1.5 bg-gray-100 rounded-md px-3 py-1.5">
            <span className={`w-2 h-2 rounded-full ${hasVisitors ? "bg-green-500" : "bg-gray-400"}`} />
            <span className="text-sm text-gray-700">{visitorLabel}</span>
          </div>
        </div>
        <button
          onClick={onReport}
          className="flex items-center gap-1.5 bg-gray-100 rounded-md px-3 py-1.5 text-sm font-medium text-gray-900 border-none"
        >
          <img src={reportIcon} alt={translateAttribute("Report")} className="w-4 h-4" loading="lazy" />
          {t("report")}
        </button>
      </div>
    </div>
  );
};

export default StatsBar;
