// @ts-nocheck
import { AppText } from "@/components/AppTranslation";
import { useState } from "react";
import { createPortal } from "react-dom";
import { Check, Globe, Banknote } from "lucide-react";

const SHOPIFY_LANGUAGES = [
  { code: "en", name: "English" },
  { code: "de", name: "Deutsch" },
  { code: "fr", name: "Français" },
  { code: "es", name: "Español" },
  { code: "it", name: "Italiano" },
  { code: "pt-BR", name: "Português (Brasil)" },
  { code: "pt", name: "Português" },
  { code: "nl", name: "Nederlands" },
  { code: "pl", name: "Polski" },
  { code: "ja", name: "日本語" },
  { code: "ko", name: "한국어" },
  { code: "zh-CN", name: "简体中文" },
  { code: "zh-TW", name: "繁體中文" },
  { code: "tr", name: "Türkçe" },
  { code: "th", name: "ไทย" },
  { code: "sv", name: "Svenska" },
  { code: "da", name: "Dansk" },
  { code: "fi", name: "Suomi" },
  { code: "nb", name: "Norsk" },
  { code: "cs", name: "Čeština" },
  { code: "ro", name: "Română" },
  { code: "hu", name: "Magyar" },
  { code: "id", name: "Bahasa Indonesia" },
  { code: "ms", name: "Bahasa Melayu" },
  { code: "vi", name: "Tiếng Việt" },
  { code: "hi", name: "हिन्दी" },
  { code: "ar", name: "العربية" },
  { code: "he", name: "עברית" },
];

const SHOPIFY_CURRENCIES = [
  { code: "USD", symbol: "$", name: "US Dollar" },
  { code: "EUR", symbol: "€", name: "Euro" },
  { code: "GBP", symbol: "£", name: "British Pound" },
  { code: "CAD", symbol: "CA$", name: "Canadian Dollar" },
  { code: "AUD", symbol: "A$", name: "Australian Dollar" },
  { code: "JPY", symbol: "¥", name: "Japanese Yen" },
  { code: "CNY", symbol: "¥", name: "Chinese Yuan" },
  { code: "CHF", symbol: "CHF", name: "Swiss Franc" },
  { code: "HKD", symbol: "HK$", name: "Hong Kong Dollar" },
  { code: "NZD", symbol: "NZ$", name: "New Zealand Dollar" },
  { code: "SEK", symbol: "kr", name: "Swedish Krona" },
  { code: "KRW", symbol: "₩", name: "South Korean Won" },
  { code: "SGD", symbol: "S$", name: "Singapore Dollar" },
  { code: "NOK", symbol: "kr", name: "Norwegian Krone" },
  { code: "MXN", symbol: "MX$", name: "Mexican Peso" },
  { code: "INR", symbol: "₹", name: "Indian Rupee" },
  { code: "BRL", symbol: "R$", name: "Brazilian Real" },
  { code: "PLN", symbol: "zł", name: "Polish Zloty" },
  { code: "DKK", symbol: "kr", name: "Danish Krone" },
  { code: "CZK", symbol: "Kč", name: "Czech Koruna" },
  { code: "TRY", symbol: "₺", name: "Turkish Lira" },
  { code: "THB", symbol: "฿", name: "Thai Baht" },
  { code: "TWD", symbol: "NT$", name: "Taiwan Dollar" },
  { code: "AED", symbol: "د.إ", name: "UAE Dirham" },
  { code: "SAR", symbol: "﷼", name: "Saudi Riyal" },
  { code: "PHP", symbol: "₱", name: "Philippine Peso" },
  { code: "MYR", symbol: "RM", name: "Malaysian Ringgit" },
  { code: "IDR", symbol: "Rp", name: "Indonesian Rupiah" },
  { code: "ZAR", symbol: "R", name: "South African Rand" },
  { code: "ILS", symbol: "₪", name: "Israeli Shekel" },
];

type View = "main" | "language" | "currency";

interface ShopifyLocaleSheetProps {
  open: boolean;
  onClose: () => void;
  language: string;
  currency: string;
  onLanguageChange: (code: string) => void;
  onCurrencyChange: (code: string) => void;
}

const ShopifyLocaleSheet = ({ open, onClose, language, currency, onLanguageChange, onCurrencyChange }: ShopifyLocaleSheetProps) => {
  const [view, setView] = useState<View>("main");

  if (!open) return null;

  const selectedLang = SHOPIFY_LANGUAGES.find(l => l.code === language) || SHOPIFY_LANGUAGES[0];
  const selectedCur = SHOPIFY_CURRENCIES.find(c => c.code === currency) || SHOPIFY_CURRENCIES[0];

  const handleClose = () => {
    setView("main");
    onClose();
  };

  return createPortal(
    <div className="fixed inset-0 z-[9999] flex items-end justify-center">
      <div className="absolute inset-0 bg-black/40" onClick={handleClose} />
      <div className="relative z-[10000] w-full max-w-[430px] bg-white rounded-t-[24px] px-5 pb-10 pt-3 animate-in slide-in-from-bottom duration-300">
        <div className="mx-auto mt-1 h-1.5 w-[40px] rounded-full bg-gray-300" />

        {view === "main" && (
          <div className="mt-5 space-y-3">
            <h3 className="text-base font-bold text-gray-900 mb-4"><AppText>Settings</AppText></h3>
            <button
              onClick={() => setView("language")}
              className="w-full flex items-center gap-4 p-4 rounded-2xl border border-gray-200 bg-white hover:bg-gray-50 transition-colors"
            >
              <Globe className="w-5 h-5 text-gray-600" />
              <div className="flex-1 text-left">
                <span className="text-sm font-semibold text-gray-900 block"><AppText>Language</AppText></span>
                <span className="text-xs text-gray-500">{selectedLang.name}</span>
              </div>
            </button>
            <button
              onClick={() => setView("currency")}
              className="w-full flex items-center gap-4 p-4 rounded-2xl border border-gray-200 bg-white hover:bg-gray-50 transition-colors"
            >
              <Banknote className="w-5 h-5 text-gray-600" />
              <div className="flex-1 text-left">
                <span className="text-sm font-semibold text-gray-900 block"><AppText>Currency</AppText></span>
                <span className="text-xs text-gray-500">{selectedCur.symbol} — {selectedCur.name}</span>
              </div>
            </button>
          </div>
        )}

        {view === "language" && (
          <div className="mt-5">
            <button onClick={() => setView("main")} className="text-sm text-blue-600 font-medium mb-3"><AppText>← Back</AppText></button>
            <h3 className="text-base font-bold text-gray-900 mb-3"><AppText>Language</AppText></h3>
            <div className="max-h-[50vh] overflow-y-auto -mx-1 px-1 space-y-1">
              {SHOPIFY_LANGUAGES.map(lang => (
                <button
                  key={lang.code}
                  onClick={() => { onLanguageChange(lang.code); setView("main"); }}
                  className="w-full flex items-center justify-between px-4 py-3 rounded-xl hover:bg-gray-50 transition-colors"
                >
                  <span className="text-sm font-medium text-gray-900">{lang.name}</span>
                  {lang.code === language && <Check className="w-4 h-4 text-green-600" strokeWidth={3} />}
                </button>
              ))}
            </div>
          </div>
        )}

        {view === "currency" && (
          <div className="mt-5">
            <button onClick={() => setView("main")} className="text-sm text-blue-600 font-medium mb-3"><AppText>← Back</AppText></button>
            <h3 className="text-base font-bold text-gray-900 mb-3"><AppText>Currency</AppText></h3>
            <div className="max-h-[50vh] overflow-y-auto -mx-1 px-1 space-y-1">
              {SHOPIFY_CURRENCIES.map(cur => (
                <button
                  key={cur.code}
                  onClick={() => { onCurrencyChange(cur.code); setView("main"); }}
                  className="w-full flex items-center gap-3 px-4 py-3 rounded-xl hover:bg-gray-50 transition-colors"
                >
                  <span className="text-sm font-bold text-gray-900 w-8">{cur.symbol}</span>
                  <div className="flex-1 text-left">
                    <span className="text-sm font-medium text-gray-900">{cur.name}</span>
                    <span className="text-xs text-gray-400 ml-2">{cur.code}</span>
                  </div>
                  {cur.code === currency && <Check className="w-4 h-4 text-green-600" strokeWidth={3} />}
                </button>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>,
    document.body
  );
};

export default ShopifyLocaleSheet;
