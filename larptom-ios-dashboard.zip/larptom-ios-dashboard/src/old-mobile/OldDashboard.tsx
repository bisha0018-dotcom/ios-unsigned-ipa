// @ts-nocheck
import { useCallback, useEffect, useRef, useState, type ReactNode } from "react";
import { useAutoNotifications } from "./hooks/use-notifications";
import { useLiveMetrics } from "./hooks/use-live-metrics";
import { useLocalStorage } from "./hooks/use-local-storage";
import Header from "./components/Header";
import StatsBar from "./components/StatsBar";
import MetricsScroller from "./components/MetricsScroller";
import SalesChart from "./components/SalesChart";
import OrdersFulfill from "./components/OrdersFulfill";
import ShopifyPlusOffer from "./components/ShopifyPlusOffer";
import ShopifyCapital from "./components/ShopifyCapital";
import ShopifyWidget from "./components/ShopifyWidget";
import AppsTrust from "./components/AppsTrust";
import BottomNav from "./components/BottomNav";
import OrdersOverlay from "./components/OrdersOverlay";
import SectionMenu from "./components/SectionMenu";
import ChartTuningOverlay from "./components/ChartTuningOverlay";

const DEFAULT_SECTION_ORDER = ["orders", "capital", "plus", "widget", "apps"];

export function OldDashboard() {
  const randomizeFnRef = useRef<(() => void) | null>(null);
  const [activeMetric, setActiveMetric] = useLocalStorage("active-metric", { label: "Total sales", value: "$0.00" });
  const [visitorCount, setVisitorCount] = useLocalStorage("visitor-count", 0);
  const [showOrders, setShowOrders] = useState(false);
  const [chartEditMode, setChartEditMode] = useState(false);
  const [chartSpike, setChartSpike] = useLocalStorage("larptom:old:chart-spike", 50);
  const [chartLineHeight, setChartLineHeight] = useLocalStorage("larptom:old:chart-line-height", 75);
  const [chartCollapsed, setChartCollapsed] = useState(false);
  const [sectionOrder, setSectionOrder] = useLocalStorage("section-order", DEFAULT_SECTION_ORDER);
  const [movedSections, setMovedSections] = useLocalStorage<string[]>("section-moved", []);
  const { resetAll } = useLiveMetrics();
  useAutoNotifications();

  useEffect(() => {
    document.documentElement.classList.add("app-locked");
    return () => document.documentElement.classList.remove("app-locked");
  }, []);

  const handleSearchReset = useCallback(() => {
    resetAll();
    setActiveMetric({ label: "Total sales", value: "$0.00" });
    setVisitorCount(0);
  }, [resetAll, setActiveMetric, setVisitorCount]);
  void handleSearchReset;

  const moveSection = useCallback((id: string, direction: "up" | "down") => {
    setSectionOrder((previous: string[]) => {
      const next = [...previous];
      const index = next.indexOf(id);
      const other = direction === "up" ? index - 1 : index + 1;
      if (index < 0 || other < 0 || other >= next.length) return next;
      [next[index], next[other]] = [next[other] ?? id, next[index] ?? id];
      return next;
    });
    if (direction === "up") setMovedSections((previous) => previous.includes(id) ? previous : [...previous, id]);
  }, [setMovedSections, setSectionOrder]);

  const renderMenu = (id: string) => {
    const index = sectionOrder.indexOf(id);
    return <SectionMenu canMoveUp={index > 0} canMoveDown={index < sectionOrder.length - 1} onMoveUp={() => moveSection(id, "up")} onMoveDown={() => moveSection(id, "down")} />;
  };

  const sections: Record<string, ReactNode> = {
    orders: <OrdersFulfill key="orders" />,
    capital: <ShopifyCapital key="capital" menuSlot={renderMenu("capital")} />,
    plus: <ShopifyPlusOffer key="plus" menuSlot={renderMenu("plus")} />,
    widget: <ShopifyWidget key="widget" menuSlot={renderMenu("widget")} />,
    apps: <AppsTrust key="apps" menuSlot={renderMenu("apps")} />,
  };

  return <div className="fixed inset-0 flex flex-col overflow-hidden bg-black font-sans text-gray-900">
    {!showOrders && <div className="z-50 shrink-0"><Header chartEditMode={chartEditMode} onBellClick={() => setChartEditMode((value) => !value)} /></div>}
    {showOrders ? <OrdersOverlay onClose={() => setShowOrders(false)} /> : <div className="min-h-0 flex-1 overflow-hidden bg-black"><div className="h-full min-h-0 overflow-hidden rounded-t-3xl bg-white"><div className="scrollbar-hide relative h-full overflow-y-auto overflow-x-hidden overscroll-contain">
      <StatsBar onReport={() => randomizeFnRef.current?.()} visitorCount={visitorCount} onVisitorCountChange={setVisitorCount} />
      <MetricsScroller onReportRef={(fn) => { randomizeFnRef.current = fn; }} onActiveMetricChange={(metric) => setActiveMetric({ label: metric.label, value: metric.value })} onBackgroundClick={() => setChartCollapsed((value) => !value)} />
      <div className="overflow-hidden transition-all duration-400 ease-in-out" style={{ maxHeight: chartCollapsed ? "0px" : "600px", opacity: chartCollapsed ? 0 : 1 }}><SalesChart metricValue={activeMetric.value} metricLabel={activeMetric.label} editMode={chartEditMode} spike={chartSpike} lineHeight={chartLineHeight} /></div>
      {sectionOrder.map((id) => <div key={id} className={movedSections.includes(id) ? "pt-3" : ""}>{sections[id]}</div>)}
      <div className="h-24" />
    </div></div></div>}
    {chartEditMode && !showOrders && (
      <ChartTuningOverlay
        spike={chartSpike}
        lineHeight={chartLineHeight}
        onSpikeChange={setChartSpike}
        onLineHeightChange={setChartLineHeight}
        onClose={() => setChartEditMode(false)}
      />
    )}
    <BottomNav showOrders={showOrders} onShowOrdersChange={setShowOrders} />
  </div>;
}
