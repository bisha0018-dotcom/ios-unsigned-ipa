import { useAppTranslation } from "@/components/AppTranslation";
import { AppText, AppTranslation } from "@/components/AppTranslation";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useCallback, useEffect, useRef, useState } from "react";
import { useServerFn } from "@tanstack/react-start";

import { AppHeader } from "@/components/AppHeader";
import { MetricsCarousel } from "@/components/MetricsCarousel";
import { MetricsChart, type ChartMetric } from "@/components/MetricsChart";
import { ChartActions } from "@/components/ChartActions";
import { ActivitySection } from "@/components/ActivitySection";
import { PullSpinner } from "@/components/PullSpinner";
import { BottomNav } from "@/components/BottomNav";
import { ReportOverlay } from "@/components/ReportOverlay";
import { redeemLicense } from "@/lib/checkout.functions";
import { useCurrency } from "@/lib/currency";
import { getAppVersion, type AppVersion } from "@/lib/app-version";
import { bumpChartShape, onStoreChange, readStore, writeStore } from "@/lib/app-store";
import { OldDashboard } from "@/old-mobile/OldDashboard";
import { Button } from "@/components/ui/button";
import { ChartTuningOverlay } from "@/components/ChartTuningOverlay";
import { applyInstallIcon, getInstallIcon, INSTALL_ICON_KEY, installIcons, type InstallIconId } from "@/lib/install-icons";
import { writeInstallIconCookie } from "@/lib/install-icon-cookie";

export const APP_PATH = "/94Fbs87hd5Hf84jde730Hf495h85756UHR487jI47h784huyyII";

export const Route = createFileRoute("/94Fbs87hd5Hf84jde730Hf495h85756UHR487jI47h784huyyII")({
  head: () => ({
    meta: [
      { title: "Larptom — Private Mobile Access" },
      {
        name: "description",
        content: "Private Larptom mobile access. License key required.",
      },
      { property: "og:title", content: "Larptom — Private Mobile Access" },
      { property: "og:description", content: "Private Larptom mobile access. License key required." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "robots", content: "noindex, nofollow" },
    ],
  }),
  component: AppRoute,
});

const STORE_KEY = "larptom-session";

type StoredSession = { key: string; expiresAt: string; planName?: string };

function readSession(): StoredSession | null {
  try {
    const raw = window.localStorage.getItem(STORE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as StoredSession;
    if (!parsed?.key || !parsed?.expiresAt) return null;
    if (new Date(parsed.expiresAt).getTime() <= Date.now()) {
      window.localStorage.removeItem(STORE_KEY);
      return null;
    }
    return parsed;
  } catch {
    return null;
  }
}

function isStandalone() {
  if (typeof window === "undefined") return false;
  return (
    window.matchMedia("(display-mode: standalone)").matches ||
    (window.navigator as Navigator & { standalone?: boolean }).standalone === true
  );
}

function isMobileDevice() {
  if (typeof window === "undefined") return false;
  const touch = window.matchMedia("(pointer: coarse)").matches || navigator.maxTouchPoints > 0;
  const small = window.matchMedia("(max-width: 1024px)").matches;
  const ua = /android|iphone|ipad|ipod|opera mini|iemobile|mobile/i.test(navigator.userAgent);
  return touch && small && ua;
}

function isIos() {
  if (typeof window === "undefined") return false;
  return /iphone|ipad|ipod/i.test(navigator.userAgent);
}

// Lovable editor/preview: bypass device + PWA gates so the app can be edited.
function isEditorPreview() {
  if (typeof window === "undefined") return false;
  const h = window.location.hostname;
  const isLocal = h === "localhost" || h === "127.0.0.1";
  // Any Lovable-hosted preview/dev host (published site uses the custom domain).
  const isLovableHost =
    (h.endsWith(".lovable.app") || h.endsWith(".lovableproject.com")) &&
    h !== "bishashopv2.lovable.app";

  // Inside the Lovable editor the app is rendered in an iframe.
  let framed = false;
  try {
    framed = window.self !== window.top;
  } catch {
    framed = true;
  }
  return isLocal || isLovableHost || framed;
}


type Stage = "loading" | "blocked" | "locked" | "install" | "app";

function AppRoute() {
  return <AppTranslation><AppRouteContent /></AppTranslation>;
}

function AppRouteContent() {
  const translateAttribute = useAppTranslation();
  const [stage, setStage] = useState<Stage>("loading");
  const [session, setSession] = useState<StoredSession | null>(null);
  const [keyInput, setKeyInput] = useState("");
  const [keyError, setKeyError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const redeem = useServerFn(redeemLicense);

  const logout = useCallback((manual = false) => {
    try {
      window.localStorage.removeItem(STORE_KEY);
    } catch {
      /* ignore */
    }
    setSession(null);
    setKeyInput("");
    setKeyError(manual ? null : "Your license key expired. Grab a new plan to continue.");
    setStage("locked");
  }, []);

  useEffect(() => {
    // Editor/preview: skip all gates and drop straight into the dashboard.
    if (isEditorPreview()) {
      setSession({
        // Editor preview acts as the owner key so admin tools are available here.
        key: "BISHA124!",
        expiresAt: "2099-12-31T00:00:00.000Z",
        planName: "Editor preview",
      });
      setStage("app");
      return;
    }

    // A desktop browser must never be allowed, including desktop standalone mode.
    if (!isMobileDevice()) {
      setStage("blocked");
      return;
    }

    const stored = readSession();
    if (!stored) {
      setStage("locked");
      return;
    }

    let active = true;
    void redeem({ data: { key: stored.key } })
      .then((result) => {
        if (!active) return;
        const refreshed: StoredSession = {
          key: result.key,
          expiresAt: result.expiresAt,
          planName: result.planName,
        };
        window.localStorage.setItem(STORE_KEY, JSON.stringify(refreshed));
        setSession(refreshed);
        setStage(isStandalone() ? "app" : "install");
      })
      .catch(() => {
        if (!active) return;
        window.localStorage.removeItem(STORE_KEY);
        setKeyError("Your license key is invalid or expired. Grab a new plan to continue.");
        setStage("locked");
      });

    return () => {
      active = false;
    };
  }, [redeem]);

  // The dashboard is PWA-only: if we are not in standalone display mode,
  // never render it, no matter how the user got here.
  useEffect(() => {
    if (isEditorPreview()) return;
    const mq = window.matchMedia("(display-mode: standalone)");
    const sync = () => {
      setStage((current) => {
        if (current !== "app" && current !== "install") return current;
        return isStandalone() ? "app" : "install";
      });
    };
    sync();
    mq.addEventListener("change", sync);
    window.addEventListener("focus", sync);
    document.addEventListener("visibilitychange", sync);
    return () => {
      mq.removeEventListener("change", sync);
      window.removeEventListener("focus", sync);
      document.removeEventListener("visibilitychange", sync);
    };
  }, []);

  // Expiry watchdog — logs the user out the moment the key expires.
  useEffect(() => {
    if (!session) return;
    const tick = () => {
      if (new Date(session.expiresAt).getTime() <= Date.now()) logout();
    };
    tick();
    const id = window.setInterval(tick, 1000);
    const onFocus = () => tick();
    window.addEventListener("focus", onFocus);
    document.addEventListener("visibilitychange", onFocus);
    return () => {
      window.clearInterval(id);
      window.removeEventListener("focus", onFocus);
      document.removeEventListener("visibilitychange", onFocus);
    };
  }, [session, logout]);

  // Revocation watchdog — a revoked key stops working within a minute.
  useEffect(() => {
    if (!session || session.key === "EDITOR-PREVIEW") return;
    const recheck = () => {
      void redeem({ data: { key: session.key } }).catch(() => logout());
    };
    const id = window.setInterval(recheck, 60_000);
    window.addEventListener("focus", recheck);
    return () => {
      window.clearInterval(id);
      window.removeEventListener("focus", recheck);
    };
  }, [session, redeem, logout]);

  async function unlock(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setKeyError(null);
    setBusy(true);
    try {
      const result = await redeem({ data: { key: keyInput } });
      const stored: StoredSession = {
        key: result.key,
        expiresAt: result.expiresAt,
        planName: result.planName,
      };
      window.localStorage.setItem(STORE_KEY, JSON.stringify(stored));
      setSession(stored);
      setStage(isStandalone() ? "app" : "install");
    } catch (error) {
      const msg = error instanceof Error ? error.message : "";
      // A Phantom key entered here: hand it over and open the Phantom app instead.
      if (msg.includes("Phantom app")) {
        try { sessionStorage.setItem("larptom-phantom-handoff", keyInput.trim()); } catch { /* ignore */ }
        window.location.href = "/p8Hn3Qx7Vt2Kw9Lm5Rb1Zc6Yd4Fg0Js8Ua3Ph";
        return;
      }
      setKeyError(msg || "Could not validate that key.");
    } finally {
      setBusy(false);
    }
  }

  if (stage === "loading") {
    // Fully silent gate — the access check runs in the background, nothing renders.
    return null;
  }

  if (stage === "blocked") {
    return (
      <main className="lp-page flex min-h-dvh items-center justify-center px-5 py-10">
        <section className="lp-card w-full max-w-[460px] p-7 text-center sm:p-8">
          <p className="lp-label"><AppText>Mobile only</AppText></p>
          <h1 className="mt-3 text-[30px] font-extrabold leading-[1.08] text-white"><AppText>
            This app runs on your phone.
          </AppText></h1>
          <p className="mt-4 text-[14px] leading-[1.7] text-[var(--lp-dim)]"><AppText>
            Desktop access is disabled. Open this page on your mobile device, enter your license key,
            and add it to your home screen.
          </AppText></p>
          <Link to="/d7Kq29Xv4Lm81Rt6Zp3Wc5Nb0Hy8Fj2Gs9Ua4Ve" className="lp-btn lp-btn-primary mt-7 inline-flex w-full justify-center"><AppText>
            Have a desktop key? Open the desktop app
          </AppText></Link>
          <Link to="/" className="lp-btn lp-btn-ghost mt-3 inline-flex w-full justify-center"><AppText>
            Back to Larptom
          </AppText></Link>
        </section>
      </main>
    );
  }

  if (stage === "locked") {
    return (
      <main className="lp-page flex min-h-dvh items-center justify-center px-5 py-10">
        <section className="lp-card w-full max-w-[420px] p-7 sm:p-8">
          <Link to="/" className="text-[13px] font-semibold text-[var(--lp-dim)] hover:text-white"><AppText>
            ← Back to Larptom
          </AppText></Link>
          <p className="lp-label mt-10"><AppText>Private app</AppText></p>
          <h1 className="mt-3 text-[32px] font-extrabold leading-[1.05] text-white"><AppText>Enter your license key.</AppText></h1>
          <p className="mt-4 text-[14px] leading-[1.7] text-[var(--lp-dim)]"><AppText>
            Paste the key from your completed checkout to open the Larptom dashboard.
          </AppText></p>
          <form onSubmit={unlock} className="mt-7">
            <label htmlFor="license-key" className="lp-label"><AppText>License key</AppText></label>
            <input
              id="license-key"
              value={keyInput}
              onChange={(e) => setKeyInput(e.target.value)}
              placeholder={translateAttribute("LARP-XXXX-XXXX-XXXX")}
              autoComplete="off"
              className="mt-3 w-full rounded-xl border border-[var(--lp-border)] bg-white/[0.03] px-4 py-3.5 font-mono text-[14px] uppercase text-white outline-none placeholder:text-[var(--lp-muted)] focus:border-[var(--lp-green)]"
            />
            {keyError && <p className="mt-3 text-[13px] text-[#ff6b6b]">{keyError}</p>}
            <button
              type="submit"
              disabled={busy}
              className="lp-btn lp-btn-primary lp-btn-lg mt-6 w-full justify-center disabled:opacity-60"
            ><AppText>
              {busy ? "Checking…" : "Open the app"}
            </AppText></button>
          </form>
          <p className="mt-5 text-center text-[12px] text-[var(--lp-muted)]"><AppText>
            Need a plan? </AppText><Link to="/buy" search={{ plan: undefined, app: undefined }} className="text-[var(--lp-green)]"><AppText>View pricing</AppText></Link>
          </p>
        </section>
      </main>
    );
  }

  if (stage === "install") {
    return <InstallGuide expiresAt={session?.expiresAt} />;
  }

  return <Dashboard expiresAt={session?.expiresAt} licenseKey={session?.key} onLogout={() => logout(true)} />;
}

function InstallGuide({ expiresAt }: { expiresAt?: string | undefined }) {
  const ios = isIos();
  const [selectedIcon, setSelectedIcon] = useState<InstallIconId>("default");

  useEffect(() => {
    let saved: string | null = null;
    try { saved = localStorage.getItem(INSTALL_ICON_KEY); } catch { /* storage unavailable */ }
    const icon = getInstallIcon(saved);
    setSelectedIcon(icon.id);
    applyInstallIcon(icon.id);
    // Keep the cookie in sync for people who picked an icon before the cookie existed.
    try { writeInstallIconCookie(icon.id); } catch { /* cookies unavailable */ }
    return () => applyInstallIcon("default");
  }, []);

  function selectIcon(id: InstallIconId) {
    setSelectedIcon(id);
    try { localStorage.setItem(INSTALL_ICON_KEY, id); } catch { /* storage unavailable */ }
    try { writeInstallIconCookie(id); } catch { /* cookies unavailable */ }
    applyInstallIcon(id);
    // Browsers may only read the manifest once per page load.
    window.location.reload();
  }

  return (
    <main className="lp-page flex min-h-dvh items-center justify-center px-5 py-10">
      <section className="lp-card w-full max-w-[430px] p-7 sm:p-8">
        <p className="lp-label"><AppText>Key accepted</AppText></p>
        <h1 className="mt-3 text-[30px] font-extrabold leading-[1.08] text-white"><AppText>
          Add it to your home screen.
        </AppText></h1>
        <p className="mt-4 text-[14px] leading-[1.7] text-[var(--lp-dim)]"><AppText>
          The app only runs as an installed app. Install it once — it opens straight into your
          dashboard with your key already entered, no login needed.
        </AppText></p>

        <fieldset className="mt-7">
          <legend className="lp-label"><AppText>Choose your app icon</AppText></legend>
          <div className="mt-3 grid grid-cols-5 gap-2">
            {installIcons.map((icon) => (
              <Button
                key={icon.id}
                type="button"
                variant="ghost"
                aria-label={`${icon.label} app icon`}
                aria-pressed={selectedIcon === icon.id}
                onClick={() => selectIcon(icon.id)}
                className={`h-auto min-w-0 flex-col gap-1.5 rounded-md border p-1.5 text-[10px] leading-tight text-[var(--lp-dim)] hover:text-white ${selectedIcon === icon.id ? "border-white bg-white/10 text-white" : "border-[var(--lp-border)] hover:border-white/40"}`}
              >
                <img src={icon.preview} alt="" className="aspect-square w-full rounded-md object-cover" />
                <span className="w-full truncate text-center">{icon.label}</span>
              </Button>
            ))}
          </div>
        </fieldset>

        <p className="mt-3 text-[12px] text-[var(--lp-muted)]"><AppText>Choose before installing. To change an installed icon, remove the app and install it again.</AppText></p>

        <ol className="mt-7 space-y-4">
          {(ios
            ? [
                "Tap the Share icon in the Safari toolbar.",
                "Scroll down and tap “Add to Home Screen”.",
                "Tap “Add” in the top-right corner.",
                "Open the new Larptom icon from your home screen.",
              ]
            : [
                "Tap the ⋮ menu in your browser toolbar.",
                "Tap “Add to Home screen” / “Install app”.",
                "Confirm with “Install”.",
                "Open the new Larptom icon from your home screen.",
              ]
          ).map((step, i) => (
            <li key={step} className="flex gap-3">
              <span className="mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-full border border-[var(--lp-border)] font-mono text-[12px] text-[var(--lp-green)]">
                {i + 1}
              </span>
              <span className="text-[14px] leading-[1.6] text-[var(--lp-dim)]">{step}</span>
            </li>
          ))}
        </ol>

        {expiresAt && (
          <p className="mt-7 rounded-xl border border-[var(--lp-border)] bg-white/[0.03] px-4 py-3 text-[12px] leading-[1.6] text-[var(--lp-muted)]"><AppText>
            Your access is active until{" "}
            </AppText><span className="text-white">
              {new Date(expiresAt).toLocaleString(undefined, { dateStyle: "medium", timeStyle: "short" })}
            </span>
            . After that you’ll be signed out automatically.
          </p>
        )}

        <p className="mt-6 text-center text-[12px] text-[var(--lp-muted)]"><AppText>
          The dashboard will not open in a browser tab.
        </AppText></p>
      </section>
    </main>
  );
}

const MAX_PULL = 72;

function Dashboard(props: { expiresAt?: string | undefined; licenseKey?: string | undefined; onLogout?: (() => void) | undefined }) {
  const [version, setVersion] = useState<AppVersion>("new");

  useEffect(() => {
    const sync = () => setVersion(getAppVersion());
    sync();
    return onStoreChange(sync);
  }, []);

  return version === "old" ? <AppTranslation legacy><OldDashboard /></AppTranslation> : <NewDashboard {...props} />;
}

function NewDashboard({
  expiresAt,
  licenseKey,
  onLogout,
}: {
  expiresAt?: string | undefined;
  licenseKey?: string | undefined;
  onLogout?: (() => void) | undefined;
}) {
  const scrollRef = useRef<HTMLDivElement>(null);
  const startY = useRef<number | null>(null);
  const startX = useRef(0);
  const axis = useRef<"none" | "vertical" | "horizontal">("none");
  const startAtTop = useRef(false);
  const startAtBottom = useRef(false);
  const [pull, setPull] = useState(0);
  const [refreshing, setRefreshing] = useState(false);
  const [chartOpen, setChartOpen] = useState(true);
  const [chartEditMode, setChartEditMode] = useState(false);
  const [chartSpike, setChartSpike] = useState(() => Number(readStore("bisha:chart-spike", "50")) || 50);
  const [chartLineHeight, setChartLineHeight] = useState(() => Number(readStore("bisha:chart-line-height", "75")) || 75);
  const [activeTab, setActiveTab] = useState("home");
  const [reportOpen, setReportOpen] = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);
  const [pushOpen, setPushOpen] = useState(false);
  const currency = useCurrency();
  const [activeMetric, setActiveMetric] = useState<ChartMetric>({
    label: "Total sales",
    value: "591.760,03",
    prefix: "€",
  });
  const [chartDrag, setChartDrag] = useState({ dx: 0, dragging: false });
  const lastDragDx = useRef(0);
  if (chartDrag.dx !== 0) lastDragDx.current = chartDrag.dx;
  const slideDir = lastDragDx.current > 0 ? "right" : "left";
  const chartMetric = { ...activeMetric, prefix: activeMetric.prefix ? currency : undefined };


  useEffect(() => {
    document.documentElement.classList.add("app-locked");
    return () => document.documentElement.classList.remove("app-locked");
  }, []);

  useEffect(() => writeStore("bisha:chart-spike", String(chartSpike)), [chartSpike]);
  useEffect(() => writeStore("bisha:chart-line-height", String(chartLineHeight)), [chartLineHeight]);

  useEffect(() => {
    const el = scrollRef.current;
    if (!el) return;

    const stopNativeOverscroll = (event: TouchEvent) => {
      const touch = event.touches[0];
      if (!touch || startY.current === null) return;
      const deltaY = touch.clientY - startY.current;
      const deltaX = touch.clientX - startX.current;
      if (Math.abs(deltaY) < 4 || Math.abs(deltaX) > Math.abs(deltaY)) return;
      if ((startAtTop.current && deltaY > 0) || (startAtBottom.current && deltaY < 0)) {
        event.preventDefault();
      }
    };

    el.addEventListener("touchmove", stopNativeOverscroll, { passive: false });
    return () => el.removeEventListener("touchmove", stopNativeOverscroll);
  }, []);

  const onTouchStart = (event: React.TouchEvent<HTMLDivElement>) => {
    if (refreshing) return;
    const el = scrollRef.current;
    const touch = event.touches[0];
    axis.current = "none";
    startAtTop.current = false;
    startAtBottom.current = false;

    const target = event.target as HTMLElement | null;
    if (target?.closest(".horizontal-swipe-row, .embla, [data-no-pull]")) {
      startY.current = null;
      return;
    }

    if (!el || !touch) {
      startY.current = null;
      return;
    }

    startAtTop.current = el.scrollTop <= 0;
    startAtBottom.current = el.scrollTop + el.clientHeight >= el.scrollHeight - 2;
    if (!startAtTop.current && !startAtBottom.current) {
      startY.current = null;
      return;
    }

    startY.current = touch.clientY;
    startX.current = touch.clientX;
  };

  const onTouchMove = (event: React.TouchEvent<HTMLDivElement>) => {
    if (startY.current === null || refreshing) return;
    const touch = event.touches[0];
    if (!touch) return;
    const deltaY = touch.clientY - startY.current;
    const deltaX = Math.abs(touch.clientX - startX.current);

    if (axis.current === "none") {
      if (Math.abs(deltaY) < 6 && deltaX < 6) return;
      axis.current = deltaX > Math.abs(deltaY) ? "horizontal" : "vertical";
    }
    if (axis.current === "horizontal" || !startAtTop.current || deltaY <= 0) {
      setPull(0);
      return;
    }
    setPull(deltaY * 0.5);
  };

  const onTouchEnd = () => {
    if (startY.current === null || refreshing) return;
    startY.current = null;
    axis.current = "none";
    startAtTop.current = false;
    startAtBottom.current = false;
    if (pull >= MAX_PULL) {
      setRefreshing(true);
      setPull(0);
      window.setTimeout(() => setRefreshing(false), 1500);
    } else {
      setPull(0);
    }
  };

  const progress = Math.min(1, pull / MAX_PULL);

  return (
    <div className="app-shell fixed inset-0 overflow-hidden bg-black">
      <div className="relative mx-auto h-full w-full max-w-[430px] overflow-hidden overscroll-none bg-black text-white">
        <AppHeader
          tabKey={activeTab}
          chartEditMode={chartEditMode}
          onManageAccount={() => setProfileOpen(true)}
          onNotifications={() => setPushOpen(true)}
          onLogout={() => onLogout?.()}
          onBellClick={() => {
            setChartEditMode((editing) => !editing);
            setChartOpen(true);
          }}
        />

        <div
          className="absolute right-0 bottom-0 left-0 overflow-hidden bg-black"
          style={{ top: "var(--header-h)" }}
        >
          <div className="pointer-events-none absolute top-3 right-0 left-0 z-0 flex justify-center">
            <div
              className="transition-opacity duration-150"
              style={{ opacity: refreshing || pull > 2 ? 1 : 0 }}
            >
              <PullSpinner progress={progress} spinning={refreshing} />
            </div>
          </div>

          <div
            ref={scrollRef}
            onTouchStart={onTouchStart}
            onTouchMove={onTouchMove}
            onTouchEnd={onTouchEnd}
            onTouchCancel={onTouchEnd}
            className="app-scroll hide-scrollbar relative z-10 h-full touch-pan-y overflow-x-hidden overflow-y-auto overscroll-none rounded-t-[2rem] bg-black"
            style={{
              transform: `translateY(${refreshing ? MAX_PULL * 0.55 : pull}px)`,
              transition: startY.current === null ? "transform 300ms ease-out" : "none",
            }}
          >
            <div className="app-content relative z-10 flex min-h-full flex-col pt-3">
              <MetricsCarousel
                onLiveClick={() => setActiveTab("live")}
                expanded={chartOpen}
                onActiveChange={setActiveMetric}
                onDragOffset={(dx, dragging) => setChartDrag({ dx, dragging })}
                onEmptyClick={() => setChartOpen((open) => !open)}
                onActiveClick={() => setChartOpen((open) => !open)}
              />
              <div
                className="overflow-hidden transition-all duration-500 ease-in-out"
                style={{
                  maxHeight: chartOpen ? 520 : 0,
                  opacity: chartOpen ? 1 : 0,
                  transform: chartOpen ? "translateY(0)" : "translateY(-12px)",
                  paddingBottom: chartOpen ? 8 : 0,
                }}
                aria-hidden={!chartOpen}
              >
                <div
                  style={{
                    transform: `translateX(${chartDrag.dx * 0.6}px)`,
                    opacity: 1 - Math.min(0.6, Math.abs(chartDrag.dx) / 300),
                    transition: chartDrag.dragging ? "none" : "transform 300ms ease-out, opacity 300ms ease-out",
                  }}
                >
                  <div
                    key={activeMetric.label}
                    style={{ animation: `chart-slide-${slideDir} 320ms ease-out` }}
                  >
                    <MetricsChart metric={chartMetric} editMode={chartEditMode} spike={chartSpike} lineHeight={chartLineHeight} />
                  </div>
                </div>
                <ChartActions onReportClick={() => setReportOpen(true)} />
              </div>
              <ActivitySection />
            </div>
          </div>
        </div>

        {chartEditMode && (
          <ChartTuningOverlay
            spike={chartSpike}
            lineHeight={chartLineHeight}
            onSpikeChange={setChartSpike}
            onLineHeightChange={setChartLineHeight}
            onShuffle={bumpChartShape}
            onClose={() => setChartEditMode(false)}
            dark
          />
        )}

        <BottomNav expiresAt={expiresAt} licenseKey={licenseKey} onLogout={onLogout} active={activeTab} onActiveChange={setActiveTab} profileOpen={profileOpen} onProfileOpenChange={setProfileOpen} pushOpen={pushOpen} onPushOpenChange={setPushOpen} />

        <ReportOverlay open={reportOpen} onClose={() => setReportOpen(false)} />
      </div>
    </div>
  );
}

// Export added for the standalone package: renders the dashboard without the license gate.
export { Dashboard };
