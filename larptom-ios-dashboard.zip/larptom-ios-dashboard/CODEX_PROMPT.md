# Larptom Shopify-style Home Dashboard — iOS UI handoff

This folder is a standalone, UI-only copy of the mobile home dashboard. No login, no server:
all numbers, chart shapes, orders, products and settings live in the browser's local storage.

## Run it
    npm install
    npm run dev        # open on a phone-sized window (393 x 852)

## What to build (prompt for Codex)
Recreate this app as a native iOS app (SwiftUI, iOS 17+) that matches the web UI pixel-for-pixel,
OR wrap it as-is with Capacitor (`npx cap add ios`, webDir = `dist`) if exact parity matters most.

Screens / pieces (source in `src/`):
- `AppScreens.tsx` → `NewDashboard`: whole home screen layout, pull-to-refresh, overlays.
- `components/AppHeader.tsx`: store logo, name, bell with badge, account/stores sheets.
- `components/MetricsCarousel.tsx`: swipeable metric pills (Total sales, Orders, …) with rolling numbers.
- `components/MetricsChart.tsx` + `ChartScrubTooltip.tsx`: line chart (solid current, dashed comparison),
  touch-scrub cursor + tooltip, nice-rounded Y axis, time labels per date range. Use Swift Charts.
- `components/ChartActions.tsx`, `DateRangeSheet.tsx`: "Today" range picker and "View report".
- `components/ActivitySection.tsx`: activity chips, banner, dismissible promo cards.
- `components/BottomNav.tsx`, `MobileNavigationMenu.tsx`, `MobileNavigationIcons.tsx`: floating tab bar and menu
  (use the SVG paths exactly — do not substitute SF Symbols).
- Overlays: `OrdersOverlay`, `ProductsOverlay`, `LiveViewOverlay` (Three.js globe → SceneKit/RealityKit),
  `ReportOverlay`, `EditPanel` (all editable numbers/branding), `MobileSidekick`.
- State: `lib/app-store.ts` (key/value store + change events → use @Observable + UserDefaults),
  `lib/date-range.ts`, `lib/currency.ts`, `lib/randomize-metrics.ts`, `lib/orders-store.ts`, `lib/products-store.ts`.
- Images/sounds: `public/assets/` (referenced via `src/assets/*.asset.json` → `url`).
- Translations: `lib/locales/*.json`.
- `src/old-mobile/` is the alternate "old" dashboard version (toggle in Edit panel).

Offline stand-ins: `src/shims/*`, `lib/checkout.functions.ts`, `lib/affiliate.functions.ts` replace the
server calls; admin/affiliate/license sections do nothing in this package.
