import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";
import path from "node:path";

export default defineConfig({
  base: "./",
  plugins: [react(), tailwindcss()],
  resolve: {
    alias: {
      "@tanstack/react-start": path.resolve(__dirname, "src/shims/react-start.ts"),
      "@tanstack/react-router": path.resolve(__dirname, "src/shims/react-router.tsx"),
      "@": path.resolve(__dirname, "src"),
    },
  },
});
